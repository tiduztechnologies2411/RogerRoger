# RogerRoger veröffentlichen und installieren (GitHub Pages)

Die App braucht **keinen Build**. Du lädst die Dateien hoch, GitHub veröffentlicht sie automatisch.
Die Adresse sieht danach so aus: `https://DEIN-NAME.github.io/REPO-NAME/`

## Teil 1 – Hochladen und veröffentlichen

1. **GitHub-Konto** anlegen bzw. anmelden: https://github.com
2. **Neues Repository** erstellen (Plus-Symbol → *New repository*).
   - Name z. B. `roger-roger` (wird Teil der Webadresse, nur Kleinbuchstaben/Bindestriche empfohlen).
   - **Public** wählen (GitHub Pages ist bei kostenlosen Konten nur für öffentliche Repos verfügbar).
   - Keine README/.gitignore/Lizenz hinzufügen lassen.
3. **ZIP auf dem Computer entpacken.** Du siehst den Ordner `roger-roger` mit `index.html`, `sw.js`, `css`, `js`, `icons`, `docs`, `.github` …
4. **Dateien hochladen:** Im leeren Repo auf *uploading an existing file* klicken und den **Inhalt** des Ordners (nicht den Ordner selbst) in das Browserfenster ziehen.
   - ⚠️ Der versteckte Ordner **`.github`** (darin `workflows/pages.yml`) muss mit hoch. Wird er vom Drag & Drop übersprungen (versteckte Ordner), lege die Datei so an: *Add file → Create new file*, Dateiname `.github/workflows/pages.yml` eintippen (die `/` erzeugen die Ordner) und den Inhalt der Datei aus dem ZIP einfügen.
   - Ebenfalls mit hochladen: `.nojekyll` und `.gitignore` (beide versteckt, aber hilfreich; die App läuft zur Not auch ohne).
   - Unten *Commit changes* klicken (Branch `main`).
5. **Pages aktivieren:** Repository → *Settings* → *Pages* → bei **Source** *GitHub Actions* wählen.
6. **Veröffentlichung abwarten:** Reiter *Actions* öffnen. Der Lauf „GitHub Pages“ wird grün (ca. 1 Minute). Falls er nicht von selbst gestartet ist: *Actions → GitHub Pages → Run workflow*.
7. **App öffnen:** Die Adresse steht unter *Settings → Pages* bzw. im Lauf unter „deploy“. Beispiel: `https://DEIN-NAME.github.io/roger-roger/`

## Teil 2 – Installieren

**Android (Chrome):** Adresse öffnen → Menü ⋮ → *App installieren* bzw. *Zum Startbildschirm hinzufügen*. Das Icon (Droide) erscheint auf dem Homescreen, die App startet ohne Browserleiste.

**iPhone/iPad (Safari, nicht Chrome):** Adresse in Safari öffnen → Teilen-Symbol → *Zum Home-Bildschirm* → *Hinzufügen*.

**Desktop (Chrome/Edge):** In der Adressleiste auf das Installieren-Symbol klicken.

Einmal online öffnen reicht, danach startet die App auch ohne Internet.

## Teil 3 – Wichtig zu deinen Daten

- Die Daten liegen **nur auf dem Gerät** (im Browser-Speicher der Adresse `DEIN-NAME.github.io`). Es gibt keinen Server und keine Cloud.
- Die Adresse ist ein **neuer Speicherort**: die App startet leer. Wenn du Daten von der alten Version behalten willst: dort *Einstellungen → Daten & Backup → exportieren*, in der neuen App *importieren*.
- Auf dem iPhone sind **Safari-Tab und installierte App getrennte Speicher**. Installiere zuerst und nutze danach nur die installierte App.
- Mach regelmäßig ein Backup (Einstellungen → Daten & Backup), z. B. bevor du das Gerät wechselst oder Browserdaten löschst.

## Teil 4 – Aktualisieren

1. Geänderte Dateien im Repo ersetzen (*Add file → Upload files*, gleiche Dateinamen überschreiben) und *Commit changes*.
2. Der Workflow veröffentlicht automatisch und vergibt eine neue Cache-Version.
3. In der App erscheint beim nächsten Öffnen **„Neue Version verfügbar – Aktualisieren“**. Antippen lädt die neue Version. Deine Daten bleiben erhalten.

Hinweis: Wenn du später statt *GitHub Actions* die Quelle *Deploy from a branch* nutzt, musst du bei jeder Änderung in `sw.js` die Zeile `const CACHE_VERSION = 'v12';` hochzählen (v13, v14 …), sonst bekommen Geräte das Update nicht.

## Fehlersuche

- **Seite zeigt 404:** Warte 1–2 Minuten nach dem ersten Lauf, prüfe *Settings → Pages → Source = GitHub Actions* und die genaue Adresse (Groß-/Kleinschreibung, abschließender `/`).
- **Actions-Lauf rot:** Meist fehlt eine Datei (die Fehlermeldung nennt sie) oder der Ordner `.github/workflows` liegt nicht richtig im Repo.
- **Icon/Name auf dem Handy alt:** App deinstallieren und neu installieren (Icons werden bei der Installation gespeichert).
- **App lädt alte Version:** App komplett schließen und neu öffnen; erscheint das Update-Banner, antippen.
