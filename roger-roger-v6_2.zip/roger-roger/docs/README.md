# Roger Roger – Technische Dokumentation (V1)

Persönliche, modulare Begleit-App. Läuft vollständig lokal im Browser als installierbare PWA.

## 1. Technologie-Stack

**Vanilla JavaScript (ES-Module) + IndexedDB + native Web-APIs. Kein Build-Schritt, kein Framework, keine externen Abhängigkeiten.**

Begründung:
- Die App soll lokal, offline-fähig und langfristig wartbar sein. Ein Framework (React/Vue) plus Build-Tooling (Vite/Webpack) wäre ein zusätzlicher Layer an Komplexität, den eine App dieses Umfangs nicht braucht ("Überengineere die App nicht").
- Moderne Browser unterstützen ES-Module (`import`/`export`) nativ – dadurch bleibt der Code modular (ein Modul = eine Datei), ganz ohne Bundler.
- **IndexedDB** statt `localStorage`: asynchron (blockiert die UI nicht), unterstützt strukturierte Objekte und Blobs (wichtig für Hintergrundbilder) nativ und hat ein deutlich größeres Speicherkontingent. `localStorage` ist synchron, string-only und typischerweise auf 5–10 MB begrenzt – das reicht nicht für Bilder, Trainingshistorien und Notizen über Monate hinweg.
- Ein Service Worker übernimmt das Caching der App-Shell (HTML/CSS/JS) für echte Offline-Nutzung, unabhängig von den in IndexedDB gespeicherten Nutzerdaten.

## 2. Projektstruktur

```
roger-roger/
├── index.html              Einstiegspunkt, lädt Styles + app.js
├── manifest.webmanifest    PWA-Manifest (Name, Icon, Startverhalten)
├── sw.js                   Service Worker (Offline-Caching der App-Shell)
├── icons/                  App-Icons (PNG-Set, Droide); icons/source/ = Originalgrafik (nicht im Deploy)
├── scripts/check-shell.mjs Prüft SHELL_FILES + Manifest-Icons
├── .github/workflows/pages.yml  Veröffentlichung auf GitHub Pages
├── css/
│   ├── tokens.css          Design-Tokens (Neon Core = Standard-Theme, Typografie, Abstände)
│   ├── themes.css          weitere Themes (Pergament, Forest) als Token-Überschreibungen (V6.1)
│   ├── base.css            Reset, Layout-Grundgerüst, Navigation, Buttons, Formulare, Dialoge
│   ├── components.css      Gemeinsame Komponenten (Kacheln, Wochenstreifen, Listen, FAB …)
│   └── <modul>.css         Modul-spezifische Styles (calendar, sport, quiz, notes, settings)
├── js/
│   ├── core/                zentrale, modulübergreifende Bausteine
│   │   ├── db.js             IndexedDB-Wrapper (ein Object Store pro Domäne)
│   │   ├── router.js         einfacher Hash-Router
│   │   ├── moduleRegistry.js Modul-Metadaten, Aktivierung/Reihenfolge
│   │   ├── icons.js          Inline-SVG-Icon-Bibliothek
│   │   ├── theme.js          Theme-Registry, Anwenden + Speichern des gewählten Designs (V6.1)
│   │   └── utils.js          Datum/Zeit-Helfer, IDs, Bildkompression, Toasts
│   ├── modules/              ein Ordner-Äquivalent (Datei) pro fachlichem Modul
│   │   ├── dashboard.js
│   │   ├── calendar.js
│   │   ├── sport.js
│   │   ├── quiz.js
│   │   ├── quizData.js       kuratierter Startbestand an Fragen
│   │   ├── notes.js
│   │   └── settings.js
│   └── app.js                Routing-Registrierung, dynamische Navigation
└── docs/README.md            diese Datei
```

## 3. Modularchitektur

Jedes fachliche Modul (`calendar.js`, `sport.js`, `quiz.js`, `notes.js`) ist bewusst als **eigenständiges JS-Modul mit öffentlicher API** aufgebaut:

- Es exportiert Datenzugriffs-Funktionen (`getX`, `saveX`, `deleteX`) und eine `render(container, params)`-Funktion für die UI.
- Ein Modul greift **nie direkt** auf den IndexedDB-Store eines anderen Moduls zu, sondern – falls überhaupt nötig – nur auf dessen exportierte Funktionen. Beispiel: Das Dashboard liest Kalendereinträge über `calendar.getEntriesForDate()`, nicht direkt aus der DB.
- Der Kalender zeigt Trainingseinheiten an, indem er lesend auf den `workoutSessions`-Store zugreift (siehe `calendar.js`, `getEntriesForDate`) – er dupliziert die Daten aber nicht in eine eigene Tabelle. Das Sport-Modul bleibt alleinige Quelle der Wahrheit für Trainingsdaten. Diese Kopplung ist bewusst nur "lesend" und lose.
- Aktivieren/Deaktivieren eines Moduls (siehe `moduleRegistry.js`) verändert ausschließlich einen Konfigurationseintrag (`settings`-Store). Die Daten des Moduls selbst bleiben in ihren eigenen Object Stores unangetastet – Deaktivieren löscht nichts.

### Neues Modul hinzufügen

1. Neue Datei `js/modules/<name>.js` anlegen, nach dem Muster der bestehenden Module (Datenzugriffs-Funktionen + `render()`).
2. Falls das Modul eigene Daten braucht: in `js/core/db.js` einen neuen Eintrag in `STORES` ergänzen (Objekt-Store-Name) und ggf. in `onupgradeneeded` einen Index anlegen. Dazu `DB_VERSION` um 1 erhöhen.
3. In `js/core/moduleRegistry.js` einen Eintrag in `MODULE_DEFS` ergänzen (`id`, `label`, `icon`, `order`).
4. In `js/app.js`: `import * as <name> from './modules/<name>.js'` und `registerRoute('<name>', <name>.render)`.
5. Bei Bedarf ein passendes Icon in `js/core/icons.js` ergänzen und ein `css/<name>.css` anlegen + in `index.html` (und `sw.js`-Cache-Liste) verlinken.

Bestehende Module müssen dafür **nicht** verändert werden. Die Navigation (Tabbar) und das Dashboard aktualisieren sich automatisch, da sie ihre Modulliste zur Laufzeit aus `moduleRegistry.js` lesen.

## 4. Datenmodell (IndexedDB, Datenbank `roger-roger-db`)

| Store | Zweck | wichtige Felder |
|---|---|---|
| `appointments` | Kalender: eigene Termine | id, title, date, startTime, endTime, note |
| `birthdays` | Kalender: Geburtstage | id, name, day, month (kein Jahr) |
| `trainingPlans` | Sport: importierte/gespeicherte Pläne | id, name, days[{title, exercises[]}] |
| `exercises` | Sport: Übungsbibliothek | id, name, equipment, weight, sets, reps, note |
| `workoutSessions` | Sport: absolviertes Training | id, date, startTime, title, entries[] |
| `bodyMetrics` | Sport: Körpermessungen | id, date, type, value |
| `quizQuestions` | Quiz: Fragenpool | id, category, subtopic, difficulty, text, options[], correctIndex, explanation, source, reviewStatus, reported |
| `quizProgress` | Quiz: Karteikarten-Fortschritt (Leitner-System, 5 Boxen) | id (=questionId), box, knownCount, unknownCount, nextReview |
| `quizResults` | Quiz: abgeschlossene Durchläufe | id, category, difficulty, correctCount, wrongCount, totalCount, percent |
| `notes` | Notizen | id, title, body, createdAt, updatedAt |
| `backgrounds` | Dashboard-Hintergrundbilder | id, imageBlob (komprimiert, max. 1600px) |
| `settings` | Key/Value: Name, Modul-Konfiguration, aktives Hintergrundbild, Auto-Wechsel | key, value |

## 5. Trainingsplan-Importformat

Definiertes JSON-Format (`js/modules/sport.js`, Konstante `IMPORT_FORMAT_VERSION = "roger-roger-trainingsplan-v1"`), gedacht für einen künftigen separaten KI-Masterprompt:

```json
{
  "format": "roger-roger-trainingsplan-v1",
  "name": "Ganzkörper 3er Split",
  "days": [
    {
      "title": "Montag – Brust & Trizeps",
      "exercises": [
        { "name": "Kurzhantel-Bankdrücken", "equipment": "dumbbell", "weight": 12, "reps": 10, "sets": 3, "note": "" }
      ]
    }
  ]
}
```

`equipment` muss einer der in `EQUIPMENT_TYPES` registrierten Schlüssel sein (`dumbbell` → kg, `resistance_band` → lbs, `bodyweight` → ohne Einheit). Weitere Geräte lassen sich dort einfach ergänzen. Vor dem Speichern validiert `validateImportPlan()` Pflichtfelder, Zahlenwerte und bekannte Geräte-Schlüssel und liefert verständliche Fehlermeldungen – erst nach erfolgreicher Vorschau wird importiert.

## 6. Quiz-Fragenformat & Qualitätssicherung

Jede Frage (Store `quizQuestions`) hat: `id`, `category`, `subtopic`, `difficulty` (einfach/mittel/schwer), `text`, `options[4]`, `correctIndex`, `explanation`, `source`, `createdAt`, `reviewStatus` (`reviewed` | `pending`), `reported` (bool).

- Der mitgelieferte Startbestand (`quizData.js`, ~68 Fragen über alle 11 Kategorien inkl. Filmwissenschaften) wurde redaktionell auf gesichertes, unstrittiges Wissen beschränkt und ist mit `reviewStatus: 'reviewed'` markiert.
- **Nur Fragen mit `reviewStatus === 'reviewed'` erscheinen im aktiven Pool** (`getActiveQuestions()`). Das ist die Grundlage dafür, dass künftig automatisiert oder manuell ergänzte Fragen (`reviewStatus: 'pending'`) erst nach Freigabe aktiv werden – die Prüf-Infrastruktur ist vorbereitet, auch wenn V1 keine eigene UI zum Anlegen neuer Fragen enthält.
- "Frage melden" setzt `reported: true`. Eine künftige Admin-/Review-Ansicht kann darauf aufbauen (z.B. gemeldete Fragen aus dem aktiven Pool nehmen).
- Der Karteikartenmodus nutzt ein einfaches **Leitner-System** (5 Boxen, Intervalle 0/1/3/7/16/35 Tage) über den `quizProgress`-Store. Die Architektur (ein Fortschritts-Datensatz pro Frage mit `box` und `nextReview`) lässt sich später leicht durch einen ausgefeilteren Spaced-Repetition-Algorithmus (z. B. SM-2) ersetzen, ohne das Datenmodell zu ändern.

## 7. Bekannte Grenzen der V1 (bewusst offen gelassen)

- Es gibt in der UI keinen Weg, **eigene** Quizfragen manuell anzulegen – nur der kuratierte Startbestand ist vorhanden. Die Datenstruktur (`reviewStatus`) ist aber darauf vorbereitet.
- Der Export/Import (Einstellungen → Daten) sichert den **gesamten** App-Zustand als eine JSON-Datei; es gibt keinen selektiven Export einzelner Module.
- Kein Kalender-Monatsblick, nur Wochenansicht (bewusst gemäß Auftrag: "kein vollständiger Ersatz für Google Calendar").
- Karteikarten-Wiederholung ist ein einfaches Leitner-System, kein SM-2/Anki-Algorithmus.

## 8. App lokal starten

Kein Build-Schritt nötig. Da die App ES-Module lädt, muss sie über **http(s)** ausgeliefert werden (nicht per `file://`, das blockieren Browser bei Modulen). Am einfachsten:

```bash
cd roger-roger
python3 -m http.server 8080
# dann im Smartphone-/Desktop-Browser: http://<Rechner-IP>:8080
```

Alternativ jeden anderen statischen Webserver (z. B. `npx serve`, Nginx, GitHub Pages, Netlify) verwenden – es werden nur statische Dateien ausgeliefert. Für die Installation als PWA auf dem Smartphone: Seite öffnen → Browser-Menü → "Zum Startbildschirm hinzufügen" / "App installieren".

## 9. Später mögliche Erweiterungen (nicht Teil der V1)

- Aufgaben, Gewohnheiten, Einkaufsliste, Finanzen, Rezepte, Medien (siehe Auftrag Punkt 26)
- SM-2-basierte Spaced Repetition im Quiz
- Admin-Ansicht für gemeldete/ausstehende Quizfragen
- Monatsansicht im Kalender
- Selektiver Datenexport pro Modul


## 9. Veröffentlichung als PWA (GitHub Pages, seit v6.2)

Schritt-für-Schritt-Anleitung für Upload, Aktivierung und Installation: `docs/ANLEITUNG-GitHub-Pages.md`.

- **Pfade:** alles relativ (`./…`), daher läuft die App unter `https://<user>.github.io/<repo>/` genauso wie unter `/`. Routing ist hashbasiert (`#/sport`), direkte Aufrufe und Neuladen erzeugen keinen 404.
- **Service Worker:** versionierter Cache, Update-Banner, nur eigene Caches werden gelöscht. Details in `sw.js` (Kopfkommentar) und CLAUDE.md Abschnitt 3 (v6.2).
- **Offline funktioniert:** nach dem ersten erfolgreichen Online-Besuch alles – Dashboard, Kalender, Sport, Quiz (1.000 Fundamentfragen sind Teil der App), Notizen, Einstellungen, Themes, Backup-Export/-Import (lokal).
- **Braucht Internet:** nur der erste Besuch/die Installation und das Laden einer neuen App-Version. Es gibt keine Server- oder Cloud-Funktion.
- **Daten:** IndexedDB gehört zum Origin (`<user>.github.io`), nicht zum Service-Worker-Cache; App-Updates löschen sie nicht. Neuer Origin = leere App, Übernahme per Backup (Einstellungen → Daten & Backup).
