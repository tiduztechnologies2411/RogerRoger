import { registerRoute, initRouter, navigate, currentRoute } from './core/router.js';
import { icon } from './core/icons.js';
import { getActiveModulesSorted } from './core/moduleRegistry.js';
import { loadStoredTheme } from './core/theme.js';
import * as dashboard from './modules/dashboard.js';
import * as calendarModule from './modules/calendar.js';
import * as sport from './modules/sport.js';
import * as quiz from './modules/quiz.js';
import * as notes from './modules/notes.js';
import * as settings from './modules/settings.js';

const MODULE_RENDERERS = {
  calendar: calendarModule.render,
  sport: sport.render,
  quiz: quiz.render,
  notes: notes.render,
};

registerRoute('dashboard', dashboard.render);
registerRoute('calendar', calendarModule.render);
registerRoute('sport', sport.render);
registerRoute('quiz', quiz.render);
registerRoute('notes', notes.render);
registerRoute('settings', settings.render);

async function renderTabbar() {
  const tabbar = document.getElementById('tabbar');
  const modules = await getActiveModulesSorted();
  tabbar.innerHTML = `
    <button class="tabbar__link" data-nav-link="dashboard">${icon('home')}<span>Start</span></button>
    ${modules.map((m) => `<button class="tabbar__link" data-nav-link="${m.id}">${icon(m.icon)}<span>${m.label}</span></button>`).join('')}
    <button class="tabbar__link" data-nav-link="settings">${icon('settings')}<span>Einstellungen</span></button>
  `;
  tabbar.querySelectorAll('[data-nav-link]').forEach((btn) => {
    btn.addEventListener('click', () => navigate(btn.dataset.navLink));
    btn.classList.toggle('is-active', btn.dataset.navLink === currentRoute());
  });
}

window.addEventListener('rr:modules-changed', renderTabbar);
window.addEventListener('hashchange', () => {
  document.querySelectorAll('[data-nav-link]').forEach((el) => {
    el.classList.toggle('is-active', el.dataset.navLink === currentRoute());
  });
});

async function init() {
  await loadStoredTheme();
  await renderTabbar();
  const outlet = document.getElementById('view-outlet');
  initRouter(outlet);

  registerServiceWorker();
}

/**
 * Service Worker (PWA): Registrierung relativ zur Seite -> funktioniert unter GitHub-Pages-Unterpfaden.
 * Neue Version wird NICHT automatisch übernommen, sondern per Banner angeboten (kein Neuladen mitten
 * in einem Training oder beim Schreiben einer Notiz).
 */
function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  const hadController = !!navigator.serviceWorker.controller;
  let reloading = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!hadController || reloading) return; // erste Installation: kein Reload nötig
    reloading = true;
    window.location.reload();
  });

  navigator.serviceWorker.register('./sw.js', { scope: './', updateViaCache: 'none' }).then((reg) => {
    const offerUpdate = (worker) => showUpdateBanner(() => worker.postMessage({ type: 'SKIP_WAITING' }));
    if (reg.waiting && navigator.serviceWorker.controller) offerUpdate(reg.waiting);
    reg.addEventListener('updatefound', () => {
      const worker = reg.installing;
      if (!worker) return;
      worker.addEventListener('statechange', () => {
        if (worker.state === 'installed' && navigator.serviceWorker.controller) offerUpdate(worker);
      });
    });
    // Installierte PWAs bleiben oft tagelang geöffnet: beim Zurückkehren in die App nach Updates suchen
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') reg.update().catch(() => {});
    });
  }).catch(() => { /* Offline-Cache optional, App funktioniert auch ohne */ });
}

function showUpdateBanner(onAccept) {
  if (document.getElementById('update-banner')) return;
  const banner = document.createElement('div');
  banner.id = 'update-banner';
  banner.className = 'update-banner';
  banner.setAttribute('role', 'status');
  banner.innerHTML = '<span>Neue Version verfügbar.</span><button type="button" class="btn btn-primary">Aktualisieren</button>';
  banner.querySelector('button').addEventListener('click', () => {
    banner.querySelector('button').disabled = true;
    onAccept();
  });
  document.body.appendChild(banner);
}

init();
