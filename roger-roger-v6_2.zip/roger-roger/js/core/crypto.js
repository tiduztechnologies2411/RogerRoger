/**
 * crypto.js – Gemeinsame Web-Crypto-Helfer (AES-GCM, PBKDF2).
 *
 * Ursprünglich lokal in notes.js (Bereich "Sicher", V5.0). Dort stand explizit im
 * Kommentar: "Sollte ein weiteres Modul Verschlüsselung benötigen, hier extrahieren."
 * V5.2 (App-Daten-Backup) ist genau dieser Fall: settings.js verschlüsselt optional
 * das gesamte Backup mit dem PIN aus "Sicher" und darf dafür keine eigene, zweite
 * Kryptografie-Implementierung bauen, sondern muss dieselbe, bereits geprüfte Logik
 * verwenden. notes.js nutzt diese Datei seit V5.2 ebenfalls (siehe dort), statt die
 * Funktionen weiterhin lokal zu duplizieren.
 */

export const PBKDF2_ITERATIONS = 150000;

export function bytesToB64(bytes) {
  let bin = '';
  bytes.forEach((b) => { bin += String.fromCharCode(b); });
  return btoa(bin);
}

export function b64ToBytes(b64) {
  const bin = atob(b64);
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
}

export function randomSaltB64(byteLength = 16) {
  return bytesToB64(crypto.getRandomValues(new Uint8Array(byteLength)));
}

/** Leitet einen AES-GCM-256-Schlüssel aus einer PIN/einem Passwort + Salt ab (PBKDF2-SHA256). */
export async function deriveKeyFromPin(pin, saltBytes) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: saltBytes, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function encryptJSON(key, obj) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const data = new TextEncoder().encode(JSON.stringify(obj));
  const cipherBuf = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, data);
  return { cipher: bytesToB64(new Uint8Array(cipherBuf)), iv: bytesToB64(iv) };
}

/** Wirft bei falschem Schlüssel/manipuliertem Chiffrat (AES-GCM-Authentifizierungstag passt nicht) – kein Klartextvergleich nötig. */
export async function decryptJSON(key, cipherB64, ivB64) {
  const iv = b64ToBytes(ivB64);
  const cipherBytes = b64ToBytes(cipherB64);
  const plainBuf = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, cipherBytes);
  return JSON.parse(new TextDecoder().decode(plainBuf));
}
