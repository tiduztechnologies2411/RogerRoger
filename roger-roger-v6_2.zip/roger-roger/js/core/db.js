/**
 * db.js – Zentrale lokale Datenhaltung (IndexedDB)
 *
 * Warum IndexedDB (statt localStorage)?
 * - localStorage ist synchron, string-only und auf ~5-10MB begrenzt.
 *   Hintergrundbilder (Blobs), Trainingshistorien und Notizen sprengen das schnell.
 * - IndexedDB ist asynchron (blockiert die UI nicht), unterstützt strukturierte
 *   Objekte & Blobs nativ, hat ein deutlich größeres Speicherkontingent und
 *   funktioniert vollständig offline. Genau das braucht eine "local first" PWA.
 *
 * Jedes Modul bekommt seinen eigenen Object Store (siehe STORES unten).
 * So bleiben Module lose gekoppelt: ein Modul greift nie direkt auf die Tabelle
 * eines anderen Moduls zu, sondern nur über dessen öffentliche API (siehe modules/*.js).
 */

const DB_NAME = 'roger-roger-db';
const DB_VERSION = 5;

/** Object Stores – ein Store pro Domäne/Modul. keyPath 'id' überall gleich. */
const STORES = {
  appointments: 'appointments',       // Kalender: eigene Termine
  birthdays: 'birthdays',             // Kalender: Geburtstage
  trainingPlans: 'trainingPlans',     // Sport: Trainingspläne (V2 Sport-Ausbau: Tage → Blöcke)
  exercises: 'exercises',             // Sport: Übungsbibliothek
  workoutSessions: 'workoutSessions', // Sport: absolvierte Trainings (Historie)
  activeWorkout: 'activeWorkout',     // Sport: laufendes Training (V2 Sport-Ausbau, reload-sicher, id 'current')
  bodyMetrics: 'bodyMetrics',         // Sport: Körperdaten
  quizQuestions: 'quizQuestions',     // Quiz: Fragenbibliothek (Seed + JSON-Importe)
  quizCategories: 'quizCategories',   // Quiz: dynamische Kategorienliste (V2)
  quizProgress: 'quizProgress',       // Quiz: Lernfortschritt pro Frage (Karteikarten/Leitner)
  quizResults: 'quizResults',         // Quiz: abgeschlossene Quiz-Durchläufe (Sessions)
  quizAnswerLog: 'quizAnswerLog',     // Quiz: Einzelantwort-Historie je Frage (V2, Basis für Statistik/Problemquiz)
  notes: 'notes',                     // Notizen: normale Notizen (V5.0: + category, isChecklist, checklistItems)
  watchlist: 'watchlist',             // Notizen: Filme & Serien-Watchlist (V5.0)
  secureNotes: 'secureNotes',         // Notizen: verschlüsselte Notizen im Bereich "Sicher" (V5.0, Inhalt clientseitig AES-GCM-verschlüsselt)
  backgrounds: 'backgrounds',         // Dashboard: Hintergrundbilder (Blobs)
  settings: 'settings',               // Einstellungen (key/value, keyPath 'key') – enthält auch die "Sicher"-Auth-Konfiguration (Salt + Verifier, KEIN Klartext-PIN)
  dailies: 'dailies',                 // Dashboard: Dailies – die Aufgabe selbst (V1.5)
  dailyCompletions: 'dailyCompletions', // Dashboard: Dailies – Erledigungsstatus je Tag (V1.5)
  steps: 'steps',                     // Dashboard: manueller Schrittestand je Tag, id = ISO-Datum (V1.5)
};

let _dbPromise = null;

function openDb() {
  if (_dbPromise) return _dbPromise;
  _dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (event) => {
      const db = event.target.result;
      Object.values(STORES).forEach((storeName) => {
        if (!db.objectStoreNames.contains(storeName)) {
          const keyPath = storeName === STORES.settings ? 'key' : 'id';
          const store = db.createObjectStore(storeName, { keyPath });
          if (storeName === STORES.appointments || storeName === STORES.workoutSessions) {
            store.createIndex('date', 'date', { unique: false });
          }
          if (storeName === STORES.bodyMetrics) {
            store.createIndex('date', 'date', { unique: false });
          }
          if (storeName === STORES.quizAnswerLog) {
            store.createIndex('questionId', 'questionId', { unique: false });
            store.createIndex('category', 'category', { unique: false });
          }
        }
      });
    };

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return _dbPromise;
}

function tx(storeName, mode = 'readonly') {
  return openDb().then((db) => db.transaction(storeName, mode).objectStore(storeName));
}

/** Alle Einträge eines Stores lesen */
async function getAll(storeName) {
  const store = await tx(storeName);
  return new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Einzelnen Eintrag per key lesen */
async function get(storeName, key) {
  const store = await tx(storeName);
  return new Promise((resolve, reject) => {
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Eintrag anlegen/überschreiben */
async function put(storeName, value) {
  const store = await tx(storeName, 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put(value);
    req.onsuccess = () => resolve(value);
    req.onerror = () => reject(req.error);
  });
}

async function putMany(storeName, values) {
  const store = await tx(storeName, 'readwrite');
  return new Promise((resolve, reject) => {
    values.forEach((v) => store.put(v));
    store.transaction.oncomplete = () => resolve(values);
    store.transaction.onerror = () => reject(store.transaction.error);
  });
}

/** Eintrag löschen */
async function remove(storeName, key) {
  const store = await tx(storeName, 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

/** Kompletten Store leeren (z.B. bei Datenimport) */
async function clear(storeName) {
  const store = await tx(storeName, 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

/** Export: gesamten DB-Inhalt als JSON-fähiges Objekt (Blobs -> Base64) */
async function exportAll() {
  const result = {};
  for (const storeName of Object.values(STORES)) {
    const rows = await getAll(storeName);
    result[storeName] = await Promise.all(rows.map(serializeRow));
  }
  return result;
}

async function serializeRow(row) {
  if (row && row.imageBlob instanceof Blob) {
    const base64 = await blobToBase64(row.imageBlob);
    const { imageBlob, ...rest } = row;
    return { ...rest, imageBase64: base64, imageType: row.imageBlob.type };
  }
  return row;
}

async function deserializeRow(row) {
  if (row && row.imageBase64) {
    const blob = base64ToBlob(row.imageBase64, row.imageType || 'image/jpeg');
    const { imageBase64, imageType, ...rest } = row;
    return { ...rest, imageBlob: blob };
  }
  return row;
}

/** Import: JSON-Objekt (aus exportAll) zurückschreiben, überschreibt vorhandene Daten */
async function importAll(data) {
  for (const storeName of Object.values(STORES)) {
    if (!data[storeName]) continue;
    await clear(storeName);
    const rows = await Promise.all(data[storeName].map(deserializeRow));
    if (rows.length) await putMany(storeName, rows);
  }
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

function base64ToBlob(dataUrl, type) {
  const base64 = dataUrl.split(',')[1] || dataUrl;
  const byteString = atob(base64);
  const bytes = new Uint8Array(byteString.length);
  for (let i = 0; i < byteString.length; i++) bytes[i] = byteString.charCodeAt(i);
  return new Blob([bytes], { type });
}

export const db = { STORES, getAll, get, put, putMany, remove, clear, exportAll, importAll };
