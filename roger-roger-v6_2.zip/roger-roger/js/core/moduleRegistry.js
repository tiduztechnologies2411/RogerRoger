/**
 * moduleRegistry.js – Single Source of Truth für Modul-Metadaten.
 *
 * Das ist der zentrale Baustein für Punkt "Zukunftssicherheit" aus dem Auftrag:
 * ein neues Modul wird ausschließlich hier registriert (Metadaten) + in app.js
 * (Route + Init-Aufruf). Bestehende Module werden dafür nicht angefasst.
 * Siehe docs/README.md, Abschnitt "Neues Modul hinzufügen".
 */
import { db } from './db.js';

export const MODULE_DEFS = [
  { id: 'calendar', label: 'Kalender', icon: 'calendar', order: 0 },
  { id: 'sport', label: 'Sport', icon: 'dumbbell', order: 1 },
  { id: 'quiz', label: 'Quiz', icon: 'brain', order: 2 },
  { id: 'notes', label: 'Notizen', icon: 'note', order: 3 },
];

const SETTINGS_KEY = 'moduleConfig';

/** liefert { [moduleId]: { enabled: bool, order: number } }, mit Defaults aufgefüllt */
export async function getModuleConfig() {
  const stored = await db.get(db.STORES.settings, SETTINGS_KEY);
  const config = stored?.value || {};
  MODULE_DEFS.forEach((def, i) => {
    if (!config[def.id]) config[def.id] = { enabled: true, order: def.order ?? i };
  });
  return config;
}

export async function saveModuleConfig(config) {
  await db.put(db.STORES.settings, { key: SETTINGS_KEY, value: config });
}

export async function setModuleEnabled(moduleId, enabled) {
  const config = await getModuleConfig();
  config[moduleId] = { ...config[moduleId], enabled };
  await saveModuleConfig(config);
  return config;
}

export async function setModuleOrder(orderedIds) {
  const config = await getModuleConfig();
  orderedIds.forEach((id, index) => {
    if (config[id]) config[id].order = index;
  });
  await saveModuleConfig(config);
  return config;
}

/** aktive Module, sortiert nach order – Grundlage für Dashboard & Navigation */
export async function getActiveModulesSorted() {
  const config = await getModuleConfig();
  return MODULE_DEFS
    .filter((def) => config[def.id]?.enabled)
    .sort((a, b) => (config[a.id].order ?? 0) - (config[b.id].order ?? 0));
}

export async function getAllModulesSorted() {
  const config = await getModuleConfig();
  return [...MODULE_DEFS].sort((a, b) => (config[a.id].order ?? 0) - (config[b.id].order ?? 0));
}
