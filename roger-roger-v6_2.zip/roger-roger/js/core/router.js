/**
 * router.js – einfacher Hash-Router.
 * Bewusst simpel gehalten (kein Framework nötig): jedes Modul registriert
 * eine render-Funktion unter seinem Routennamen. Der Router kümmert sich nur
 * darum, die richtige Funktion beim Navigieren aufzurufen und Cleanup auszuführen.
 */

const routes = new Map();
let currentCleanup = null;
let outlet = null;

export function registerRoute(name, renderFn) {
  routes.set(name, renderFn);
}

export function initRouter(outletEl) {
  outlet = outletEl;
  window.addEventListener('hashchange', handleRoute);
  handleRoute();
}

export function navigate(name, params = {}) {
  const query = Object.keys(params).length ? `?${new URLSearchParams(params).toString()}` : '';
  window.location.hash = `#/${name}${query}`;
}

function parseHash() {
  const hash = window.location.hash.replace(/^#\//, '');
  const [name, query] = hash.split('?');
  const params = Object.fromEntries(new URLSearchParams(query || ''));
  return { name: name || 'dashboard', params };
}

async function handleRoute() {
  const { name, params } = parseHash();
  if (typeof currentCleanup === 'function') {
    try { currentCleanup(); } catch (e) { /* noop */ }
    currentCleanup = null;
  }
  const renderFn = routes.get(name) || routes.get('dashboard');
  outlet.innerHTML = '';
  const result = await renderFn(outlet, params);
  if (typeof result === 'function') currentCleanup = result;
  updateActiveNav(routes.has(name) ? name : 'dashboard');
}

function updateActiveNav(name) {
  document.querySelectorAll('[data-nav-link]').forEach((el) => {
    el.classList.toggle('is-active', el.dataset.navLink === name);
  });
}

export function currentRoute() {
  return parseHash().name;
}
