/**
 * theme.js – Theme-System (V6.1)
 *
 * Ein Theme ist ein Satz von CSS-Design-Tokens (siehe css/tokens.css = Neon Core, css/themes.css
 * = weitere Themes), aktiviert über das Attribut data-theme auf <html>. Dieses Modul kennt nur
 * Metadaten (für die Auswahl in den Einstellungen) und kümmert sich um Anwenden + Speichern.
 *
 * Neues Theme: CSS-Block in themes.css + ein Eintrag in THEMES (id muss zum data-theme passen).
 *
 * Persistenz: Quelle der Wahrheit ist der bestehende IndexedDB-Store `settings` (key 'theme',
 * wird dadurch automatisch mit Backup/Restore gesichert). Zusätzlich wird der Wert als reiner
 * Start-Cache in localStorage gespiegelt, damit das Inline-Skript in index.html das Theme
 * synchron VOR dem ersten Rendern setzen kann (sonst kurzes Aufblitzen von Neon Core).
 */
import { db } from './db.js';

export const DEFAULT_THEME = 'neon';
const SETTINGS_KEY = 'theme';
const CACHE_KEY = 'rr-theme'; // muss mit dem Inline-Skript in index.html übereinstimmen

/** preview: Farben für die Vorschaukarte in den Einstellungen; themeColor: <meta name="theme-color"> */
export const THEMES = [
  {
    id: 'neon', label: 'Neon Core', desc: 'Dunkel, Cyan → Violett',
    themeColor: '#0A0D12',
    preview: { bg: '#0A0D12', card: '#12161D', ink: '#F3F6FA', border: '#232A34', gradient: 'linear-gradient(135deg, #22D3EE 0%, #3B82F6 55%, #8B5CF6 100%)' },
  },
  {
    id: 'pergament', label: 'Pergament', desc: 'Warm, Sand & Kupfer',
    themeColor: '#C6AB82',
    preview: { bg: '#C6AB82', card: '#F1E6CE', ink: '#1C1209', border: '#CDB78F', gradient: 'linear-gradient(135deg, #DDB155 0%, #CB8A40 55%, #B5702F 100%)' },
  },
  {
    id: 'forest', label: 'Forest', desc: 'Waldgrün, Salbei & Bronze',
    themeColor: '#0C1C15',
    preview: { bg: '#0C1C15', card: '#14281F', ink: '#F0E9D6', border: '#24402F', gradient: 'linear-gradient(135deg, #B4CBA0 0%, #8FB07A 55%, #B58E5C 100%)' },
  },
];

let currentId = DEFAULT_THEME;

function normalize(id) {
  return THEMES.some((t) => t.id === id) ? id : DEFAULT_THEME;
}

export function getCurrentTheme() {
  return currentId;
}

/** Wendet ein Theme sofort an (kein Reload nötig). Speichert nicht. */
export function applyTheme(id) {
  currentId = normalize(id);
  const theme = THEMES.find((t) => t.id === currentId);
  const root = document.documentElement;
  if (currentId === DEFAULT_THEME) root.removeAttribute('data-theme');
  else root.setAttribute('data-theme', currentId);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', theme.themeColor);
}

function writeCache(id) {
  try { localStorage.setItem(CACHE_KEY, id); } catch (e) { /* Cache optional */ }
}

/** Wendet an UND speichert dauerhaft (IndexedDB + Start-Cache). */
export async function setTheme(id) {
  const next = normalize(id);
  applyTheme(next);
  writeCache(next);
  await db.put(db.STORES.settings, { key: SETTINGS_KEY, value: next });
  return next;
}

/**
 * Liest das gespeicherte Theme aus IndexedDB und wendet es an (Start der App sowie nach einem
 * Backup-Restore). Fehlt der Eintrag (z. B. altes Backup/erster Start), gilt Neon Core.
 */
export async function loadStoredTheme() {
  let id = DEFAULT_THEME;
  try {
    const row = await db.get(db.STORES.settings, SETTINGS_KEY);
    id = normalize(row?.value);
  } catch (e) { /* DB nicht verfügbar → Standarddesign */ }
  applyTheme(id);
  writeCache(id);
  return id;
}
