import { db } from '../core/db.js';
import { icon } from '../core/icons.js';
import {
  uid, isoDate, todayIso, startOfWeek, addWeeks, addDays, addMonths, startOfMonth,
  weekDays, isoWeekday, WEEKDAY_SHORT_LABELS, toast, escapeHtml,
} from '../core/utils.js';
import * as sportModule from './sport.js';

/* ---------- Öffentliche Daten-API (auch für dashboard.js nutzbar) ---------- */

export async function getAppointments() { return db.getAll(db.STORES.appointments); }
export async function getBirthdays() { return db.getAll(db.STORES.birthdays); }

export async function saveAppointment(appt) {
  const row = { ...appt, id: appt.id || uid() };
  await db.put(db.STORES.appointments, row);
  return row;
}
export async function deleteAppointment(id) { await db.remove(db.STORES.appointments, id); }

export async function saveBirthday(bday) {
  const row = { ...bday, id: bday.id || uid() };
  await db.put(db.STORES.birthdays, row);
  return row;
}
export async function deleteBirthday(id) { await db.remove(db.STORES.birthdays, id); }

/** Prüft, ob ein (ggf. wöchentlich wiederkehrender) Termin an einem gegebenen Tag stattfindet.
 * `date` ist bei wiederkehrenden Terminen der Startanker – kein Vorkommen davor. V4.0. */
function appointmentOccursOn(appt, dateObj) {
  const iso = isoDate(dateObj);
  const weekdays = appt.recurrence?.weekdays;
  if (!weekdays || !weekdays.length) return appt.date === iso;
  return iso >= appt.date && weekdays.includes(isoWeekday(dateObj));
}

/** liefert für einen gegebenen Tag alle Einträge: Termine (inkl. wiederkehrend), Geburtstage
 * (jährlich wiederkehrend), absolvierte Trainings sowie geplante Trainings aus aktiven
 * Trainingsplänen (V4.0, rein über die sport.js-API – kein direkter Store-Zugriff mehr). */
export async function getEntriesForDate(dateObj) {
  const iso = isoDate(dateObj);
  const [appts, bdays, sessions, plannedTrainings] = await Promise.all([
    getAppointments(),
    getBirthdays(),
    sportModule.getSessions(),
    sportModule.getPlannedTrainingsForDate(dateObj),
  ]);
  const entries = [];
  appts.filter((a) => appointmentOccursOn(a, dateObj)).forEach((a) => entries.push({ type: 'appointment', ...a, sortTime: a.startTime || '00:00' }));
  bdays.filter((b) => b.day === dateObj.getDate() && (b.month - 1) === dateObj.getMonth())
    .forEach((b) => entries.push({ type: 'birthday', ...b, sortTime: '00:00' }));

  // Sessions, die bereits einem geplanten Trainingstermin zugeordnet sind, nicht doppelt anzeigen.
  const claimedPlanDayIds = new Set(plannedTrainings.filter((t) => t.done).map((t) => `${t.planId}::${t.dayId}`));
  sessions.filter((s) => s.date === iso && !(s.planId && claimedPlanDayIds.has(`${s.planId}::${s.dayId}`)))
    .forEach((s) => {
      // sport.js speichert workoutSessions.startTime als Unix-Timestamp (ms, siehe sport.js),
      // nicht als "HH:MM"-String wie bei appointments. Hier für Anzeige/Sortierung umwandeln,
      // ohne das Datenmodell von sport.js anzufassen (Kalender bleibt nur lesend abhängig).
      const displayTime = typeof s.startTime === 'number'
        ? new Date(s.startTime).toTimeString().slice(0, 5)
        : (s.startTime || '00:00');
      entries.push({ type: 'workout', ...s, displayTime, sortTime: displayTime });
    });
  plannedTrainings.forEach((t) => entries.push({ type: 'training', ...t, sortTime: '00:00' }));

  return entries.sort((a, b) => a.sortTime.localeCompare(b.sortTime));
}

/* ---------- UI: Wochen-/Monatsansicht ---------- */

const VIEWS = [
  { id: 'week', label: 'Woche' },
  { id: 'month', label: 'Monat' },
];

export async function render(container, params = {}) {
  const view = params.view === 'month' ? 'month' : 'week';
  if (view === 'month') {
    const monthStart = params.month ? startOfMonth(new Date(params.month)) : startOfMonth(new Date());
    await renderMonth(container, monthStart);
  } else {
    const weekStart = params.week ? new Date(params.week) : startOfWeek(new Date());
    await renderWeek(container, weekStart);
  }
}

function viewTabsHtml(activeView) {
  return `
    <div class="tabs" role="tablist">
      ${VIEWS.map((v) => `<button class="tabs__btn ${v.id === activeView ? 'is-active' : ''}" data-view="${v.id}">${v.label}</button>`).join('')}
    </div>`;
}

function installViewTabs(container) {
  container.querySelectorAll('[data-view]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (btn.dataset.view === 'month') render(container, { view: 'month' });
      else render(container, { view: 'week' });
    });
  });
}

async function renderWeek(container, weekStart) {
  const days = weekDays(weekStart);
  const todayISO = todayIso();
  const entriesPerDay = await Promise.all(days.map((d) => getEntriesForDate(d)));
  const refresh = () => renderWeek(container, weekStart);

  container.innerHTML = `
    <h1>Kalender</h1>
    ${viewTabsHtml('week')}
    <div class="cal-week-nav">
      <button class="btn-icon" id="prev-week" aria-label="Vorherige Woche">${icon('chevronLeft')}</button>
      <span class="cal-week-nav__label">${weekRangeLabel(days)}</span>
      <button class="btn-icon" id="next-week" aria-label="Nächste Woche">${icon('chevronRight')}</button>
    </div>
    <button class="btn btn-secondary btn-block" id="today-btn" style="margin-bottom:var(--sp-5)">Heute</button>

    ${days.map((d, i) => dayBlock(d, entriesPerDay[i], todayISO)).join('')}

    <div id="cal-empty" class="empty-state" style="display:${entriesPerDay.flat().length ? 'none' : 'block'}">
      ${icon('calendar')}
      <p>Diese Woche ist noch leer. Lege einen Termin oder Geburtstag an.</p>
    </div>
  `;

  installViewTabs(container);
  container.querySelector('#prev-week').addEventListener('click', () => renderWeek(container, addWeeks(weekStart, -1)));
  container.querySelector('#next-week').addEventListener('click', () => renderWeek(container, addWeeks(weekStart, 1)));
  container.querySelector('#today-btn').addEventListener('click', () => renderWeek(container, startOfWeek(new Date())));

  container.querySelectorAll('[data-entry-open]').forEach((el) => {
    el.addEventListener('click', () => openEntryDetail(el.dataset.entryOpen, el.dataset.entryType, refresh));
  });

  installFab(refresh, () => todayIso());
}

async function renderMonth(container, monthStart) {
  const gridDays = monthGridDays(monthStart);
  const todayISO = todayIso();
  const entriesPerDay = await Promise.all(gridDays.map((d) => getEntriesForDate(d)));
  const refresh = () => renderMonth(container, monthStart);

  container.innerHTML = `
    <h1>Kalender</h1>
    ${viewTabsHtml('month')}
    <div class="cal-week-nav">
      <button class="btn-icon" id="prev-month" aria-label="Vorheriger Monat">${icon('chevronLeft')}</button>
      <span class="cal-week-nav__label">${monthLabel(monthStart)}</span>
      <button class="btn-icon" id="next-month" aria-label="Nächster Monat">${icon('chevronRight')}</button>
    </div>
    <button class="btn btn-secondary btn-block" id="today-btn" style="margin-bottom:var(--sp-4)">Heute</button>

    <div class="cal-month-grid">
      ${WEEKDAY_SHORT_LABELS.map((w) => `<div class="cal-month-weekday">${w}</div>`).join('')}
      ${gridDays.map((d, i) => monthCell(d, i, entriesPerDay[i], monthStart, todayISO)).join('')}
    </div>
    <div id="cal-month-detail"></div>
  `;

  installViewTabs(container);
  container.querySelector('#prev-month').addEventListener('click', () => renderMonth(container, addMonths(monthStart, -1)));
  container.querySelector('#next-month').addEventListener('click', () => renderMonth(container, addMonths(monthStart, 1)));
  container.querySelector('#today-btn').addEventListener('click', () => renderMonth(container, startOfMonth(new Date())));

  const detailHost = container.querySelector('#cal-month-detail');
  container.querySelectorAll('[data-month-cell]').forEach((cell) => {
    cell.addEventListener('click', () => {
      const isAlreadyOpen = cell.classList.contains('is-selected');
      container.querySelectorAll('.cal-month-cell.is-selected').forEach((c) => c.classList.remove('is-selected'));
      if (isAlreadyOpen) { detailHost.innerHTML = ''; return; }
      cell.classList.add('is-selected');
      const idx = Number(cell.dataset.monthCell);
      const dateObj = gridDays[idx];
      const entries = entriesPerDay[idx];
      detailHost.innerHTML = `
        <div class="cal-day-block">
          <div class="cal-day-block__head">
            <h3>${dateObj.toLocaleDateString('de-DE', { weekday: 'long' })}${isoDate(dateObj) === todayISO ? ' · heute' : ''}</h3>
            <span>${dateObj.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' })}</span>
          </div>
          ${entries.length ? entries.map(entryLine).join('') : '<p class="field-hint">Keine Einträge</p>'}
        </div>`;
      detailHost.querySelectorAll('[data-entry-open]').forEach((el) => {
        el.addEventListener('click', () => openEntryDetail(el.dataset.entryOpen, el.dataset.entryType, refresh));
      });
    });
  });

  installFab(refresh, () => todayIso());
}

function weekRangeLabel(days) {
  const first = days[0], last = days[6];
  const fmt = (d) => d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' });
  return `${fmt(first)} – ${fmt(last)} ${last.getFullYear()}`;
}

function monthLabel(monthStart) {
  return monthStart.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
}

/** Vollständige Wochen (Montag-Sonntag), die den Monat abdecken – für ein gleichmäßiges 7-Spalten-Raster. */
function monthGridDays(monthStart) {
  const gridStart = startOfWeek(monthStart);
  const lastOfMonth = new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 0);
  const gridEnd = addDays(startOfWeek(lastOfMonth), 6);
  const days = [];
  for (let cur = gridStart; cur <= gridEnd; cur = addDays(cur, 1)) days.push(cur);
  return days;
}

function monthCell(dateObj, idx, entries, monthStart, todayISO) {
  const iso = isoDate(dateObj);
  const isToday = iso === todayISO;
  const isOtherMonth = dateObj.getMonth() !== monthStart.getMonth();
  const hasBirthday = entries.some((e) => e.type === 'birthday');
  const hasTraining = entries.some((e) => e.type === 'training' || e.type === 'workout');
  const hasOther = entries.some((e) => e.type === 'appointment');
  return `
    <div class="cal-month-cell ${isToday ? 'is-today' : ''} ${isOtherMonth ? 'is-other-month' : ''}" data-month-cell="${idx}">
      <span class="cal-month-cell__num">${dateObj.getDate()}</span>
      <span class="cal-month-cell__dots">
        ${hasOther ? '<span class="cal-month-cell__dot"></span>' : ''}
        ${hasTraining ? '<span class="cal-month-cell__dot cal-month-cell__dot--training"></span>' : ''}
        ${hasBirthday ? '<span class="cal-month-cell__dot cal-month-cell__dot--birthday"></span>' : ''}
      </span>
    </div>`;
}

function dayBlock(dateObj, entries, todayISO) {
  const iso = isoDate(dateObj);
  const isToday = iso === todayISO;
  return `
    <div class="cal-day-block">
      <div class="cal-day-block__head">
        <h3>${dateObj.toLocaleDateString('de-DE', { weekday: 'long' })}${isToday ? ' · heute' : ''}</h3>
        <span>${dateObj.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' })}</span>
      </div>
      ${entries.length ? entries.map(entryLine).join('') : '<p class="field-hint">Keine Einträge</p>'}
    </div>`;
}

/** Rendert eine einzelne Kalender-Eintragszeile. Exportiert, damit dashboard.js (Tag-Detailansicht,
 * V4.0) dieselbe Darstellung wiederverwenden kann statt eine zweite zu bauen. */
export function entryLine(entry) {
  if (entry.type === 'birthday') {
    return `
      <div class="cal-entry cal-entry--birthday" data-entry-open="${entry.id}" data-entry-type="birthday">
        <span class="cal-entry__time">${icon('cake')}</span>
        <div><div class="cal-entry__title">${escapeHtml(entry.name)} hat Geburtstag</div></div>
      </div>`;
  }
  if (entry.type === 'training') {
    return `
      <div class="cal-entry cal-entry--workout ${entry.done ? 'cal-entry--training-done' : ''}">
        <span class="cal-entry__time">${icon('dumbbell')}</span>
        <div>
          <div class="cal-entry__title">${escapeHtml(entry.title)}</div>
          <div class="cal-entry__sub">${entry.done ? `${icon('check')} Absolviert` : 'Geplant'}</div>
        </div>
      </div>`;
  }
  if (entry.type === 'workout') {
    return `
      <div class="cal-entry cal-entry--workout">
        <span class="cal-entry__time">${entry.displayTime || ''}</span>
        <div><div class="cal-entry__title">${escapeHtml(entry.title || entry.dayTitle || 'Training')}</div><div class="cal-entry__sub">Sport-Protokoll</div></div>
      </div>`;
  }
  return `
    <div class="cal-entry" data-entry-open="${entry.id}" data-entry-type="appointment">
      <span class="cal-entry__time">${entry.startTime || ''}</span>
      <div>
        <div class="cal-entry__title">${escapeHtml(entry.title)}${entry.recurrence?.weekdays?.length ? ` <span class="field-hint">↻</span>` : ''}</div>
        ${entry.note ? `<div class="cal-entry__sub">${escapeHtml(entry.note)}</div>` : ''}
      </div>
    </div>`;
}

/* ---------- Dialoge ---------- */

/** `refresh` rendert die aktuell sichtbare Ansicht (Woche oder Monat) neu – so muss keine der
 * Dialog-Funktionen wissen, in welcher Ansicht sie gerade geöffnet wurden (V4.0). */
function installFab(refresh, getDefaultDate) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  const fab = document.createElement('button');
  fab.className = 'fab';
  fab.innerHTML = icon('plus');
  fab.setAttribute('aria-label', 'Neuer Eintrag');
  fab.addEventListener('click', () => openChoiceSheet(refresh, getDefaultDate));
  document.body.appendChild(fab);
}

function openChoiceSheet(refresh, getDefaultDate) {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Neuer Eintrag</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <div class="list">
      <button class="btn btn-primary btn-block" data-choice="appointment">${icon('calendar')} Termin</button>
      <button class="btn btn-secondary btn-block" data-choice="birthday">${icon('cake')} Geburtstag hinzufügen</button>
    </div>
  `);
  dlg.querySelector('[data-choice="appointment"]').addEventListener('click', () => { dlg.close(); openAppointmentForm(refresh, getDefaultDate()); });
  dlg.querySelector('[data-choice="birthday"]').addEventListener('click', () => { dlg.close(); openBirthdayForm(refresh); });
}

function openAppointmentForm(refresh, defaultDate, existing = null) {
  const recurring = !!existing?.recurrence?.weekdays?.length;
  const selectedWeekdays = new Set(existing?.recurrence?.weekdays || []);
  const dlg = createSheet(`
    <div class="sheet__header"><h2>${existing ? 'Termin bearbeiten' : 'Neuer Termin'}</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <form id="appt-form">
      <div class="field"><label for="a-title">Titel</label><input id="a-title" required value="${existing ? escapeHtml(existing.title) : ''}" /></div>
      <div class="field"><label for="a-date">${recurring ? 'Startdatum' : 'Datum'}</label><input id="a-date" type="date" required value="${existing?.date || defaultDate || todayIso()}" /></div>
      <div class="field-row">
        <div class="field"><label for="a-start">Startzeit</label><input id="a-start" type="time" required value="${existing?.startTime || '09:00'}" /></div>
        <div class="field"><label for="a-end">Endzeit</label><input id="a-end" type="time" value="${existing?.endTime || ''}" /></div>
      </div>
      <div class="field"><label for="a-note">Notiz (optional)</label><textarea id="a-note">${existing ? escapeHtml(existing.note || '') : ''}</textarea></div>

      <div class="checkbox-row"><input type="checkbox" id="a-recurring" ${recurring ? 'checked' : ''} /><label for="a-recurring">Wiederholt sich wöchentlich</label></div>
      <div id="a-recurrence-host" style="display:${recurring ? 'block' : 'none'}">
        <div class="weekday-picker">
          ${WEEKDAY_SHORT_LABELS.map((label, i) => `<button type="button" class="weekday-chip ${selectedWeekdays.has(i + 1) ? 'is-active' : ''}" data-weekday="${i + 1}">${label}</button>`).join('')}
        </div>
        <button type="button" class="btn btn-ghost btn-block" id="a-weekdays-preset" style="margin-bottom:var(--sp-3)">Werktage (Mo–Fr) wählen</button>
        <p class="field-hint" style="margin-top:calc(-1 * var(--sp-2));margin-bottom:var(--sp-3)">Der Termin gilt ab dem oben gewählten Startdatum jede Woche an den ausgewählten Tagen.</p>
      </div>

      <div class="field-error" id="a-error" hidden></div>
      <button class="btn btn-primary btn-block" type="submit">${icon('check')} Speichern</button>
      ${existing ? `<button class="btn btn-danger btn-block" type="button" id="a-delete" style="margin-top:var(--sp-3)">${icon('trash')} Löschen</button>` : ''}
    </form>
  `);

  const recurrenceHost = dlg.querySelector('#a-recurrence-host');
  dlg.querySelector('#a-recurring').addEventListener('change', (e) => { recurrenceHost.style.display = e.target.checked ? 'block' : 'none'; });
  dlg.querySelector('#a-weekdays-preset').addEventListener('click', () => {
    dlg.querySelectorAll('[data-weekday]').forEach((chip) => {
      const wd = Number(chip.dataset.weekday);
      chip.classList.toggle('is-active', wd >= 1 && wd <= 5);
    });
  });
  dlg.querySelectorAll('[data-weekday]').forEach((chip) => chip.addEventListener('click', () => chip.classList.toggle('is-active')));

  dlg.querySelector('#appt-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = dlg.querySelector('#a-title').value.trim();
    const date = dlg.querySelector('#a-date').value;
    const startTime = dlg.querySelector('#a-start').value;
    const endTime = dlg.querySelector('#a-end').value;
    const note = dlg.querySelector('#a-note').value.trim();
    const errEl = dlg.querySelector('#a-error');
    if (!title || !date || !startTime) {
      errEl.textContent = 'Bitte Titel, Datum und Startzeit angeben.';
      errEl.hidden = false;
      return;
    }
    if (endTime && endTime <= startTime) {
      errEl.textContent = 'Die Endzeit muss nach der Startzeit liegen.';
      errEl.hidden = false;
      return;
    }
    const isRecurring = dlg.querySelector('#a-recurring').checked;
    const weekdays = Array.from(dlg.querySelectorAll('[data-weekday].is-active')).map((c) => Number(c.dataset.weekday));
    if (isRecurring && !weekdays.length) {
      errEl.textContent = 'Bitte mindestens einen Wochentag für die Wiederholung auswählen.';
      errEl.hidden = false;
      return;
    }
    const recurrence = isRecurring ? { weekdays } : null;
    await saveAppointment({ id: existing?.id, title, date, startTime, endTime, note, recurrence });
    toast('Termin gespeichert');
    dlg.close();
    refresh();
  });

  if (existing) {
    dlg.querySelector('#a-delete').addEventListener('click', async () => {
      if (!confirm(recurring ? 'Diesen wiederkehrenden Termin wirklich löschen? Alle zukünftigen Vorkommen werden entfernt.' : 'Termin wirklich löschen?')) return;
      await deleteAppointment(existing.id);
      toast('Termin gelöscht');
      dlg.close();
      refresh();
    });
  }
}

function openBirthdayForm(refresh) {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Geburtstag hinzufügen</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <form id="bday-form">
      <div class="field"><label for="b-name">Name</label><input id="b-name" required /></div>
      <div class="field-row">
        <div class="field"><label for="b-day">Tag</label><input id="b-day" type="number" min="1" max="31" required /></div>
        <div class="field"><label for="b-month">Monat</label>
          <select id="b-month" required>
            ${['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember']
              .map((m, i) => `<option value="${i + 1}">${m}</option>`).join('')}
          </select>
        </div>
      </div>
      <p class="field-hint">Ein Geburtsjahr wird nicht benötigt – der Geburtstag wiederholt sich automatisch jedes Jahr.</p>
      <div class="field-error" id="b-error" hidden></div>
      <button class="btn btn-primary btn-block" type="submit">${icon('check')} Speichern</button>
    </form>
  `);

  dlg.querySelector('#bday-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = dlg.querySelector('#b-name').value.trim();
    const day = Number(dlg.querySelector('#b-day').value);
    const month = Number(dlg.querySelector('#b-month').value);
    const errEl = dlg.querySelector('#b-error');
    if (!name || !day || day < 1 || day > 31) {
      errEl.textContent = 'Bitte Namen und einen gültigen Tag angeben.';
      errEl.hidden = false;
      return;
    }
    await saveBirthday({ name, day, month });
    toast('Geburtstag gespeichert');
    dlg.close();
    refresh();
  });
}

async function openEntryDetail(id, type, refresh) {
  if (type === 'appointment') {
    const appt = (await getAppointments()).find((a) => a.id === id);
    if (appt) openAppointmentForm(refresh, appt.date, appt);
    return;
  }
  if (type === 'birthday') {
    const b = (await getBirthdays()).find((x) => x.id === id);
    if (!b) return;
    const dlg = createSheet(`
      <div class="sheet__header"><h2>${icon('cake')} ${escapeHtml(b.name)}</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
      <p>Geburtstag am ${String(b.day).padStart(2, '0')}.${String(b.month).padStart(2, '0')} (jährlich wiederkehrend)</p>
      <button class="btn btn-danger btn-block" id="b-delete">${icon('trash')} Löschen</button>
    `);
    dlg.querySelector('#b-delete').addEventListener('click', async () => {
      await deleteBirthday(b.id);
      toast('Geburtstag gelöscht');
      dlg.close();
      refresh();
    });
  }
}

function createSheet(innerHtml) {
  const dlg = document.createElement('dialog');
  dlg.className = 'sheet';
  dlg.innerHTML = `<div class="sheet__handle"></div><div class="sheet__body">${innerHtml}</div>`;
  document.body.appendChild(dlg);
  dlg.addEventListener('close', () => dlg.remove());
  dlg.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => dlg.close()));
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  dlg.showModal();
  return dlg;
}
