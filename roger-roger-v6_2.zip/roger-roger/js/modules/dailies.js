/**
 * dailies.js – "Dailies": wiederkehrende Tagesaufgaben auf dem Dashboard (V1.5).
 *
 * Datenmodell bewusst in zwei Stores getrennt (siehe docs/README.md, Prinzip
 * "Modul greift nie direkt auf fremde Daten zu, sondern über die eigene API"):
 * - `dailies`            – die Aufgabe selbst (Titel, aktiv/inaktiv, Wiederholungsart, Erstellungsdatum)
 * - `dailyCompletions`   – Erledigungsstatus je Tag (id = `${dailyId}__${date}`)
 *
 * Der Tageswechsel muss dadurch nirgends aktiv "zurückgesetzt" werden: ein
 * neuer Kalendertag hat schlicht noch keinen Completion-Eintrag und gilt
 * damit automatisch wieder als offen. Alte Completion-Einträge bleiben
 * erhalten (Grundlage für eine spätere Statistik/Streak-Auswertung).
 *
 * `repeat: 'daily'` ist in V1.5 der einzige Wert, aber als eigenes Feld
 * angelegt, damit später z.B. 'weekly' oder ein Wochentags-Array ergänzt
 * werden kann, ohne den Store neu zu strukturieren. Dieses Modul stellt
 * bewusst kein eigenes `render(container)` für eine Vollseite bereit, da
 * Dailies laut Auftrag nur auf dem Dashboard erscheinen sollen.
 */
import { db } from '../core/db.js';
import { icon } from '../core/icons.js';
import { uid, todayIso, escapeHtml, toast } from '../core/utils.js';

const S = db.STORES;

/* ---------------- Datenzugriff ---------------- */

export async function getDailies() {
  const rows = await db.getAll(S.dailies);
  return rows.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
}

export async function getActiveDailies() {
  return (await getDailies()).filter((d) => d.active !== false);
}

export async function addDaily(title) {
  const row = { id: uid(), title: title.trim(), active: true, repeat: 'daily', createdAt: Date.now() };
  await db.put(S.dailies, row);
  return row;
}

/** Für spätere Erweiterung vorbereitet (V1.5 hat dafür bewusst keine eigene UI, nur Löschen). */
export async function setDailyActive(id, active) {
  const row = await db.get(S.dailies, id);
  if (!row) return;
  await db.put(S.dailies, { ...row, active });
}

export async function deleteDaily(id) {
  await db.remove(S.dailies, id);
  const completions = await db.getAll(S.dailyCompletions);
  await Promise.all(
    completions.filter((c) => c.dailyId === id).map((c) => db.remove(S.dailyCompletions, c.id))
  );
}

export async function getCompletionsForDate(date = todayIso()) {
  const rows = await db.getAll(S.dailyCompletions);
  return rows.filter((c) => c.date === date && c.done);
}

export async function setDailyDone(dailyId, date, done) {
  const id = completionId(dailyId, date);
  if (done) await db.put(S.dailyCompletions, { id, dailyId, date, done: true });
  else await db.remove(S.dailyCompletions, id);
}

function completionId(dailyId, date) {
  return `${dailyId}__${date}`;
}

/* ---------------- Dashboard-Integration ---------------- */

/** Liefert das HTML für den Dailies-Bereich. `doneIds` ist ein Set erledigter daily-IDs für heute. */
export function renderSection(dailies, doneIds) {
  return `
    <div class="section-title">
      <h2>Dailies</h2>
      <button class="btn-icon" id="add-daily-btn" aria-label="Neue Daily anlegen">${icon('plus')}</button>
    </div>
    ${dailies.length
      ? `<div class="list daily-list" id="daily-list">${dailies.map((d) => dailyRow(d, doneIds.has(d.id))).join('')}</div>`
      : `<div class="empty-state"><p>Noch keine Dailies angelegt. Leg dir eine tägliche Aufgabe an – z.B. „Tägliches Dehnen".</p></div>`}
  `;
}

function dailyRow(d, done) {
  return `
    <div class="daily-row ${done ? 'is-done' : ''}" data-daily-row="${d.id}">
      <button class="daily-check" data-daily-toggle="${d.id}" aria-pressed="${done}" aria-label="${done ? 'Als offen markieren' : 'Als erledigt markieren'}">
        ${done ? icon('check') : ''}
      </button>
      <span class="daily-row__title">${escapeHtml(d.title)}</span>
      <button class="btn-icon daily-row__delete" data-daily-delete="${d.id}" aria-label="Daily löschen">${icon('trash')}</button>
    </div>`;
}

/** Bindet die Events für einen bereits ins DOM eingefügten Dailies-Bereich. `onChange` wird nach jeder Änderung aufgerufen. */
export function attachHandlers(container, onChange) {
  const addBtn = container.querySelector('#add-daily-btn');
  if (addBtn) addBtn.addEventListener('click', () => openAddSheet(onChange));

  container.querySelectorAll('[data-daily-toggle]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.dailyToggle;
      const currentlyDone = btn.getAttribute('aria-pressed') === 'true';
      await setDailyDone(id, todayIso(), !currentlyDone);
      onChange();
    });
  });

  container.querySelectorAll('[data-daily-delete]').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm('Diese Daily wirklich löschen?')) return;
      await deleteDaily(btn.dataset.dailyDelete);
      toast('Daily gelöscht');
      onChange();
    });
  });
}

function openAddSheet(onChange) {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Neue Daily</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <form id="daily-form">
      <div class="field">
        <label for="daily-title">Titel</label>
        <input id="daily-title" type="text" maxlength="60" placeholder="z.B. Tägliches Dehnen" required autofocus />
      </div>
      <button class="btn btn-primary btn-block" type="submit">${icon('check')} Anlegen</button>
    </form>
  `);
  dlg.querySelector('#daily-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = dlg.querySelector('#daily-title').value.trim();
    if (!title) return;
    await addDaily(title);
    toast('Daily angelegt');
    dlg.close();
    onChange();
  });
}

function createSheet(innerHtml) {
  const dlg = document.createElement('dialog');
  dlg.className = 'sheet';
  dlg.innerHTML = `<div class="sheet__handle"></div><div class="sheet__body">${innerHtml}</div>`;
  document.body.appendChild(dlg);
  dlg.addEventListener('close', () => dlg.remove());
  dlg.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => dlg.close()));
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  dlg.showModal();
  return dlg;
}
