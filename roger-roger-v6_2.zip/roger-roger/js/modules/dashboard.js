import { icon } from '../core/icons.js';
import {
  todayIso, startOfWeek, weekDays, isSameDay, greetingForTime, formatDateLong, escapeHtml,
} from '../core/utils.js';
import { navigate } from '../core/router.js';
import { getActiveModulesSorted, setModuleOrder } from '../core/moduleRegistry.js';
import * as calendarModule from './calendar.js';
import * as dailies from './dailies.js';
import * as steps from './steps.js';
import * as notes from './notes.js';
import {
  getUserName, getBackgrounds, getActiveBackgroundId, setActiveBackgroundId,
  isAutoBackgroundEnabled, rotateToNextBackground,
} from './settings.js';

let hasRotatedThisLoad = false;

export async function render(container) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());

  if (!hasRotatedThisLoad) {
    hasRotatedThisLoad = true;
    if (await isAutoBackgroundEnabled()) await rotateToNextBackground();
  }

  const [name, backgrounds, activeBgId, modules, today, dailyList, doneToday, stepsToday, recentNotes] = await Promise.all([
    getUserName(), getBackgrounds(), getActiveBackgroundId(), getActiveModulesSorted(), Promise.resolve(new Date()),
    dailies.getActiveDailies(), dailies.getCompletionsForDate(), steps.getStepsForDate(), notes.getRecentNotes(3),
  ]);
  const activeBg = backgrounds.find((b) => b.id === activeBgId) || backgrounds[0];
  const monday = startOfWeek(today);
  const days = weekDays(monday);
  const entriesPerDay = await Promise.all(days.map((d) => calendarModule.getEntriesForDate(d)));
  const doneIds = new Set(doneToday.map((c) => c.dailyId));

  container.innerHTML = `
    <div class="dashboard-scene">
      ${activeBg ? `<div class="dashboard-scene__bg" style="background-image:url(${URL.createObjectURL(activeBg.imageBlob)})"></div>` : ''}
      <div class="dashboard-scene__overlay"></div>
      <div class="dashboard-scene__content">
        <div class="hero">
          <div class="hero__actions">
            ${backgrounds.length > 1 ? `<button class="btn-icon" id="next-bg-btn" aria-label="Nächstes Hintergrundbild">${icon('image')}</button>` : ''}
            <button class="btn-icon" id="goto-settings-btn" aria-label="Einstellungen">${icon('settings')}</button>
          </div>
          <div class="hero__dial"><span class="hero__dial-dot"></span> ROGER ROGER</div>
          <div class="hero__greeting">${greetingForTime(today)}${name ? `, ${escapeHtml(name)}` : ''}</div>
          <div class="hero__date">${formatDateLong(todayIso())}</div>
        </div>

        ${dailies.renderSection(dailyList, doneIds)}

        ${steps.renderSection(stepsToday)}

        <div class="divider-dial"></div>

        <div class="section-title"><h2>Diese Woche</h2><button class="btn btn-ghost" id="open-calendar-btn">Kalender öffnen</button></div>
        <div class="week-strip">
          ${days.map((d, i) => weekDayCell(d, entriesPerDay[i], today, i)).join('')}
        </div>
        <div id="week-day-detail" class="week-day-detail" hidden></div>

        ${recentNotes.length ? `
        <div class="divider-dial"></div>
        <div class="section-title"><h2>📝 Zuletzt bearbeitet</h2></div>
        <div class="list" id="recent-notes-list">
          ${recentNotes.map((n) => `<button class="recent-note-row" data-recent-note="${n.id}">${escapeHtml(n.title || 'Ohne Titel')}</button>`).join('')}
        </div>` : ''}

        <div class="divider-dial"></div>

        <div class="section-title"><h2>Module</h2></div>
        ${modules.length ? `<div class="module-grid" id="module-grid">${modules.map(moduleTile).join('')}</div>` : `
          <div class="empty-state">${icon('home')}<p>Alle Module sind deaktiviert. Aktiviere sie in den Einstellungen.</p></div>`}
      </div>
    </div>
  `;

  container.querySelector('#goto-settings-btn').addEventListener('click', () => navigate('settings'));
  container.querySelector('#open-calendar-btn').addEventListener('click', () => navigate('calendar'));
  container.querySelectorAll('[data-recent-note]').forEach((btn) => {
    btn.addEventListener('click', () => navigate('notes', { id: btn.dataset.recentNote }));
  });
  const nextBgBtn = container.querySelector('#next-bg-btn');
  if (nextBgBtn) nextBgBtn.addEventListener('click', async () => { await rotateToNextBackground(); render(container); });

  // V4.0: Tag antippen klappt eine Detailansicht direkt im Dashboard auf, statt zum
  // Kalender zu navigieren. Der blaue Punkt / die bestehende Wochenstreifen-Darstellung
  // bleibt dabei unverändert (siehe weekDayCell) – "Kalender öffnen" führt weiterhin zur Vollansicht.
  const detailHost = container.querySelector('#week-day-detail');
  container.querySelectorAll('[data-day-cell]').forEach((cell) => {
    cell.addEventListener('click', () => {
      const idx = Number(cell.dataset.dayIndex);
      const isAlreadyOpen = cell.classList.contains('is-selected');
      container.querySelectorAll('.week-day.is-selected').forEach((c) => c.classList.remove('is-selected'));
      if (isAlreadyOpen) { detailHost.hidden = true; detailHost.innerHTML = ''; return; }
      cell.classList.add('is-selected');
      const dateObj = days[idx];
      const entries = entriesPerDay[idx];
      const isToday = isSameDay(dateObj, today);
      detailHost.hidden = false;
      detailHost.innerHTML = `
        <div class="week-day-detail__head">${isToday ? 'Heute' : dateObj.toLocaleDateString('de-DE', { weekday: 'long' })}, ${dateObj.toLocaleDateString('de-DE', { day: '2-digit', month: 'long' })}</div>
        ${entries.length ? entries.map(calendarModule.entryLine).join('') : '<p class="field-hint">Keine Einträge</p>'}
      `;
    });
  });
  container.querySelectorAll('[data-module-tile]').forEach((tile) => {
    tile.addEventListener('click', (e) => { if (!tile.classList.contains('is-dragging')) navigate(tile.dataset.moduleTile); });
  });

  setupModuleDragDrop(container);

  dailies.attachHandlers(container, () => render(container));
  steps.attachHandlers(container, () => render(container));
}

function weekDayCell(dateObj, entries, today, index) {
  // Darstellung bewusst unverändert gegenüber v1.0/v1.5 (siehe CLAUDE.md, V4.0-Auftrag
  // Abschnitt 11): der dezente Punkt bleibt der einzige Indikator, nur der Klick-Handler
  // (siehe render()) wurde von "zum Kalender navigieren" zu "Tag ausklappen" geändert.
  const isToday = isSameDay(dateObj, today);
  const hasBirthday = entries.some((e) => e.type === 'birthday');
  const hasOther = entries.some((e) => e.type !== 'birthday');
  return `
    <div class="week-day ${isToday ? 'is-today' : ''}" data-day-cell data-day-index="${index}">
      <span class="week-day__label">${dateObj.toLocaleDateString('de-DE', { weekday: 'short' })}</span>
      <span class="week-day__num">${dateObj.getDate()}</span>
      <span class="week-day__dots">
        ${hasOther ? '<span class="week-day__dot"></span>' : ''}
        ${hasBirthday ? '<span class="week-day__dot week-day__dot--birthday"></span>' : ''}
      </span>
    </div>`;
}

function moduleTile(mod) {
  return `
    <div class="module-tile" draggable="true" data-module-tile="${mod.id}" data-module-id="${mod.id}">
      <span class="module-tile__icon">${icon(mod.icon)}</span>
      <div>
        <div class="module-tile__title">${escapeHtml(mod.label)}</div>
      </div>
    </div>`;
}

function setupModuleDragDrop(container) {
  const grid = container.querySelector('#module-grid');
  if (!grid) return;
  let dragEl = null;
  grid.querySelectorAll('.module-tile').forEach((tile) => {
    tile.addEventListener('dragstart', () => { dragEl = tile; tile.classList.add('is-dragging'); });
    tile.addEventListener('dragend', () => { tile.classList.remove('is-dragging'); dragEl = null; persistOrder(grid); });
    tile.addEventListener('dragover', (e) => {
      e.preventDefault();
      if (!dragEl || dragEl === tile) return;
      const rect = tile.getBoundingClientRect();
      const before = e.clientX < rect.left + rect.width / 2;
      grid.insertBefore(dragEl, before ? tile : tile.nextSibling);
    });
  });
}

async function persistOrder(grid) {
  const ids = Array.from(grid.querySelectorAll('.module-tile')).map((t) => t.dataset.moduleId);
  await setModuleOrder(ids);
}
