import { db } from '../core/db.js';
import { icon } from '../core/icons.js';
import { uid, escapeHtml, toast } from '../core/utils.js';
import { bytesToB64, b64ToBytes, deriveKeyFromPin, encryptJSON, decryptJSON } from '../core/crypto.js';

const S = db.STORES;

/* ================= Konstanten ================= */

// Kategorien bewusst als einfaches, leicht erweiterbares Array (kein eigener DB-Store wie
// beim Quiz) – eine Notiz speichert nur die category-id als String, neue Kategorien lassen
// sich hier jederzeit ergänzen, ohne Datenmodell/Migration anzufassen.
export const NOTE_CATEGORIES = [
  { id: 'gaming', label: 'Gaming', emoji: '🎮' },
  { id: 'filme', label: 'Filme & Serien', emoji: '🎬' },
  { id: 'einkauf', label: 'Einkauf', emoji: '🛒' },
  { id: 'ideen', label: 'Ideen', emoji: '💡' },
  { id: 'sonstiges', label: 'Sonstiges', emoji: '📌' },
];
const DEFAULT_CATEGORY = 'sonstiges';

const WATCH_TYPES = [
  { id: 'movie', label: 'Film', emoji: '🎬' },
  { id: 'series', label: 'Serie', emoji: '📺' },
];
const WATCH_STATUSES = [
  { id: 'todo', label: 'Noch schauen' },
  { id: 'seen', label: 'Gesehen' },
];
const NO_GENRE_LABEL = 'Ohne Genre';

// Feste Genre-Liste für die Watchlist (löst das frühere Freitextfeld ab). Die Reihenfolge
// hier ist absichtlich vorgegeben (nicht alphabetisch) und bestimmt zugleich die Reihenfolge
// der Genre-Gruppen in der Ansicht (siehe genreSortKey/watchStatusSection). Alte, aus der
// Freitext-Ära stammende Genre-Werte, die hier nicht (mehr) vorkommen, werden nicht migriert
// oder gelöscht, sondern weiterhin unterstützt angezeigt (siehe openWatchSheet).
export const WATCH_GENRES = [
  'Drama',
  'Action & Abenteuer',
  'Fantasy & Mythos',
  'Science-Fiction & Zukunft',
  'Horror & Mystery',
  'Komödie',
  'Krimi & Thriller',
  'Historisch & Gesellschaftlich',
];

const SECURE_AUTH_KEY = 'notesSecureAuth'; // liegt im settings-Store: { salt, verifierCipher, verifierIv } – NIEMALS der PIN selbst
const SECURE_VERIFIER_OK = 'roger-roger-secure-v1';
const SECURE_IDLE_LOCK_MS = 2 * 60 * 1000; // 2 Minuten Inaktivität sperren (siehe CLAUDE.md, vereinfachte Umsetzung)
const MIN_PIN_LENGTH = 4;

/* ================= Web-Crypto (AES-GCM, PBKDF2) =================
 * Seit V5.2 in core/crypto.js ausgelagert, da settings.js (App-Daten-Backup) dieselbe
 * Verschlüsselung wiederverwendet, statt eine zweite Implementierung zu bauen (siehe
 * dort). Hier nur noch importiert, keine lokale Logik mehr.
 */

/* ================= "Sicher" – Auth-Status (nur im Arbeitsspeicher!) ================= */

let secureKey = null;      // CryptoKey, NIE persistiert – existiert nur solange der Bereich entsperrt ist
let secureIdleTimer = null;

export function isSecureUnlocked() { return !!secureKey; }

/** Exportiert, damit settings.js (V5.2, App-Daten-Backup) prüfen kann, ob "Sicher" eingerichtet
 * ist und – mit vom Nutzer eingegebener PIN – denselben Schlüssel für die optionale
 * Backup-Verschlüsselung ableiten kann. Gibt niemals den PIN selbst preis, nur Salt + Verifier
 * (wie ohnehin schon in der DB gespeichert). */
export async function getSecureAuthConfig() {
  const row = await db.get(S.settings, SECURE_AUTH_KEY);
  return row?.value || null;
}

export async function hasSecurePin() { return !!(await getSecureAuthConfig()); }

export async function setupSecurePin(pin) {
  const saltBytes = crypto.getRandomValues(new Uint8Array(16));
  const key = await deriveKeyFromPin(pin, saltBytes);
  const verifier = await encryptJSON(key, { ok: SECURE_VERIFIER_OK });
  await db.put(S.settings, {
    key: SECURE_AUTH_KEY,
    value: { salt: bytesToB64(saltBytes), verifierCipher: verifier.cipher, verifierIv: verifier.iv },
  });
  secureKey = key;
  armIdleTimer();
}

export async function tryUnlockSecure(pin) {
  const cfg = await getSecureAuthConfig();
  if (!cfg) return false;
  try {
    const key = await deriveKeyFromPin(pin, b64ToBytes(cfg.salt));
    const result = await decryptJSON(key, cfg.verifierCipher, cfg.verifierIv);
    if (result?.ok !== SECURE_VERIFIER_OK) return false;
    secureKey = key;
    armIdleTimer();
    return true;
  } catch (e) {
    return false; // falscher PIN -> AES-GCM-Entschlüsselung schlägt fehl (Authentifizierungstag passt nicht)
  }
}

export function lockSecure() {
  secureKey = null;
  clearIdleTimer();
}

/** PIN vergessen: kompletter, unwiderruflicher Reset. Kein Master-Bypass, kein Hintereingang. */
export async function resetSecure() {
  lockSecure();
  await db.clear(S.secureNotes);
  await db.remove(S.settings, SECURE_AUTH_KEY);
}

function armIdleTimer() {
  clearIdleTimer();
  secureIdleTimer = setTimeout(() => { lockSecure(); }, SECURE_IDLE_LOCK_MS);
}
function clearIdleTimer() {
  if (secureIdleTimer) clearTimeout(secureIdleTimer);
  secureIdleTimer = null;
}
function bumpIdleTimer() { if (secureKey) armIdleTimer(); }

/* ================= "Sicher" – Notizen-CRUD (nur bei entsperrtem Bereich) ================= */

async function listSecureNotesDecrypted() {
  if (!secureKey) return [];
  const rows = await db.getAll(S.secureNotes);
  const decrypted = await Promise.all(rows.map(async (r) => {
    try {
      const data = await decryptJSON(secureKey, r.cipher, r.iv);
      return { id: r.id, createdAt: r.createdAt, updatedAt: r.updatedAt, ...data };
    } catch (e) {
      return null;
    }
  }));
  return decrypted.filter(Boolean).sort((a, b) => b.updatedAt - a.updatedAt);
}

async function getSecureNoteDecrypted(id) {
  if (!secureKey) return null;
  const row = await db.get(S.secureNotes, id);
  if (!row) return null;
  try {
    const data = await decryptJSON(secureKey, row.cipher, row.iv);
    return { id: row.id, createdAt: row.createdAt, updatedAt: row.updatedAt, ...data };
  } catch (e) {
    return null;
  }
}

async function saveSecureNote(note) {
  if (!secureKey) throw new Error('Geschützter Bereich ist gesperrt');
  const now = Date.now();
  const id = note.id || uid();
  const createdAt = note.createdAt || now;
  const data = {
    title: note.title,
    body: note.body,
    category: note.category || DEFAULT_CATEGORY,
    isChecklist: !!note.isChecklist,
    checklistItems: note.isChecklist ? (note.checklistItems || []) : undefined,
  };
  if (!data.isChecklist) delete data.checklistItems;
  const { cipher, iv } = await encryptJSON(secureKey, data);
  await db.put(S.secureNotes, { id, cipher, iv, createdAt, updatedAt: now });
  bumpIdleTimer();
  return { id, createdAt, updatedAt: now, ...data };
}

async function deleteSecureNote(id) {
  await db.remove(S.secureNotes, id);
  bumpIdleTimer();
}

/* ================= Normale Notizen ================= */

export async function getNotes() {
  const rows = await db.getAll(S.notes);
  return rows.sort((a, b) => b.updatedAt - a.updatedAt);
}
export async function getNote(id) { return db.get(S.notes, id); }

export async function saveNote(note) {
  const now = Date.now();
  const row = {
    ...note,
    id: note.id || uid(),
    category: note.category || DEFAULT_CATEGORY,
    isChecklist: !!note.isChecklist,
    checklistItems: note.isChecklist ? (note.checklistItems || []) : undefined,
    createdAt: note.createdAt || now,
    updatedAt: now,
  };
  if (!row.isChecklist) delete row.checklistItems;
  await db.put(S.notes, row);
  return row;
}
export async function deleteNote(id) { await db.remove(S.notes, id); }

/** Für das Dashboard: zuletzt bearbeitete normale Notizen (Sicher bleibt bewusst außen vor). */
export async function getRecentNotes(limit = 3) {
  const all = await getNotes();
  return all.slice(0, limit);
}

function searchableText(note) {
  const extra = note.isChecklist ? (note.checklistItems || []).map((i) => i.text).join(' ') : (note.body || '');
  return `${note.title || ''} ${extra}`.toLowerCase();
}

/* ================= Filme & Serien (Watchlist) ================= */

export async function getWatchlist() { return db.getAll(S.watchlist); }
export async function getWatchItem(id) { return db.get(S.watchlist, id); }
export async function saveWatchItem(item) {
  const now = Date.now();
  const row = { ...item, id: item.id || uid(), createdAt: item.createdAt || now, updatedAt: now };
  await db.put(S.watchlist, row);
  return row;
}
export async function deleteWatchItem(id) { await db.remove(S.watchlist, id); }

/* ================= UI: Dispatch ================= */

const VIEWS = [
  { id: 'notes', label: '📝 Notizen' },
  { id: 'movies', label: '🎬 Filme & Serien' },
  { id: 'secure', label: '🔒 Sicher' },
];

export async function render(container, params = {}) {
  const view = ['notes', 'movies', 'secure'].includes(params.view) ? params.view : 'notes';
  if (view === 'notes' && params.id) {
    await renderEditor(container, params.id === 'new' ? null : params.id);
  } else if (view === 'movies') {
    await renderMoviesTab(container, '');
  } else if (view === 'secure') {
    await renderSecureTab(container);
  } else {
    await renderNotesList(container, '');
  }
  // Lockt "Sicher" zuverlässig, sobald der Nutzer das gesamte Notizen-Modul verlässt
  // (der Router ruft diese Funktion beim nächsten Routenwechsel auf, siehe router.js).
  return () => { lockSecure(); };
}

function tabsHtml(activeView) {
  return `
    <div class="tabs" role="tablist">
      ${VIEWS.map((v) => `<button class="tabs__btn ${v.id === activeView ? 'is-active' : ''}" data-notes-view="${v.id}">${v.label}</button>`).join('')}
    </div>`;
}

function installTabs(container) {
  container.querySelectorAll('[data-notes-view]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const view = btn.dataset.notesView;
      if (view === 'movies') renderMoviesTab(container, '');
      else if (view === 'secure') renderSecureTab(container);
      else renderNotesList(container, '');
    });
  });
}

function installFab(container, onClick, label) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  const fab = document.createElement('button');
  fab.className = 'fab';
  fab.setAttribute('aria-label', label);
  fab.innerHTML = icon('plus');
  fab.addEventListener('click', onClick);
  document.body.appendChild(fab);
}

function categoryInfo(id) { return NOTE_CATEGORIES.find((c) => c.id === id) || NOTE_CATEGORIES.find((c) => c.id === DEFAULT_CATEGORY); }

/* ================= UI: Normale Notizen ================= */

async function renderNotesList(container, query) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  const all = await getNotes();
  const notes = query ? all.filter((n) => searchableText(n).includes(query.toLowerCase())) : all;

  container.innerHTML = `
    <h1>Notizen</h1>
    ${tabsHtml('notes')}
    <div class="field notes-search">
      <input type="search" id="notes-search-input" placeholder="Notizen durchsuchen …" value="${escapeHtml(query)}" />
    </div>
    <div class="list" id="notes-list">
      ${notes.length ? notes.map(noteCard).join('') : emptyState(query ? 'Keine Treffer.' : 'Noch keine Notizen. Tippe auf +, um deine erste Notiz zu erstellen.')}
    </div>
  `;
  installTabs(container);
  installFab(container, () => renderEditor(container, null), 'Neue Notiz');

  const searchInput = container.querySelector('#notes-search-input');
  searchInput.addEventListener('input', debounce(() => renderNotesList(container, searchInput.value), 200));

  container.querySelectorAll('[data-open-note]').forEach((card) => {
    card.addEventListener('click', () => renderEditor(container, card.dataset.openNote));
  });
}

function noteCard(note) {
  const date = new Date(note.updatedAt).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const cat = categoryInfo(note.category);
  const snippet = note.isChecklist
    ? `${(note.checklistItems || []).filter((i) => i.done).length}/${(note.checklistItems || []).length} erledigt`
    : (note.body || '');
  return `
    <div class="card card--tab-corner" data-open-note="${note.id}" style="cursor:pointer">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">
        ${note.isChecklist ? icon('listChecks', 'note-card__icon') : ''}
        <div class="item-row__title" style="margin-bottom:0">${escapeHtml(note.title || 'Ohne Titel')}</div>
      </div>
      <div class="note-card__snippet">${escapeHtml(snippet)}</div>
      <div class="item-row__meta" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center">
        <span class="pill pill--accent">${cat.emoji} ${escapeHtml(cat.label)}</span>
        <span>${date}</span>
      </div>
    </div>`;
}

async function renderEditor(container, id) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  const note = id ? await getNote(id) : null;
  let currentId = note?.id || null;
  let isChecklist = !!note?.isChecklist;
  let items = note?.checklistItems ? [...note.checklistItems] : [];

  container.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--sp-4)">
      <button class="btn-icon" id="back-btn" aria-label="Zurück">${icon('chevronLeft')}</button>
      <div style="display:flex;gap:8px">
        ${note ? `<button class="btn-icon" id="delete-note-btn" aria-label="Löschen">${icon('trash')}</button>` : ''}
        <button class="btn-icon" id="save-note-btn" aria-label="Speichern">${icon('check')}</button>
      </div>
    </div>
    <input class="note-editor-title" id="note-title" placeholder="Titel" value="${note ? escapeHtml(note.title) : ''}" />
    <div class="field-row" style="margin-bottom:var(--sp-3)">
      <div class="field" style="margin-bottom:0">
        <select id="note-category">
          ${NOTE_CATEGORIES.map((c) => `<option value="${c.id}" ${(note?.category || DEFAULT_CATEGORY) === c.id ? 'selected' : ''}>${c.emoji} ${escapeHtml(c.label)}</option>`).join('')}
        </select>
      </div>
    </div>
    <label class="checkbox-row" style="margin-bottom:var(--sp-4)">
      <input type="checkbox" id="note-checklist-toggle" ${isChecklist ? 'checked' : ''} />
      Als Checkliste
    </label>
    <div id="note-body-host"></div>
    ${note ? `<button class="btn btn-ghost btn-block" id="protect-note-btn" style="margin-top:var(--sp-4)">${icon('lock')} In Sicher verschieben</button>` : ''}
  `;

  const titleEl = container.querySelector('#note-title');
  const categoryEl = container.querySelector('#note-category');
  const bodyHost = container.querySelector('#note-body-host');
  const checklistToggle = container.querySelector('#note-checklist-toggle');

  const persist = debounce(async () => {
    const title = titleEl.value.trim();
    const body = isChecklist ? '' : bodyEl?.value || '';
    if (!title && !body && !(isChecklist && items.length)) return;
    const saved = await saveNote({
      id: currentId, title: title || 'Ohne Titel', body, category: categoryEl.value, isChecklist, checklistItems: items,
    });
    currentId = saved.id;
    updateProtectButtonVisibility();
  }, 500);

  let bodyEl = null;
  function renderBodyArea() {
    if (isChecklist) {
      bodyHost.innerHTML = `<div id="checklist-host"></div>`;
      attachChecklistEditor(container.querySelector('#checklist-host'), items, (nextItems) => { items = nextItems; persist(); });
    } else {
      bodyHost.innerHTML = `<textarea class="note-editor-body" id="note-body" placeholder="Beginne zu schreiben …">${note && !note.isChecklist ? escapeHtml(note.body) : ''}</textarea>`;
      bodyEl = bodyHost.querySelector('#note-body');
      bodyEl.addEventListener('input', persist);
    }
  }
  renderBodyArea();

  function updateProtectButtonVisibility() {
    const btn = container.querySelector('#protect-note-btn');
    if (btn) btn.hidden = !currentId;
  }

  titleEl.addEventListener('input', persist);
  categoryEl.addEventListener('change', persist);
  checklistToggle.addEventListener('change', () => {
    isChecklist = checklistToggle.checked;
    if (isChecklist && !items.length) items = [];
    renderBodyArea();
    persist();
  });

  container.querySelector('#back-btn').addEventListener('click', async () => {
    const title = titleEl.value.trim();
    const body = isChecklist ? '' : (bodyEl?.value || '');
    if (title || body || (isChecklist && items.length)) {
      await saveNote({ id: currentId, title: title || 'Ohne Titel', body, category: categoryEl.value, isChecklist, checklistItems: items });
    }
    renderNotesList(container, '');
  });
  container.querySelector('#save-note-btn').addEventListener('click', async () => {
    const title = titleEl.value.trim();
    const body = isChecklist ? '' : (bodyEl?.value || '');
    const saved = await saveNote({ id: currentId, title: title || 'Ohne Titel', body, category: categoryEl.value, isChecklist, checklistItems: items });
    currentId = saved.id;
    updateProtectButtonVisibility();
    toast('Notiz gespeichert');
  });
  if (note) {
    container.querySelector('#delete-note-btn').addEventListener('click', async () => {
      if (!confirm('Notiz wirklich löschen?')) return;
      await deleteNote(note.id);
      toast('Notiz gelöscht');
      renderNotesList(container, '');
    });
    const protectBtn = container.querySelector('#protect-note-btn');
    protectBtn.addEventListener('click', () => {
      const doMove = async () => {
        const title = titleEl.value.trim() || 'Ohne Titel';
        const body = isChecklist ? '' : (bodyEl?.value || '');
        await saveSecureNote({ title, body, category: categoryEl.value, isChecklist, checklistItems: items });
        await deleteNote(currentId);
        toast('Notiz in "Sicher" verschoben');
        renderSecureTab(container);
      };
      if (isSecureUnlocked()) {
        if (confirm('Diese Notiz in den geschützten Bereich verschieben?')) doMove();
      } else {
        openSecureUnlockSheet(doMove);
      }
    });
  }
}

/* ================= UI: Checkliste (gemeinsam für normale + sichere Notizen) ================= */

function attachChecklistEditor(hostEl, items, onChange) {
  function renderRows() {
    hostEl.innerHTML = `
      <div class="list" id="checklist-items">
        ${items.map(checklistItemRow).join('')}
      </div>
      <div class="checklist-add-row">
        <input type="text" id="checklist-new-input" placeholder="Neuer Eintrag …" />
        <button class="btn-icon" id="checklist-add-btn" aria-label="Eintrag hinzufügen">${icon('plus')}</button>
      </div>
    `;
    hostEl.querySelectorAll('[data-check-item]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const item = items.find((i) => i.id === btn.dataset.checkItem);
        if (item) { item.done = !item.done; renderRows(); onChange(items); }
      });
    });
    hostEl.querySelectorAll('[data-item-text]').forEach((input) => {
      input.addEventListener('input', debounce(() => {
        const item = items.find((i) => i.id === input.dataset.itemText);
        if (item) { item.text = input.value; onChange(items); }
      }, 400));
    });
    hostEl.querySelectorAll('[data-del-item]').forEach((btn) => {
      btn.addEventListener('click', () => {
        items = items.filter((i) => i.id !== btn.dataset.delItem);
        renderRows();
        onChange(items);
      });
    });
    hostEl.querySelectorAll('[data-move-up]').forEach((btn) => {
      btn.addEventListener('click', () => { moveItem(btn.dataset.moveUp, -1); });
    });
    hostEl.querySelectorAll('[data-move-down]').forEach((btn) => {
      btn.addEventListener('click', () => { moveItem(btn.dataset.moveDown, 1); });
    });
    const newInput = hostEl.querySelector('#checklist-new-input');
    const addBtn = hostEl.querySelector('#checklist-add-btn');
    const addItem = () => {
      const text = newInput.value.trim();
      if (!text) return;
      items.push({ id: uid(), text, done: false });
      renderRows();
      onChange(items);
      hostEl.querySelector('#checklist-new-input')?.focus();
    };
    addBtn.addEventListener('click', addItem);
    newInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addItem(); } });
  }

  function moveItem(id, dir) {
    const i = items.findIndex((it) => it.id === id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= items.length) return;
    [items[i], items[j]] = [items[j], items[i]];
    renderRows();
    onChange(items);
  }

  renderRows();
}

function checklistItemRow(item, index, arr) {
  return `
    <div class="checklist-item">
      <button class="checklist-item__check ${item.done ? 'is-done' : ''}" data-check-item="${item.id}" aria-label="Abhaken">${item.done ? icon('check') : ''}</button>
      <input class="checklist-item__text" data-item-text="${item.id}" value="${escapeHtml(item.text)}" />
      <div class="checklist-item__moves">
        <button class="btn-icon" data-move-up="${item.id}" aria-label="Nach oben" ${index === 0 ? 'disabled' : ''}>${icon('chevronUp')}</button>
        <button class="btn-icon" data-move-down="${item.id}" aria-label="Nach unten" ${index === arr.length - 1 ? 'disabled' : ''}>${icon('chevronDown')}</button>
      </div>
      <button class="btn-icon checklist-item__del" data-del-item="${item.id}" aria-label="Löschen">${icon('x')}</button>
    </div>`;
}

/* ================= UI: Filme & Serien ================= */

async function renderMoviesTab(container, query) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  const all = await getWatchlist();
  const items = query
    ? all.filter((i) => `${i.name} ${i.genre || ''}`.toLowerCase().includes(query.toLowerCase()))
    : all;

  container.innerHTML = `
    <h1>Filme &amp; Serien</h1>
    ${tabsHtml('movies')}
    <div class="field notes-search">
      <input type="search" id="watch-search-input" placeholder="Filme &amp; Serien durchsuchen …" value="${escapeHtml(query)}" />
    </div>
    <div id="watch-list">
      ${items.length ? WATCH_STATUSES.map((s) => watchStatusSection(s, items)).join('') : emptyState(query ? 'Keine Treffer.' : 'Noch nichts auf der Watchlist. Tippe auf +, um einen Film oder eine Serie hinzuzufügen.')}
    </div>
  `;
  installTabs(container);
  installFab(container, () => openWatchSheet(container, null), 'Neuer Eintrag');

  const searchInput = container.querySelector('#watch-search-input');
  searchInput.addEventListener('input', debounce(() => renderMoviesTab(container, searchInput.value), 200));

  container.querySelectorAll('[data-open-watch]').forEach((row) => {
    row.addEventListener('click', async () => {
      const item = await getWatchItem(row.dataset.openWatch);
      openWatchSheet(container, item);
    });
  });
}

function watchStatusSection(status, allItems) {
  const items = allItems.filter((i) => i.status === status.id);
  if (!items.length) return '';
  const byGenre = {};
  items.forEach((i) => {
    const genre = (i.genre || '').trim() || NO_GENRE_LABEL;
    if (!byGenre[genre]) byGenre[genre] = [];
    byGenre[genre].push(i);
  });
  const genres = Object.keys(byGenre).sort((a, b) => genreSortKey(a) - genreSortKey(b) || a.localeCompare(b, 'de'));
  return `
    <div class="section-title"><h2>${escapeHtml(status.label)}</h2></div>
    ${genres.map((genre) => `
      <div class="watch-genre-label">${escapeHtml(genre)}</div>
      <div class="list" style="margin-bottom:var(--sp-4)">
        ${byGenre[genre].sort((a, b) => a.name.localeCompare(b.name, 'de')).map(watchRow).join('')}
      </div>
    `).join('')}
  `;
}

/** Sortierschlüssel für Genre-Gruppen: erst die 8 festen Genres in ihrer vorgegebenen
 * Reihenfolge (siehe WATCH_GENRES), danach alphabetisch alles andere (z.B. alte Freitext-Genres
 * aus v5.0), "Ohne Genre" ganz zuletzt. */
function genreSortKey(genre) {
  if (genre === NO_GENRE_LABEL) return WATCH_GENRES.length + 1;
  const idx = WATCH_GENRES.indexOf(genre);
  return idx === -1 ? WATCH_GENRES.length : idx;
}

function watchRow(item) {
  const typeInfo = WATCH_TYPES.find((t) => t.id === item.type) || WATCH_TYPES[0];
  return `
    <div class="item-row watch-row" data-open-watch="${item.id}" style="cursor:pointer">
      <span class="watch-row__icon">${icon(item.type === 'series' ? 'tv' : 'film')}</span>
      <div class="item-row__main">
        <div class="item-row__title">${escapeHtml(item.name)}</div>
        <div class="item-row__meta">${typeInfo.emoji} ${typeInfo.label}</div>
      </div>
      ${item.status === 'seen' && item.rating ? `<span class="pill pill--accent">${icon('star')} ${item.rating}/10</span>` : ''}
    </div>`;
}

function openWatchSheet(container, item) {
  let type = item?.type || 'movie';
  let status = item?.status || 'todo';
  let rating = item?.rating || null;

  const dlg = createSheet(`
    <div class="sheet__header"><h2>${item ? 'Eintrag bearbeiten' : 'Neuer Eintrag'}</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <div class="field">
      <label for="watch-name">Name</label>
      <input type="text" id="watch-name" value="${item ? escapeHtml(item.name) : ''}" placeholder="z.B. Dune" />
    </div>
    <div class="field">
      <label>Typ</label>
      <div class="tabs" id="watch-type-tabs">
        ${WATCH_TYPES.map((t) => `<button type="button" class="tabs__btn ${t.id === type ? 'is-active' : ''}" data-type="${t.id}">${t.emoji} ${t.label}</button>`).join('')}
      </div>
    </div>
    <div class="field">
      <label for="watch-genre">Genre</label>
      <select id="watch-genre">
        ${!item?.genre ? `<option value="">Genre wählen …</option>` : ''}
        ${WATCH_GENRES.map((g) => `<option value="${escapeHtml(g)}" ${item?.genre === g ? 'selected' : ''}>${escapeHtml(g)}</option>`).join('')}
        ${item && item.genre && !WATCH_GENRES.includes(item.genre) ? `<option value="${escapeHtml(item.genre)}" selected>${escapeHtml(item.genre)} (alt)</option>` : ''}
      </select>
    </div>
    <div class="field">
      <label>Status</label>
      <div class="tabs" id="watch-status-tabs">
        ${WATCH_STATUSES.map((s) => `<button type="button" class="tabs__btn ${s.id === status ? 'is-active' : ''}" data-status="${s.id}">${s.label}</button>`).join('')}
      </div>
    </div>
    <div class="field" id="watch-rating-field" ${status === 'seen' ? '' : 'hidden'}>
      <label for="watch-rating">Bewertung</label>
      <select id="watch-rating">
        <option value="">Keine Bewertung</option>
        ${Array.from({ length: 10 }, (_, i) => i + 1).map((n) => `<option value="${n}" ${rating === n ? 'selected' : ''}>${n}/10</option>`).join('')}
      </select>
    </div>
    <button class="btn btn-primary btn-block" id="watch-save-btn" style="margin-top:var(--sp-3)">${icon('check')} Speichern</button>
    ${item ? `<button class="btn btn-danger btn-block" id="watch-delete-btn" style="margin-top:var(--sp-3)">${icon('trash')} Löschen</button>` : ''}
  `);

  dlg.querySelectorAll('[data-type]').forEach((b) => b.addEventListener('click', () => {
    type = b.dataset.type;
    dlg.querySelectorAll('[data-type]').forEach((x) => x.classList.toggle('is-active', x === b));
  }));
  dlg.querySelectorAll('[data-status]').forEach((b) => b.addEventListener('click', () => {
    status = b.dataset.status;
    dlg.querySelectorAll('[data-status]').forEach((x) => x.classList.toggle('is-active', x === b));
    dlg.querySelector('#watch-rating-field').hidden = status !== 'seen';
  }));

  dlg.querySelector('#watch-save-btn').addEventListener('click', async () => {
    const name = dlg.querySelector('#watch-name').value.trim();
    if (!name) { toast('Bitte einen Namen eingeben', 'danger'); return; }
    const genre = dlg.querySelector('#watch-genre').value.trim();
    const ratingVal = status === 'seen' ? (Number(dlg.querySelector('#watch-rating').value) || null) : null;
    await saveWatchItem({ id: item?.id, name, type, genre, status, rating: ratingVal });
    dlg.close();
    toast('Gespeichert');
    renderMoviesTab(container, '');
  });
  if (item) {
    dlg.querySelector('#watch-delete-btn').addEventListener('click', async () => {
      if (!confirm('Eintrag wirklich löschen?')) return;
      await deleteWatchItem(item.id);
      dlg.close();
      toast('Eintrag gelöscht');
      renderMoviesTab(container, '');
    });
  }
}

/* ================= UI: Sicher ================= */

async function renderSecureTab(container) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  if (!isSecureUnlocked()) {
    const hasPin = await hasSecurePin();
    return hasPin ? renderPinEntry(container) : renderPinSetup(container);
  }
  bumpIdleTimer();
  const notes = await listSecureNotesDecrypted();
  container.innerHTML = `
    <h1>Sicher</h1>
    ${tabsHtml('secure')}
    <div style="display:flex;justify-content:flex-end;margin-bottom:var(--sp-3)">
      <button class="btn btn-secondary" id="lock-btn">${icon('lock')} Sperren</button>
    </div>
    <div class="list" id="secure-list">
      ${notes.length ? notes.map(secureNoteCard).join('') : emptyState('Noch keine geschützten Notizen.')}
    </div>
  `;
  installTabs(container);
  installFab(container, () => renderSecureEditor(container, null), 'Neue geschützte Notiz');

  container.querySelector('#lock-btn').addEventListener('click', () => {
    lockSecure();
    renderSecureTab(container);
  });
  container.querySelectorAll('[data-open-secure]').forEach((card) => {
    card.addEventListener('click', () => renderSecureEditor(container, card.dataset.openSecure));
  });
}

function secureNoteCard(note) {
  const date = new Date(note.updatedAt).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const cat = categoryInfo(note.category);
  const snippet = note.isChecklist
    ? `${(note.checklistItems || []).filter((i) => i.done).length}/${(note.checklistItems || []).length} erledigt`
    : (note.body || '');
  return `
    <div class="card card--tab-corner" data-open-secure="${note.id}" style="cursor:pointer">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">
        ${note.isChecklist ? icon('listChecks', 'note-card__icon') : ''}
        <div class="item-row__title" style="margin-bottom:0">${escapeHtml(note.title || 'Ohne Titel')}</div>
      </div>
      <div class="note-card__snippet">${escapeHtml(snippet)}</div>
      <div class="item-row__meta" style="margin-top:6px;display:flex;justify-content:space-between;align-items:center">
        <span class="pill pill--accent">${cat.emoji} ${escapeHtml(cat.label)}</span>
        <span>${date}</span>
      </div>
    </div>`;
}

function renderPinSetup(container) {
  container.innerHTML = `
    <h1>Sicher</h1>
    ${tabsHtml('secure')}
    <div class="empty-state" style="padding-top:var(--sp-5)">
      ${icon('lock')}
      <p>Richte eine PIN ein, um diesen Bereich zu schützen. Der geschützte Bereich ist für private Notizen gedacht – kein vollwertiger Passwortmanager.</p>
    </div>
    <div class="field">
      <label for="pin-new">PIN erstellen (mind. ${MIN_PIN_LENGTH} Ziffern)</label>
      <input type="password" inputmode="numeric" id="pin-new" placeholder="••••" />
    </div>
    <div class="field">
      <label for="pin-confirm">PIN bestätigen</label>
      <input type="password" inputmode="numeric" id="pin-confirm" placeholder="••••" />
    </div>
    <div class="field-error" id="pin-error" style="display:none"></div>
    <button class="btn btn-primary btn-block" id="pin-setup-btn">${icon('lock')} Bereich einrichten</button>
  `;
  installTabs(container);
  const errorEl = container.querySelector('#pin-error');
  container.querySelector('#pin-setup-btn').addEventListener('click', async () => {
    const pin = container.querySelector('#pin-new').value;
    const confirmPin = container.querySelector('#pin-confirm').value;
    if (pin.length < MIN_PIN_LENGTH) { showError(`PIN muss mindestens ${MIN_PIN_LENGTH} Zeichen haben.`); return; }
    if (pin !== confirmPin) { showError('Die PINs stimmen nicht überein.'); return; }
    await setupSecurePin(pin);
    toast('Geschützter Bereich eingerichtet');
    renderSecureTab(container);
  });
  function showError(msg) { errorEl.textContent = msg; errorEl.style.display = 'block'; }
}

function renderPinEntry(container) {
  container.innerHTML = `
    <h1>Sicher</h1>
    ${tabsHtml('secure')}
    <div class="empty-state" style="padding-top:var(--sp-5)">
      ${icon('lock')}
      <p>Gib deine PIN ein, um den geschützten Bereich zu öffnen.</p>
    </div>
    <div class="field">
      <label for="pin-entry">PIN</label>
      <input type="password" inputmode="numeric" id="pin-entry" placeholder="••••" />
    </div>
    <div class="field-error" id="pin-error" style="display:none">Falsche PIN.</div>
    <button class="btn btn-primary btn-block" id="pin-unlock-btn">${icon('unlock')} Entsperren</button>
    <button class="btn btn-ghost btn-block" id="pin-forgot-btn" style="margin-top:var(--sp-3)">PIN vergessen?</button>
  `;
  installTabs(container);
  const errorEl = container.querySelector('#pin-error');
  const pinInput = container.querySelector('#pin-entry');
  const unlock = async () => {
    const ok = await tryUnlockSecure(pinInput.value);
    if (ok) { renderSecureTab(container); return; }
    errorEl.style.display = 'block';
    pinInput.value = '';
  };
  container.querySelector('#pin-unlock-btn').addEventListener('click', unlock);
  pinInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') unlock(); });
  container.querySelector('#pin-forgot-btn').addEventListener('click', () => {
    if (!confirm('PIN zurücksetzen? Dabei gehen alle bisher geschützten Notizen unwiderruflich verloren, da sie ohne die alte PIN nicht entschlüsselt werden können.')) return;
    resetSecure().then(() => { toast('Geschützter Bereich zurückgesetzt'); renderSecureTab(container); });
  });
}

/** Wiederverwendbarer Einrichtungs-/Entsperr-Flow, z.B. wenn eine normale Notiz geschützt werden soll,
 *  ohne dass der Nutzer vorher manuell zum "Sicher"-Tab wechseln muss. */
function openSecureUnlockSheet(onUnlocked) {
  hasSecurePin().then((hasPin) => {
    const dlg = createSheet(`
      <div class="sheet__header"><h2>${hasPin ? 'PIN eingeben' : 'PIN erstellen'}</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
      <div class="field">
        <label for="sheet-pin">${hasPin ? 'PIN' : `PIN erstellen (mind. ${MIN_PIN_LENGTH} Ziffern)`}</label>
        <input type="password" inputmode="numeric" id="sheet-pin" placeholder="••••" />
      </div>
      ${hasPin ? '' : `<div class="field"><label for="sheet-pin-confirm">PIN bestätigen</label><input type="password" inputmode="numeric" id="sheet-pin-confirm" placeholder="••••" /></div>`}
      <div class="field-error" id="sheet-pin-error" style="display:none"></div>
      <button class="btn btn-primary btn-block" id="sheet-pin-btn">${icon(hasPin ? 'unlock' : 'lock')} ${hasPin ? 'Entsperren' : 'Einrichten & verschieben'}</button>
    `);
    const errorEl = dlg.querySelector('#sheet-pin-error');
    const showError = (msg) => { errorEl.textContent = msg; errorEl.style.display = 'block'; };
    dlg.querySelector('#sheet-pin-btn').addEventListener('click', async () => {
      const pin = dlg.querySelector('#sheet-pin').value;
      if (hasPin) {
        const ok = await tryUnlockSecure(pin);
        if (!ok) { showError('Falsche PIN.'); return; }
      } else {
        const confirmPin = dlg.querySelector('#sheet-pin-confirm').value;
        if (pin.length < MIN_PIN_LENGTH) { showError(`PIN muss mindestens ${MIN_PIN_LENGTH} Zeichen haben.`); return; }
        if (pin !== confirmPin) { showError('Die PINs stimmen nicht überein.'); return; }
        await setupSecurePin(pin);
      }
      dlg.close();
      await onUnlocked();
    });
  });
}

/* ================= UI: Editor für geschützte Notizen ================= */

async function renderSecureEditor(container, id) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  if (!isSecureUnlocked()) { renderSecureTab(container); return; }
  const note = id ? await getSecureNoteDecrypted(id) : null;
  let currentId = note?.id || null;
  let isChecklist = !!note?.isChecklist;
  let items = note?.checklistItems ? [...note.checklistItems] : [];

  container.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--sp-4)">
      <button class="btn-icon" id="back-btn" aria-label="Zurück">${icon('chevronLeft')}</button>
      <span class="eyebrow">${icon('lock')} Geschützt</span>
      <div style="display:flex;gap:8px">
        ${note ? `<button class="btn-icon" id="delete-note-btn" aria-label="Löschen">${icon('trash')}</button>` : ''}
        <button class="btn-icon" id="save-note-btn" aria-label="Speichern">${icon('check')}</button>
      </div>
    </div>
    <input class="note-editor-title" id="note-title" placeholder="Titel" value="${note ? escapeHtml(note.title) : ''}" />
    <div class="field-row" style="margin-bottom:var(--sp-3)">
      <div class="field" style="margin-bottom:0">
        <select id="note-category">
          ${NOTE_CATEGORIES.map((c) => `<option value="${c.id}" ${(note?.category || DEFAULT_CATEGORY) === c.id ? 'selected' : ''}>${c.emoji} ${escapeHtml(c.label)}</option>`).join('')}
        </select>
      </div>
    </div>
    <label class="checkbox-row" style="margin-bottom:var(--sp-4)">
      <input type="checkbox" id="note-checklist-toggle" ${isChecklist ? 'checked' : ''} />
      Als Checkliste
    </label>
    <div id="note-body-host"></div>
    ${note ? `<button class="btn btn-ghost btn-block" id="unprotect-note-btn" style="margin-top:var(--sp-4)">${icon('unlock')} Schutz aufheben</button>` : ''}
  `;

  const titleEl = container.querySelector('#note-title');
  const categoryEl = container.querySelector('#note-category');
  const bodyHost = container.querySelector('#note-body-host');
  const checklistToggle = container.querySelector('#note-checklist-toggle');
  let bodyEl = null;

  const persist = debounce(async () => {
    const title = titleEl.value.trim();
    const body = isChecklist ? '' : (bodyEl?.value || '');
    if (!title && !body && !(isChecklist && items.length)) return;
    try {
      const saved = await saveSecureNote({ id: currentId, title: title || 'Ohne Titel', body, category: categoryEl.value, isChecklist, checklistItems: items });
      currentId = saved.id;
    } catch (e) {
      // Geschützter Bereich wurde zwischenzeitlich gesperrt oder verlassen (z.B. durch Navigation
      // während der 500ms-Debounce-Verzögerung). Der explizite Speichern-/Zurück-Pfad hat den
      // letzten Stand bereits synchron gesichert, daher hier den Auto-Save-Versuch still verwerfen.
    }
  }, 500);

  function renderBodyArea() {
    if (isChecklist) {
      bodyHost.innerHTML = `<div id="checklist-host"></div>`;
      attachChecklistEditor(container.querySelector('#checklist-host'), items, (nextItems) => { items = nextItems; persist(); });
    } else {
      bodyHost.innerHTML = `<textarea class="note-editor-body" id="note-body" placeholder="Beginne zu schreiben …">${note && !note.isChecklist ? escapeHtml(note.body) : ''}</textarea>`;
      bodyEl = bodyHost.querySelector('#note-body');
      bodyEl.addEventListener('input', persist);
    }
  }
  renderBodyArea();

  titleEl.addEventListener('input', persist);
  categoryEl.addEventListener('change', persist);
  checklistToggle.addEventListener('change', () => {
    isChecklist = checklistToggle.checked;
    renderBodyArea();
    persist();
  });

  container.querySelector('#back-btn').addEventListener('click', async () => {
    const title = titleEl.value.trim();
    const body = isChecklist ? '' : (bodyEl?.value || '');
    if (title || body || (isChecklist && items.length)) {
      await saveSecureNote({ id: currentId, title: title || 'Ohne Titel', body, category: categoryEl.value, isChecklist, checklistItems: items });
    }
    renderSecureTab(container);
  });
  container.querySelector('#save-note-btn').addEventListener('click', async () => {
    const title = titleEl.value.trim();
    const body = isChecklist ? '' : (bodyEl?.value || '');
    const saved = await saveSecureNote({ id: currentId, title: title || 'Ohne Titel', body, category: categoryEl.value, isChecklist, checklistItems: items });
    currentId = saved.id;
    toast('Notiz gespeichert');
  });
  if (note) {
    container.querySelector('#delete-note-btn').addEventListener('click', async () => {
      if (!confirm('Notiz wirklich löschen?')) return;
      await deleteSecureNote(note.id);
      toast('Notiz gelöscht');
      renderSecureTab(container);
    });
    container.querySelector('#unprotect-note-btn').addEventListener('click', async () => {
      if (!confirm('Schutz aufheben und in die normalen Notizen verschieben?')) return;
      const title = titleEl.value.trim() || 'Ohne Titel';
      const body = isChecklist ? '' : (bodyEl?.value || '');
      await saveNote({ title, body, category: categoryEl.value, isChecklist, checklistItems: items });
      await deleteSecureNote(currentId);
      toast('Notiz in normale Notizen verschoben');
      renderNotesList(container, '');
    });
  }
}

/* ================= Hilfsfunktionen ================= */

function emptyState(text) { return `<div class="empty-state">${icon('note')}<p>${escapeHtml(text)}</p></div>`; }
function debounce(fn, ms) { let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); }; }

function createSheet(innerHtml) {
  const dlg = document.createElement('dialog');
  dlg.className = 'sheet';
  dlg.innerHTML = `<div class="sheet__handle"></div><div class="sheet__body">${innerHtml}</div>`;
  document.body.appendChild(dlg);
  dlg.addEventListener('close', () => dlg.remove());
  dlg.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => dlg.close()));
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  dlg.showModal();
  return dlg;
}
