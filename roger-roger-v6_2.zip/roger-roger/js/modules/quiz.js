import { db } from '../core/db.js';
import { icon } from '../core/icons.js';
import { uid, escapeHtml, toast } from '../core/utils.js';
import { CATEGORIES } from './quizData.js';
import { PROMPT_VERSION, MASTER_PROMPT } from './quizPrompt.js';
import { FOUNDATION_QUESTIONS, FOUNDATION_CATEGORIES } from './quizFoundation/index.js';

const S = db.STORES;
const LEITNER_INTERVALS_DAYS = [0, 1, 3, 7, 16, 35]; // Index = Box (0 ungenutzt), Box 1-5

// V2-Konstanten (siehe CLAUDE.md "Wichtige Entscheidungen" nach dem Ausbau)
const MIN_ANSWERS_FOR_RANKING = 5; // Mindestanzahl beantworteter Fragen je Kategorie, bevor sie fuer "beste/schlechteste Kategorie" gewertet wird
const PROBLEM_MASTERED_BOX = 4;    // ab dieser Leitner-Box gilt eine Problemfrage als gefestigt genug, um aus dem Problemquiz zu verschwinden
const QUIZ_SESSION_SIZE = 8;
const FLASH_SESSION_SIZE = 12;
const PROBLEM_SESSION_SIZE = 10;
const VALID_DIFFICULTIES = ['einfach', 'mittel', 'schwer'];

/* ================= Seeding & Kategorien ================= */

/** Beim ersten Start: Seed-Fragen + Seed-Kategorien in die DB laden, falls noch keine vorhanden sind. */
/** Beim App-Start sicherstellen: Fundament vorhanden (ensureFoundationSeeded) und alte,
 * vor V6.0 fest eingebaute Seed-Fragen/-Kategorien entfernt (removeLegacySeedData, siehe
 * dort). Auf einer wirklich frischen Installation ist removeLegacySeedData() sofort ein
 * No-Op, da die alte Seed-Logik hier bewusst nicht mehr ausgeführt wird – der alte
 * Grundbestand ist durch das neue 1.000-Fragen-Fundament vollständig abgelöst. */
export async function ensureSeeded() {
  await ensureFoundationSeeded();
  await removeLegacySeedData();
}

/**
 * Quiz-Fundament (V6.0): stellt sicher, dass alle 1.000 Fundamentfragen aus
 * quizFoundation/index.js in der DB vorhanden sind, ohne sie jemals zu duplizieren.
 *
 * Bewusst KEIN "leer? dann alles einfuegen"-Gate wie beim alten Seed oben – die
 * Fundamentfragen muessen auch dann ergaenzt werden, wenn die DB bereits Fragen
 * enthaelt (z.B. nach einem App-Update, das neue Fundamentfragen mitbringt, oder wenn
 * jemand einzelne Fundamentfragen versehentlich geloescht hat). Der Duplikatschutz
 * laeuft daher pro Frage ueber die stabile, lesbare ID (foundation-<kategorie>-NNN),
 * nicht ueber die Store-Groesse insgesamt. Ein mehrfacher Aufruf (z.B. bei jedem
 * Oeffnen des Quiz-Moduls) fuegt dadurch nie Duplikate hinzu.
 */
export async function ensureFoundationSeeded() {
  const [existingQuestions, existingCategories] = await Promise.all([
    db.getAll(S.quizQuestions),
    db.getAll(S.quizCategories),
  ]);
  const existingIds = new Set(existingQuestions.map((q) => q.id));
  const missingQuestions = FOUNDATION_QUESTIONS.filter((q) => !existingIds.has(q.id));
  if (missingQuestions.length) {
    await db.putMany(S.quizQuestions, missingQuestions);
  }
  const existingCatIds = new Set(existingCategories.map((c) => c.id));
  const missingCategories = FOUNDATION_CATEGORIES
    .filter((name) => !existingCatIds.has(name))
    .map((name) => ({ id: name, name, createdAt: Date.now(), source: 'foundation' }));
  if (missingCategories.length) {
    await db.putMany(S.quizCategories, missingCategories);
  }
}

/**
 * Entfernt die alten, vor V6.0 fest eingebauten Seed-Fragen und -Kategorien (~67 Fragen,
 * ursprünglich aus quizData.js/SEED_QUESTIONS), auf ausdrücklichen Nutzerwunsch nach
 * Einführung des 1.000-Fragen-Fundaments ("entferne die alten Kategorien, die vor der
 * 6.0 Version im Quiz waren").
 *
 * WICHTIG – Namensüberschneidung: 5 der 11 alten Kategorien tragen exakt denselben Namen
 * wie eine neue Fundament-Kategorie (Geschichte, Geografie, Naturwissenschaften,
 * "Kunst & Kultur", Sport). Da `quizCategories` je Kategorie nur eine Zeile führt
 * (id = Name), gehört diese eine Zeile inzwischen zu den 100 neuen Fundamentfragen dieser
 * Kategorie – sie darf NICHT gelöscht werden, nur weil sie ursprünglich mit `source:'seed'`
 * angelegt wurde. Es werden daher ausschließlich Kategorien entfernt, die (a) zu den alten
 * CATEGORIES aus quizData.js gehören, (b) in KEINER neuen Fundament-Kategorie eine
 * Entsprechung haben und (c) tatsächlich noch mit `source: 'seed'` gespeichert sind (nie
 * eine vom Nutzer selbst per Import angelegte Kategorie gleichen Namens).
 *
 * Nur die Fragen selbst werden gelöscht (plus verwaiste Leitner-Fortschrittseinträge dazu) –
 * bereits vorhandene Statistik-/Ergebnis-Historie (`quizAnswerLog`, `quizResults`) bleibt
 * unangetastet, da das echte Nutzerhistorie ist, kein Bestandteil der "alten Kategorien".
 *
 * Idempotent: ein wiederholter Aufruf (z.B. bei jedem Öffnen des Quiz, wie ensureSeeded()
 * es tut) findet beim zweiten Mal nichts mehr zu tun und ist dann ein reines No-Op.
 */
export async function removeLegacySeedData() {
  const foundationSet = new Set(FOUNDATION_CATEGORIES);
  const [allQuestions, allCategories, allProgress] = await Promise.all([
    db.getAll(S.quizQuestions), db.getAll(S.quizCategories), db.getAll(S.quizProgress),
  ]);

  const legacyQuestions = allQuestions.filter((q) => q.source === 'seed');
  for (const question of legacyQuestions) {
    await db.remove(S.quizQuestions, question.id);
  }

  if (legacyQuestions.length) {
    const legacyIds = new Set(legacyQuestions.map((q) => q.id));
    for (const p of allProgress) {
      if (legacyIds.has(p.id)) await db.remove(S.quizProgress, p.id);
    }
  }

  for (const cat of allCategories) {
    const isOldBuiltIn = CATEGORIES.includes(cat.name);
    const stillUsedByFoundation = foundationSet.has(cat.name);
    if (isOldBuiltIn && !stillUsedByFoundation && cat.source === 'seed') {
      await db.remove(S.quizCategories, cat.id);
    }
  }
}

/** Dynamische Kategorienliste (Seed + spaeter per Import hinzugekommene), alphabetisch sortiert. */
export async function getCategories() {
  const cats = await db.getAll(S.quizCategories);
  return cats.map((c) => c.name).sort((a, b) => a.localeCompare(b, 'de'));
}

async function ensureCategoryExists(name) {
  const trimmed = (name || '').trim();
  if (!trimmed) return null;
  const existing = await db.get(S.quizCategories, trimmed);
  if (!existing) {
    await db.put(S.quizCategories, { id: trimmed, name: trimmed, createdAt: Date.now(), source: 'import' });
  }
  return trimmed;
}

export async function getActiveQuestions(category = null) {
  const all = await db.getAll(S.quizQuestions);
  return all.filter((q) => q.reviewStatus === 'reviewed' && (!category || q.category === category));
}

export async function getAllQuestions() { return db.getAll(S.quizQuestions); }

export async function reportQuestion(id) {
  const question = await db.get(S.quizQuestions, id);
  if (!question) return;
  await db.put(S.quizQuestions, { ...question, reported: true });
}

/* ================= Fortschritt / Lernstatistik ================= */

export async function getProgressFor(questionId) {
  return db.get(S.quizProgress, questionId);
}

export async function getAllProgress() { return db.getAll(S.quizProgress); }

async function updateProgress(questionId, known) {
  const existing = await db.get(S.quizProgress, questionId);
  let box = existing?.box || 1;
  box = known ? Math.min(box + 1, 5) : 1;
  const nextIntervalDays = LEITNER_INTERVALS_DAYS[box];
  const nextReview = Date.now() + nextIntervalDays * 86400000;
  await db.put(S.quizProgress, {
    id: questionId,
    box,
    knownCount: (existing?.knownCount || 0) + (known ? 1 : 0),
    unknownCount: (existing?.unknownCount || 0) + (known ? 0 : 1),
    lastReviewed: Date.now(),
    nextReview,
  });
}

/** Zentrale Stelle, an der jede einzelne Antwort dauerhaft erfasst wird (V2 Lernstatistik-Basis).
 * Exportiert, damit andere Module (z.B. das Sport-Pausenquiz) dieselbe Lernlogik wiederverwenden
 * können, statt ein zweites Quizsystem zu bauen (siehe CLAUDE.md Architekturprinzip). */
export async function logAnswer(question, correct, mode) {
  await db.put(S.quizAnswerLog, {
    id: uid(),
    questionId: question.id,
    category: question.category,
    correct,
    mode, // 'quiz' | 'flashcard' | 'problem'
    timestamp: Date.now(),
  });
  await updateProgress(question.id, correct);
}

export async function saveResult(result) {
  const row = { ...result, id: uid(), completedAt: Date.now() };
  await db.put(S.quizResults, row);
  return row;
}

export async function getResults() { return db.getAll(S.quizResults); }

export async function getAnswerLog() { return db.getAll(S.quizAnswerLog); }

/** Erfolgsquote pro Kategorie, aus der tatsaechlichen Antwort-Historie (nicht aus erfundenen Werten). */
export async function getCategoryStats() {
  const log = await getAnswerLog();
  const stats = {};
  log.forEach((entry) => {
    if (!stats[entry.category]) stats[entry.category] = { correct: 0, total: 0 };
    stats[entry.category].total += 1;
    if (entry.correct) stats[entry.category].correct += 1;
  });
  return stats;
}

/** Anzahl aktiver Fragen insgesamt und pro Kategorie (Basis fuer Fragenbibliothek/Kategorien-Anzeige). */
export async function getQuestionCounts() {
  const questions = await getActiveQuestions();
  const byCategory = {};
  questions.forEach((q) => {
    byCategory[q.category] = (byCategory[q.category] || 0) + 1;
  });
  return { total: questions.length, byCategory };
}

export async function getOverallStats() {
  const log = await getAnswerLog();
  const total = log.length;
  const correct = log.filter((e) => e.correct).length;
  return { total, correct, pct: total ? Math.round((correct / total) * 100) : null };
}

/** Beste/schlechteste Kategorie, nur unter Kategorien mit ausreichend Datenbasis (siehe MIN_ANSWERS_FOR_RANKING). */
export async function getBestWorstCategory() {
  const stats = await getCategoryStats();
  const ranked = Object.entries(stats)
    .filter(([, s]) => s.total >= MIN_ANSWERS_FOR_RANKING)
    .map(([name, s]) => ({ name, pct: Math.round((s.correct / s.total) * 100) }));
  if (!ranked.length) return { best: null, worst: null };
  ranked.sort((a, b) => b.pct - a.pct);
  return { best: ranked[0], worst: ranked[ranked.length - 1] };
}

/** Problemfragen: falsch beantwortet und noch nicht ausreichend gefestigt (Box < PROBLEM_MASTERED_BOX). */
export async function getProblemQuestions(limit = PROBLEM_SESSION_SIZE, category = null) {
  const [progressList, questions] = await Promise.all([getAllProgress(), getActiveQuestions(category)]);
  const qMap = new Map(questions.map((q) => [q.id, q]));
  const candidates = progressList
    .filter((p) => p.unknownCount > 0 && p.box < PROBLEM_MASTERED_BOX && qMap.has(p.id))
    .sort((a, b) => (b.unknownCount - b.knownCount) - (a.unknownCount - a.knownCount) || a.box - b.box);
  return candidates.slice(0, limit).map((p) => qMap.get(p.id));
}

/* ================= JSON-Import ================= */

function hashString(str) {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash + str.charCodeAt(i)) | 0;
  }
  return (hash >>> 0).toString(36);
}

/** Stabile, inhaltsbasierte ID -> gleicher Import erzeugt keine Duplikate. */
function stableQuestionId(category, text, options) {
  const normalized = `${category.trim().toLowerCase()}|${text.trim().toLowerCase()}|${options.map((o) => o.trim().toLowerCase()).join('|')}`;
  return `imp-${hashString(normalized)}`;
}

/**
 * Validiert einen eingefuegten JSON-Katalog gegen das in quizPrompt.js dokumentierte Schema.
 * Gibt niemals eine Exception zurueck: entweder { error } oder { valid, invalid, duplicates, unknownCategories }.
 */
function validateImportPayload(raw, existingIds, existingCategoryNames) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    return { error: 'Das eingefuegte JSON konnte nicht gelesen werden (Syntaxfehler).' };
  }

  const topCategory = typeof parsed?.category === 'string' ? parsed.category.trim() : null;
  const list = Array.isArray(parsed) ? parsed : (Array.isArray(parsed?.questions) ? parsed.questions : null);
  if (!list) {
    return { error: 'Unerwartetes Format: erwartet wird ein Objekt mit einem "questions"-Array (siehe Prompt).' };
  }
  if (!list.length) {
    return { error: 'Der Katalog enthaelt keine Fragen.' };
  }

  const valid = [];
  const invalid = [];
  const duplicates = [];
  const seenInBatch = new Set();
  const categoriesFound = new Set();

  list.forEach((item, i) => {
    const errors = [];
    const category = (typeof item?.category === 'string' && item.category.trim()) ? item.category.trim() : topCategory;
    const text = typeof item?.text === 'string' ? item.text.trim() : '';
    const options = Array.isArray(item?.options)
      ? item.options.map((o) => (typeof o === 'string' ? o.trim() : ''))
      : [];
    const correctIndex = Number.isInteger(item?.correctIndex) ? item.correctIndex : null;
    const explanation = typeof item?.explanation === 'string' ? item.explanation.trim() : '';
    const difficulty = VALID_DIFFICULTIES.includes(item?.difficulty) ? item.difficulty : 'mittel';
    const subtopic = typeof item?.subtopic === 'string' ? item.subtopic.trim() : '';
    const tags = Array.isArray(item?.tags) ? item.tags.filter((t) => typeof t === 'string') : [];

    if (!category) errors.push('keine Kategorie angegeben');
    if (!text) errors.push('kein Fragetext');
    if (options.length < 2 || options.length > 6) errors.push('2-6 Antwortoptionen erforderlich');
    if (options.some((o) => !o)) errors.push('leere Antwortoption');
    const lowerOpts = options.map((o) => o.toLowerCase());
    if (new Set(lowerOpts).size !== lowerOpts.length) errors.push('doppelte Antwortoptionen');
    if (correctIndex === null || correctIndex < 0 || correctIndex >= options.length) errors.push('correctIndex ungueltig');

    if (errors.length) {
      invalid.push({ index: i, text: text || '(kein Text)', errors });
      return;
    }

    categoriesFound.add(category);
    const id = stableQuestionId(category, text, options);
    if (existingIds.has(id) || seenInBatch.has(id)) {
      duplicates.push({ index: i, text, category });
      return;
    }
    seenInBatch.add(id);

    valid.push({
      id, category, subtopic: subtopic || null, difficulty, text, options, correctIndex, explanation,
      tags, source: 'import', createdAt: Date.now(), reviewStatus: 'reviewed', reported: false,
    });
  });

  const unknownCategories = [...categoriesFound].filter(
    (c) => !existingCategoryNames.some((e) => e.toLowerCase() === c.toLowerCase())
  );

  return { valid, invalid, duplicates, categoriesFound: [...categoriesFound], unknownCategories };
}

async function commitImport(validQuestions, categoryMapping) {
  const remapped = validQuestions.map((q) => ({ ...q, category: categoryMapping[q.category] || q.category }));
  const categoriesToEnsure = [...new Set(remapped.map((q) => q.category))];
  for (const name of categoriesToEnsure) await ensureCategoryExists(name);
  if (remapped.length) await db.putMany(S.quizQuestions, remapped);
}

/* ================= UI: Uebersicht ================= */

export async function render(container, params = {}) {
  await ensureSeeded();
  return renderOverview(container);
}

async function renderOverview(container) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  const [overall, catStats, bestWorst, categories, problemQuestions, questionCounts] = await Promise.all([
    getOverallStats(), getCategoryStats(), getBestWorstCategory(), getCategories(), getProblemQuestions(999), getQuestionCounts(),
  ]);

  container.innerHTML = `
    <h1>Quiz</h1>

    <div class="section-title" style="margin-top:0"><h2>Mein Fortschritt</h2></div>
    ${progressCard(overall, bestWorst)}

    <div class="section-title"><h2>Schnelles Quiz</h2></div>
    <div class="card list">
      <button class="btn btn-primary btn-block" id="quick-mixed-btn">${icon('brain')} Gemischt starten</button>
      <button class="btn btn-secondary btn-block" id="quick-category-btn">Kategorie waehlen</button>
    </div>

    <div class="section-title"><h2>Karteikarten</h2></div>
    <div class="card list">
      <button class="btn btn-primary btn-block" id="flash-mixed-btn">${icon('card')} Gemischt starten</button>
      <button class="btn btn-secondary btn-block" id="flash-category-btn">Kategorie waehlen</button>
    </div>

    <div class="section-title"><h2>Problemquiz</h2></div>
    <div class="card">
      <p class="field-hint" style="margin-bottom:var(--sp-3)">Fragen, die du bisher falsch beantwortet hast – gezielt wiederholen.</p>
      <button class="btn ${problemQuestions.length ? 'btn-primary' : 'btn-secondary'} btn-block" id="problem-btn" ${problemQuestions.length ? '' : 'disabled'}>
        ${icon('target')} ${problemQuestions.length ? `Problemquiz starten (${problemQuestions.length})` : 'Noch keine Problemfragen'}
      </button>
    </div>

    <div class="section-title"><h2>Kategorien</h2></div>
    <div class="category-grid">
      ${categories.map((c) => categoryTile(c, catStats[c] || { correct: 0, total: 0 }, questionCounts.byCategory[c] || 0)).join('')}
    </div>

    <div class="section-title"><h2>Fragenbibliothek</h2></div>
    <div class="card list">
      <p class="field-hint" style="margin:0 0 var(--sp-3)">${questionCounts.total} ${questionCounts.total === 1 ? 'Frage' : 'Fragen'} im Modul, in ${categories.length} ${categories.length === 1 ? 'Kategorie' : 'Kategorien'}</p>
      <button class="btn btn-secondary btn-block" id="import-btn">${icon('upload')} Fragen importieren</button>
      <button class="btn btn-ghost btn-block" id="prompt-btn">${icon('copy')} Prompt fuer neue Fragen</button>
    </div>
  `;

  container.querySelector('#quick-mixed-btn').addEventListener('click', () => renderQuizSession(container, null, null));
  container.querySelector('#quick-category-btn').addEventListener('click', () => {
    openCategoryPickerSheet(categories, (c) => renderQuizSession(container, c, null));
  });
  container.querySelector('#flash-mixed-btn').addEventListener('click', () => renderFlashSession(container, null));
  container.querySelector('#flash-category-btn').addEventListener('click', () => {
    openCategoryPickerSheet(categories, (c) => renderFlashSession(container, c));
  });
  const problemBtn = container.querySelector('#problem-btn');
  if (!problemBtn.disabled) problemBtn.addEventListener('click', () => renderProblemSession(container));
  container.querySelectorAll('[data-category]').forEach((tile) => {
    tile.addEventListener('click', () => openCategorySheet(container, tile.dataset.category));
  });
  container.querySelector('#import-btn').addEventListener('click', () => renderImport(container));
  container.querySelector('#prompt-btn').addEventListener('click', () => openPromptSheet());
}

function progressCard(overall, bestWorst) {
  if (!overall.total) {
    return `<div class="card">${emptyState('Noch keine beantworteten Fragen – starte dein erstes Quiz.')}</div>`;
  }
  return `
    <div class="card">
      <div class="progress-row__label"><span>Beantwortet</span><span>${overall.total}</span></div>
      <div class="progress-row__label"><span>Richtig</span><span>${overall.correct} / ${overall.total} (${overall.pct}%)</span></div>
      <div class="progress-bar" style="margin-bottom:var(--sp-3)"><div class="progress-bar__fill" style="width:${overall.pct}%"></div></div>
      <div class="progress-row__label"><span>Beste Kategorie</span><span>${bestWorst.best ? `${escapeHtml(bestWorst.best.name)} (${bestWorst.best.pct}%)` : '– noch nicht genug Daten'}</span></div>
      <div class="progress-row__label"><span>Schwaechste Kategorie</span><span>${bestWorst.worst ? `${escapeHtml(bestWorst.worst.name)} (${bestWorst.worst.pct}%)` : '– noch nicht genug Daten'}</span></div>
    </div>`;
}

function categoryTile(name, stat, questionCount) {
  const pct = stat.total ? Math.round((stat.correct / stat.total) * 100) : null;
  return `
    <button class="category-tile" data-category="${escapeHtml(name)}">
      <div class="category-tile__name">${escapeHtml(name)}</div>
      <div class="category-tile__stat">${pct === null ? 'Noch nicht gespielt' : `${pct}% Erfolgsquote`}</div>
      <div class="category-tile__count">${questionCount} ${questionCount === 1 ? 'Frage' : 'Fragen'}</div>
    </button>`;
}

function openCategoryPickerSheet(categories, onPick) {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Kategorie waehlen</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <div class="list">
      ${categories.map((c) => `<button class="btn btn-secondary btn-block" data-pick="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('')}
    </div>
  `);
  dlg.querySelectorAll('[data-pick]').forEach((b) => b.addEventListener('click', () => {
    dlg.close();
    onPick(b.dataset.pick);
  }));
}

function openCategorySheet(container, category) {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>${escapeHtml(category)}</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <div class="list">
      <button class="btn btn-primary btn-block" data-diff="einfach">Quiz – Einfach</button>
      <button class="btn btn-primary btn-block" data-diff="mittel">Quiz – Mittel</button>
      <button class="btn btn-primary btn-block" data-diff="schwer">Quiz – Schwer</button>
      <button class="btn btn-secondary btn-block" data-diff="alle">Quiz – Alle Schwierigkeiten</button>
      <button class="btn btn-secondary btn-block" id="flash-cat-btn">${icon('card')} Karteikarten zu dieser Kategorie</button>
    </div>
  `);
  dlg.querySelectorAll('[data-diff]').forEach((b) => b.addEventListener('click', () => {
    dlg.close();
    renderQuizSession(container, category, b.dataset.diff);
  }));
  dlg.querySelector('#flash-cat-btn').addEventListener('click', () => { dlg.close(); renderFlashSession(container, category); });
}

function openPromptSheet() {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Prompt fuer neue Fragen</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <p class="field-hint" style="margin-bottom:var(--sp-3)">Prompt-Version: ${PROMPT_VERSION} – kopiere den Prompt, ergaenze Thema/Anzahl und lass Claude oder ChatGPT damit einen JSON-Fragenkatalog erzeugen. Importiere das Ergebnis anschliessend hier im Quiz.</p>
    <textarea id="prompt-text" readonly style="min-height:280px;font-family:var(--font-mono);font-size:var(--fs-xs)">${escapeHtml(MASTER_PROMPT)}</textarea>
    <button class="btn btn-primary btn-block" id="prompt-copy-btn" style="margin-top:var(--sp-4)">${icon('copy')} Kopieren</button>
  `);
  dlg.querySelector('#prompt-copy-btn').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(MASTER_PROMPT);
      toast('Prompt kopiert');
    } catch (e) {
      const ta = dlg.querySelector('#prompt-text');
      ta.select();
      document.execCommand('copy');
      toast('Prompt kopiert');
    }
  });
}

/* ================= UI: Import ================= */

async function renderImport(container) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  container.innerHTML = `
    <h1>Fragen importieren</h1>
    <p class="field-hint" style="margin-bottom:var(--sp-4)">Fuege einen JSON-Fragenkatalog ein (z.B. mit dem Prompt erzeugt) oder waehle eine Datei. Vor dem eigentlichen Import zeigt dir die App eine Vorschau.</p>
    <div class="field">
      <label for="import-textarea">JSON</label>
      <textarea id="import-textarea" rows="8" placeholder='{"category": "...", "questions": [...] }'></textarea>
    </div>
    <input type="file" id="import-file-input" accept="application/json" hidden />
    <button class="btn btn-secondary btn-block" id="import-file-btn" style="margin-bottom:var(--sp-4)">${icon('upload')} Datei waehlen</button>
    <button class="btn btn-primary btn-block" id="import-validate-btn">Validieren</button>
    <button class="btn btn-ghost btn-block" id="import-back-btn" style="margin-top:var(--sp-3)">Zurueck</button>
    <div id="import-preview"></div>
  `;

  const textarea = container.querySelector('#import-textarea');
  const fileInput = container.querySelector('#import-file-input');
  container.querySelector('#import-file-btn').addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files?.[0];
    if (!file) return;
    textarea.value = await file.text();
    fileInput.value = '';
  });
  container.querySelector('#import-back-btn').addEventListener('click', () => renderOverview(container));

  container.querySelector('#import-validate-btn').addEventListener('click', async () => {
    const raw = textarea.value.trim();
    if (!raw) { toast('Bitte zuerst JSON einfuegen oder eine Datei waehlen', 'danger'); return; }
    const [existingQuestions, existingCategories] = await Promise.all([getAllQuestions(), getCategories()]);
    // V6.0: Duplikaterkennung laeuft ueber den Inhalts-Hash (stableQuestionId), nicht ueber die
    // gespeicherte ID. Dadurch werden Duplikate auch gegen Fundamentfragen erkannt, deren IDs
    // (foundation-<kat>-NNN) nicht dem imp-<hash>-Schema neu importierter Fragen entsprechen –
    // sie sind aber inhaltlich (Kategorie+Text+Antworten) exakt vergleichbar. Erweitert damit den
    // bestehenden Mechanismus statt einen zweiten zu bauen (siehe Auftrag "Quiz-Fundament").
    const existingIds = new Set(existingQuestions.map((q) => stableQuestionId(q.category, q.text, q.options)));
    const result = validateImportPayload(raw, existingIds, existingCategories);
    if (result.error) { toast(result.error, 'danger'); return; }
    renderImportPreview(container, result, existingCategories);
  });
}

function renderImportPreview(container, result, existingCategories) {
  const previewEl = container.querySelector('#import-preview');
  const { valid, invalid, duplicates, unknownCategories } = result;

  previewEl.innerHTML = `
    <div class="section-title"><h2>Vorschau</h2></div>
    <div class="card list">
      <div class="progress-row__label"><span>Neue Fragen</span><span>${valid.length}</span></div>
      <div class="progress-row__label"><span>Duplikate (werden uebersprungen)</span><span>${duplicates.length}</span></div>
      <div class="progress-row__label"><span>Ungueltige Fragen (werden uebersprungen)</span><span>${invalid.length}</span></div>
    </div>
    ${invalid.length ? `<details style="margin-top:var(--sp-3)"><summary class="field-hint">${icon('alertTriangle')} Ungueltige Fragen anzeigen</summary>
      <div class="list" style="margin-top:var(--sp-2)">
        ${invalid.slice(0, 30).map((e) => `<div class="item-row"><div class="item-row__main"><div class="item-row__title">#${e.index + 1}: ${escapeHtml(e.text)}</div><div class="item-row__desc">${escapeHtml(e.errors.join(', '))}</div></div></div>`).join('')}
      </div>
    </details>` : ''}
    ${unknownCategories.length ? `
      <div class="section-title"><h2>Unbekannte Kategorien</h2></div>
      <p class="field-hint" style="margin-bottom:var(--sp-3)">Ordne jede neue Kategorie einer bestehenden zu oder lege sie neu an.</p>
      <div class="list" id="category-map-list">
        ${unknownCategories.map((c, i) => categoryMapRow(c, i, existingCategories)).join('')}
      </div>
    ` : ''}
    <button class="btn btn-primary btn-block" id="import-confirm-btn" style="margin-top:var(--sp-4)" ${valid.length ? '' : 'disabled'}>
      ${icon('check')} ${valid.length} Frage${valid.length === 1 ? '' : 'n'} importieren
    </button>
  `;

  const confirmBtn = previewEl.querySelector('#import-confirm-btn');
  if (confirmBtn && valid.length) {
    confirmBtn.addEventListener('click', async () => {
      const mapping = {};
      unknownCategories.forEach((c, i) => {
        const select = previewEl.querySelector(`[data-cat-select="${i}"]`);
        mapping[c] = select ? select.value : c;
      });
      await commitImport(valid, mapping);
      toast(`${valid.length} Frage${valid.length === 1 ? '' : 'n'} importiert`);
      renderOverview(container);
    });
  }
}

function categoryMapRow(categoryName, index, existingCategories) {
  return `
    <div class="field" style="margin-bottom:var(--sp-3)">
      <label>${escapeHtml(categoryName)}</label>
      <select data-cat-select="${index}">
        <option value="${escapeHtml(categoryName)}" selected>Neue Kategorie: "${escapeHtml(categoryName)}"</option>
        ${existingCategories.map((c) => `<option value="${escapeHtml(c)}">Zuordnen zu: ${escapeHtml(c)}</option>`).join('')}
      </select>
    </div>`;
}

/* ================= UI: Quizmodus (Multiple Choice) ================= */

async function renderQuizSession(container, category, difficulty) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  let pool = await getActiveQuestions(category);
  if (difficulty && difficulty !== 'alle') pool = pool.filter((q) => q.difficulty === difficulty);
  pool = shuffle(pool).slice(0, Math.min(QUIZ_SESSION_SIZE, pool.length));

  if (!pool.length) {
    container.innerHTML = `<h1>Quiz</h1>${emptyState('Fuer diese Auswahl sind aktuell keine geprueften Fragen verfuegbar.')}
      <button class="btn btn-secondary btn-block" id="back-btn">Zurueck</button>`;
    container.querySelector('#back-btn').addEventListener('click', () => renderOverview(container));
    return;
  }

  let index = 0;
  let correctCount = 0;
  let wrongCount = 0;

  function showQuestion() {
    const question = pool[index];
    container.innerHTML = `
      <div class="quiz-progress-top">Frage ${index + 1} / ${pool.length} · ${escapeHtml(category || 'Gemischt')} · ${question.difficulty}</div>
      <div class="quiz-question">${escapeHtml(question.text)}</div>
      <div id="answers"></div>
      <div id="explanation-area"></div>
      <button class="btn btn-ghost" id="report-btn" style="margin-top:var(--sp-2)">${icon('flag')} Frage melden</button>
    `;
    const answersEl = container.querySelector('#answers');
    const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
    question.options.forEach((opt, i) => {
      const btn = document.createElement('button');
      btn.className = 'answer-option';
      btn.innerHTML = `<span class="answer-option__letter">${letters[i]}</span><span>${escapeHtml(opt)}</span>`;
      btn.addEventListener('click', () => selectAnswer(i));
      answersEl.appendChild(btn);
    });
    container.querySelector('#report-btn').addEventListener('click', async () => {
      await reportQuestion(question.id);
      toast('Danke, die Frage wurde gemeldet und wird geprueft.');
    });

    async function selectAnswer(i) {
      const isCorrect = i === question.correctIndex;
      if (isCorrect) correctCount += 1; else wrongCount += 1;
      await logAnswer(question, isCorrect, 'quiz');
      Array.from(answersEl.children).forEach((btn, bi) => {
        btn.disabled = true;
        if (bi === question.correctIndex) btn.classList.add('is-correct');
        else if (bi === i) btn.classList.add('is-wrong');
      });
      container.querySelector('#explanation-area').innerHTML = `
        <div class="quiz-explanation">${isCorrect ? 'Richtig! ' : 'Leider falsch. '}${escapeHtml(question.explanation)}</div>
        <button class="btn btn-primary btn-block" id="next-btn">${index + 1 < pool.length ? 'Naechste Frage' : 'Ergebnis anzeigen'}</button>
      `;
      container.querySelector('#next-btn').addEventListener('click', () => {
        index += 1;
        if (index < pool.length) showQuestion(); else showResult();
      });
    }
  }

  async function showResult() {
    const total = correctCount + wrongCount;
    const pct = Math.round((correctCount / total) * 100);
    await saveResult({ category: category || 'Gemischt', difficulty: difficulty || 'alle', correctCount, wrongCount, totalCount: total, percent: pct });
    container.innerHTML = `
      <h1>Auswertung</h1>
      <div class="result-ring-wrap">${resultRing(pct)}</div>
      <div class="card list">
        <div class="progress-row__label"><span>Richtig</span><span>${correctCount} / ${total}</span></div>
        <div class="progress-row__label"><span>Falsch</span><span>${wrongCount} / ${total}</span></div>
        <div class="progress-row__label"><span>Kategorie</span><span>${escapeHtml(category || 'Gemischt')}</span></div>
        <div class="progress-row__label"><span>Schwierigkeit</span><span>${difficulty || 'alle'}</span></div>
      </div>
      <button class="btn btn-primary btn-block" id="again-btn" style="margin-top:var(--sp-4)">${icon('refresh')} Noch einmal</button>
      <button class="btn btn-secondary btn-block" id="back-overview-btn" style="margin-top:var(--sp-3)">Zur Uebersicht</button>
    `;
    container.querySelector('#again-btn').addEventListener('click', () => renderQuizSession(container, category, difficulty));
    container.querySelector('#back-overview-btn').addEventListener('click', () => renderOverview(container));
  }

  showQuestion();
}

/* ================= UI: Problemquiz ================= */

async function renderProblemSession(container) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  const pool = shuffle(await getProblemQuestions(PROBLEM_SESSION_SIZE));

  if (!pool.length) {
    container.innerHTML = `<h1>Problemquiz</h1>${emptyState('Aktuell keine Problemfragen – gut gemacht!')}
      <button class="btn btn-secondary btn-block" id="back-btn">Zurueck</button>`;
    container.querySelector('#back-btn').addEventListener('click', () => renderOverview(container));
    return;
  }

  let index = 0;
  let correctCount = 0;
  let wrongCount = 0;

  function showQuestion() {
    const question = pool[index];
    container.innerHTML = `
      <div class="quiz-progress-top">Problemfrage ${index + 1} / ${pool.length} · ${escapeHtml(question.category)}</div>
      <div class="quiz-question">${escapeHtml(question.text)}</div>
      <div id="answers"></div>
      <div id="explanation-area"></div>
    `;
    const answersEl = container.querySelector('#answers');
    const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
    question.options.forEach((opt, i) => {
      const btn = document.createElement('button');
      btn.className = 'answer-option';
      btn.innerHTML = `<span class="answer-option__letter">${letters[i]}</span><span>${escapeHtml(opt)}</span>`;
      btn.addEventListener('click', () => selectAnswer(i));
      answersEl.appendChild(btn);
    });

    async function selectAnswer(i) {
      const isCorrect = i === question.correctIndex;
      if (isCorrect) correctCount += 1; else wrongCount += 1;
      await logAnswer(question, isCorrect, 'problem');
      Array.from(answersEl.children).forEach((btn, bi) => {
        btn.disabled = true;
        if (bi === question.correctIndex) btn.classList.add('is-correct');
        else if (bi === i) btn.classList.add('is-wrong');
      });
      container.querySelector('#explanation-area').innerHTML = `
        <div class="quiz-explanation">${isCorrect ? 'Richtig! ' : 'Leider falsch. '}${escapeHtml(question.explanation)}</div>
        <button class="btn btn-primary btn-block" id="next-btn">${index + 1 < pool.length ? 'Naechste Frage' : 'Ergebnis anzeigen'}</button>
      `;
      container.querySelector('#next-btn').addEventListener('click', () => {
        index += 1;
        if (index < pool.length) showQuestion(); else showResult();
      });
    }
  }

  function showResult() {
    const total = correctCount + wrongCount;
    const pct = Math.round((correctCount / total) * 100);
    container.innerHTML = `
      <h1>Problemquiz – Auswertung</h1>
      <div class="result-ring-wrap">${resultRing(pct)}</div>
      <div class="card list">
        <div class="progress-row__label"><span>Richtig</span><span>${correctCount} / ${total}</span></div>
        <div class="progress-row__label"><span>Falsch</span><span>${wrongCount} / ${total}</span></div>
      </div>
      <button class="btn btn-primary btn-block" id="again-btn" style="margin-top:var(--sp-4)">${icon('refresh')} Naechste Runde</button>
      <button class="btn btn-secondary btn-block" id="back-overview-btn" style="margin-top:var(--sp-3)">Zur Uebersicht</button>
    `;
    container.querySelector('#again-btn').addEventListener('click', () => renderProblemSession(container));
    container.querySelector('#back-overview-btn').addEventListener('click', () => renderOverview(container));
  }

  showQuestion();
}

function resultRing(pct) {
  const r = 60, c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;
  const color = pct >= 70 ? 'var(--color-success)' : pct >= 40 ? 'var(--color-accent)' : 'var(--color-danger)';
  return `
    <div class="result-ring">
      <svg width="140" height="140" viewBox="0 0 140 140">
        <circle cx="70" cy="70" r="${r}" fill="none" stroke="var(--color-border)" stroke-width="12" />
        <circle cx="70" cy="70" r="${r}" fill="none" stroke="${color}" stroke-width="12" stroke-linecap="round"
          stroke-dasharray="${c}" stroke-dashoffset="${offset}" transform="rotate(-90 70 70)" />
      </svg>
      <div class="result-ring__pct">${pct}%</div>
    </div>`;
}

/* ================= UI: Karteikartenmodus ================= */

async function renderFlashSession(container, category) {
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  const [pool, progress] = await Promise.all([getActiveQuestions(category), getAllProgress()]);
  const progressMap = new Map(progress.map((p) => [p.id, p]));
  const now = Date.now();

  const due = pool.filter((q) => {
    const p = progressMap.get(q.id);
    return !p || p.nextReview <= now;
  });
  // Karten mit niedrigerer Box (schlechter beherrscht) zuerst
  due.sort((a, b) => (progressMap.get(a.id)?.box || 1) - (progressMap.get(b.id)?.box || 1));
  const session = due.slice(0, FLASH_SESSION_SIZE);

  if (!session.length) {
    container.innerHTML = `<h1>Karteikarten</h1>${emptyState('Aktuell sind keine Karten faellig. Schau spaeter wieder vorbei oder waehle eine andere Kategorie.')}
      <button class="btn btn-secondary btn-block" id="back-btn">Zurueck</button>`;
    container.querySelector('#back-btn').addEventListener('click', () => renderOverview(container));
    return;
  }

  let index = 0;
  function showCard() {
    const question = session[index];
    const flipped = { value: false };
    container.innerHTML = `
      <div class="quiz-progress-top">Karte ${index + 1} / ${session.length}${category ? ` · ${escapeHtml(category)}` : ' · alle Kategorien'}</div>
      <div class="flashcard" id="flashcard">
        <div class="flashcard__inner">
          <div class="flashcard__face flashcard__face--front">
            <span class="eyebrow">${escapeHtml(question.category)}</span>
            <p style="font-size:var(--fs-md);font-weight:600">${escapeHtml(question.text)}</p>
            <span class="field-hint">Zum Umdrehen antippen</span>
          </div>
          <div class="flashcard__face flashcard__face--back">
            <strong>${escapeHtml(question.options[question.correctIndex])}</strong>
            <p style="font-size:var(--fs-sm)">${escapeHtml(question.explanation)}</p>
          </div>
        </div>
      </div>
      <div id="know-actions" style="display:none" class="field-row">
        <button class="btn btn-danger btn-block" id="unknown-btn">${icon('x')} Nicht gewusst</button>
        <button class="btn btn-primary btn-block" id="known-btn" style="background:var(--color-success)">${icon('check')} Gewusst</button>
      </div>
    `;
    const flashcardEl = container.querySelector('#flashcard');
    const actionsEl = container.querySelector('#know-actions');
    flashcardEl.addEventListener('click', () => {
      flipped.value = !flipped.value;
      flashcardEl.classList.toggle('is-flipped', flipped.value);
      actionsEl.style.display = flipped.value ? 'flex' : 'none';
    });
    container.querySelector('#known-btn').addEventListener('click', async (e) => { e.stopPropagation(); await answer(true); });
    container.querySelector('#unknown-btn').addEventListener('click', async (e) => { e.stopPropagation(); await answer(false); });

    async function answer(known) {
      await logAnswer(question, known, 'flashcard');
      index += 1;
      if (index < session.length) showCard(); else showDone();
    }
  }

  function showDone() {
    container.innerHTML = `
      <h1>Geschafft!</h1>
      <p>Du hast ${session.length} Karte${session.length === 1 ? '' : 'n'} wiederholt.</p>
      <button class="btn btn-primary btn-block" id="again-btn">${icon('refresh')} Weitere Karten</button>
      <button class="btn btn-secondary btn-block" id="back-btn" style="margin-top:var(--sp-3)">Zur Uebersicht</button>
    `;
    container.querySelector('#again-btn').addEventListener('click', () => renderFlashSession(container, category));
    container.querySelector('#back-btn').addEventListener('click', () => renderOverview(container));
  }

  showCard();
}

/* ================= Hilfsfunktionen ================= */

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function emptyState(text) { return `<div class="empty-state">${icon('brain')}<p>${escapeHtml(text)}</p></div>`; }

function createSheet(innerHtml) {
  const dlg = document.createElement('dialog');
  dlg.className = 'sheet';
  dlg.innerHTML = `<div class="sheet__handle"></div><div class="sheet__body">${innerHtml}</div>`;
  document.body.appendChild(dlg);
  dlg.addEventListener('close', () => dlg.remove());
  dlg.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => dlg.close()));
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  dlg.showModal();
  return dlg;
}
