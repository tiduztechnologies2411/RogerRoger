/**
 * quizData.js – kuratierter Startbestand an Quizfragen.
 *
 * Wichtig (siehe Auftrag, Punkt 15 "Qualitätssicherung"): jede Frage hier wurde
 * bewusst auf gesichertes, unstrittiges Wissen beschränkt (Fachbegriffe, Jahreszahlen,
 * Definitionen). Jede Frage trägt reviewStatus: 'reviewed' und gilt damit als für den
 * aktiven Pool freigegeben. Neue, per Import oder Texteingabe hinzugefügte Fragen
 * starten dagegen immer mit reviewStatus: 'pending' und werden erst nach manueller
 * Freigabe durch den Nutzer aktiv (siehe quiz.js / submitQuestionForReview).
 */
export const CATEGORIES = [
  'Allgemeines Wissen',
  'Geschichte',
  'Geografie',
  'Naturwissenschaften',
  'Technik',
  'Politik & Gesellschaft',
  'Wirtschaft',
  'Kunst & Kultur',
  'Musik',
  'Sport',
  'Filmwissenschaften',
];

let counter = 0;
function q(category, subtopic, difficulty, text, options, correctIndex, explanation) {
  counter += 1;
  return {
    id: `seed-${counter}`,
    category,
    subtopic,
    difficulty, // 'einfach' | 'mittel' | 'schwer'
    text,
    options,
    correctIndex,
    explanation,
    source: 'Redaktionell geprüft – gesichertes Allgemeinwissen',
    createdAt: Date.now(),
    reviewStatus: 'reviewed',
    reported: false,
  };
}

export const SEED_QUESTIONS = [
  // Allgemeines Wissen
  q('Allgemeines Wissen', 'Erdkunde', 'einfach', 'Wie viele Kontinente werden üblicherweise unterschieden?', ['5', '6', '7', '8'], 2, 'Das gängigste Modell unterscheidet 7 Kontinente: Afrika, Antarktika, Asien, Australien, Europa, Nordamerika, Südamerika.'),
  q('Allgemeines Wissen', 'Tierwelt', 'einfach', 'Welches Tier gilt als das schnellste Landtier der Welt?', ['Löwe', 'Gepard', 'Antilope', 'Strauß'], 1, 'Der Gepard erreicht auf kurzen Strecken Geschwindigkeiten von über 100 km/h.'),
  q('Allgemeines Wissen', 'Spiele', 'einfach', 'Wie viele Karten hat ein klassisches Kartenspiel (ohne Joker)?', ['48', '52', '54', '32'], 1, 'Ein klassisches französisches Blatt besteht aus 52 Karten in vier Farben.'),
  q('Allgemeines Wissen', 'Farben', 'einfach', 'Welche Farbe entsteht beim Mischen von Blau und Gelb?', ['Lila', 'Orange', 'Grün', 'Braun'], 2, 'Blau und Gelb ergeben als Mischfarbe Grün.'),
  q('Allgemeines Wissen', 'Kalender', 'mittel', 'Wie viele Tage hat ein Schaltjahr?', ['364', '365', '366', '367'], 2, 'In einem Schaltjahr wird der Februar um einen Tag verlängert, wodurch das Jahr 366 Tage hat.'),
  q('Allgemeines Wissen', 'Erdkunde', 'mittel', 'Welches ist der flächenmäßig größte Ozean der Erde?', ['Atlantik', 'Indischer Ozean', 'Pazifik', 'Arktischer Ozean'], 2, 'Der Pazifik ist mit Abstand der größte Ozean der Erde.'),

  // Geschichte
  q('Geschichte', '20. Jahrhundert', 'einfach', 'In welchem Jahr endete der Zweite Weltkrieg?', ['1943', '1944', '1945', '1946'], 2, 'Der Zweite Weltkrieg endete 1945 mit der bedingungslosen Kapitulation Deutschlands und Japans.'),
  q('Geschichte', 'Deutsche Geschichte', 'einfach', 'In welchem Jahr fiel die Berliner Mauer?', ['1987', '1989', '1991', '1993'], 1, 'Die Berliner Mauer fiel am 9. November 1989.'),
  q('Geschichte', 'Deutsche Geschichte', 'einfach', 'An welchem Datum wurde die Deutsche Wiedervereinigung vollzogen?', ['17. Juni 1990', '9. November 1990', '3. Oktober 1990', '1. Januar 1991'], 2, 'Der 3. Oktober 1990 ist der Tag der Deutschen Einheit.'),
  q('Geschichte', 'Bundesrepublik', 'mittel', 'Wer war der erste Bundeskanzler der Bundesrepublik Deutschland?', ['Willy Brandt', 'Konrad Adenauer', 'Ludwig Erhard', 'Kurt Georg Kiesinger'], 1, 'Konrad Adenauer war von 1949 bis 1963 Bundeskanzler.'),
  q('Geschichte', 'Erster Weltkrieg', 'mittel', 'Welches Ereignis gilt als unmittelbarer Auslöser des Ersten Weltkriegs 1914?', ['Der Untergang der Titanic', 'Das Attentat von Sarajevo', 'Die Oktoberrevolution', 'Der Wiener Kongress'], 1, 'Die Ermordung von Erzherzog Franz Ferdinand in Sarajevo löste eine Kette von Kriegserklärungen aus.'),
  q('Geschichte', 'Antike', 'schwer', 'In welchem Jahrhundert lebte Julius Caesar?', ['3. Jahrhundert v. Chr.', '1. Jahrhundert v. Chr.', '1. Jahrhundert n. Chr.', '5. Jahrhundert n. Chr.'], 1, 'Julius Caesar lebte von 100 bis 44 v. Chr., also im 1. Jahrhundert vor Christus.'),

  // Geografie
  q('Geografie', 'Staaten', 'einfach', 'Welches ist der flächenmäßig größte Staat der Welt?', ['China', 'USA', 'Kanada', 'Russland'], 3, 'Russland ist mit rund 17 Millionen km² das flächenmäßig größte Land der Erde.'),
  q('Geografie', 'Landschaften', 'einfach', 'Auf welchem Kontinent liegt die Sahara?', ['Asien', 'Afrika', 'Südamerika', 'Australien'], 1, 'Die Sahara ist die größte heiße Wüste der Welt und liegt in Nordafrika.'),
  q('Geografie', 'Berge', 'einfach', 'Welches ist der höchste Berg der Welt?', ['K2', 'Mont Blanc', 'Mount Everest', 'Kilimandscharo'], 2, 'Der Mount Everest im Himalaya ist mit 8.849 m der höchste Berg der Erde.'),
  q('Geografie', 'Flüsse', 'einfach', 'Welcher bedeutende Fluss fließt durch Ägypten?', ['Euphrat', 'Nil', 'Ganges', 'Jordan'], 1, 'Der Nil durchquert Ägypten von Süden nach Norden und mündet ins Mittelmeer.'),
  q('Geografie', 'Hauptstädte', 'mittel', 'Wie heißt die Hauptstadt Australiens?', ['Sydney', 'Melbourne', 'Canberra', 'Perth'], 2, 'Nicht Sydney, sondern Canberra ist die Hauptstadt Australiens.'),
  q('Geografie', 'Meere', 'einfach', 'Welches Meer liegt zwischen Europa und Afrika?', ['Nordsee', 'Mittelmeer', 'Rotes Meer', 'Schwarzes Meer'], 1, 'Das Mittelmeer trennt bzw. verbindet Südeuropa und Nordafrika.'),

  // Naturwissenschaften
  q('Naturwissenschaften', 'Chemie', 'einfach', 'Welches chemische Element hat das Symbol "O"?', ['Gold', 'Sauerstoff', 'Osmium', 'Silber'], 1, '"O" steht im Periodensystem für Sauerstoff (Oxygenium).'),
  q('Naturwissenschaften', 'Chemie', 'einfach', 'Was ist die chemische Formel von Wasser?', ['CO2', 'H2O', 'O2', 'NaCl'], 1, 'Wasser besteht aus zwei Wasserstoff- und einem Sauerstoffatom: H2O.'),
  q('Naturwissenschaften', 'Biologie', 'mittel', 'Wie viele Knochen hat das Skelett eines erwachsenen Menschen in etwa?', ['126', '166', '206', '256'], 2, 'Der erwachsene menschliche Körper besteht aus rund 206 Knochen.'),
  q('Naturwissenschaften', 'Physik', 'einfach', 'Welche Kraft hält die Planeten auf ihrer Umlaufbahn um die Sonne?', ['Magnetismus', 'Reibung', 'Gravitation', 'Fliehkraft allein'], 2, 'Die Gravitationskraft der Sonne hält die Planeten auf ihrer Umlaufbahn.'),
  q('Naturwissenschaften', 'Biologie', 'einfach', 'Wie nennt man den Prozess, mit dem Pflanzen Lichtenergie in chemische Energie umwandeln?', ['Osmose', 'Photosynthese', 'Transpiration', 'Fermentation'], 1, 'Bei der Photosynthese wandeln Pflanzen mithilfe von Chlorophyll Lichtenergie in Traubenzucker um.'),
  q('Naturwissenschaften', 'Erdatmosphäre', 'mittel', 'Welches Gas kommt in der Erdatmosphäre am häufigsten vor?', ['Sauerstoff', 'Kohlenstoffdioxid', 'Stickstoff', 'Wasserstoff'], 2, 'Mit rund 78 % ist Stickstoff das häufigste Gas der Erdatmosphäre, nicht Sauerstoff (ca. 21 %).'),

  // Technik
  q('Technik', 'Internet', 'mittel', 'Wer gilt als Erfinder des World Wide Web?', ['Bill Gates', 'Steve Jobs', 'Tim Berners-Lee', 'Mark Zuckerberg'], 2, 'Tim Berners-Lee entwickelte 1989 am CERN die Grundlagen des World Wide Web.'),
  q('Technik', 'Abkürzungen', 'einfach', 'Wofür steht die Abkürzung "USB"?', ['Universal Serial Bus', 'United System Board', 'Universal Save Backup', 'Unit Signal Bridge'], 0, 'USB steht für Universal Serial Bus, eine Schnittstelle zur Datenübertragung.'),
  q('Technik', 'Abkürzungen', 'einfach', 'Wofür steht die Abkürzung "HTML"?', ['High Tech Modern Language', 'HyperText Markup Language', 'Home Tool Markup Language', 'Hyperlink Text Management Language'], 1, 'HTML steht für HyperText Markup Language, die Grundsprache von Webseiten.'),
  q('Technik', 'Netzwerke', 'mittel', 'Wofür steht die Abkürzung "WLAN"?', ['Wireless Local Area Network', 'Wide Line Area Node', 'Wireless Linked Access Node', 'Web Local Access Network'], 0, 'WLAN steht für Wireless Local Area Network, ein kabelloses lokales Funknetzwerk.'),
  q('Technik', 'Informatik', 'mittel', 'Wie nennt man die kleinste Speichereinheit in der Informatik?', ['Byte', 'Pixel', 'Bit', 'Chip'], 2, 'Ein Bit ist die kleinste Informationseinheit und kann nur die Werte 0 oder 1 annehmen.'),

  // Politik & Gesellschaft
  q('Politik & Gesellschaft', 'Deutschland', 'einfach', 'Wie viele Bundesländer hat Deutschland?', ['14', '15', '16', '17'], 2, 'Deutschland besteht aus 16 Bundesländern.'),
  q('Politik & Gesellschaft', 'Deutschland', 'einfach', 'Wie heißt das deutsche Parlament?', ['Bundesrat', 'Bundestag', 'Landtag', 'Reichstag'], 1, 'Der Bundestag ist die vom Volk gewählte Volksvertretung Deutschlands.'),
  q('Politik & Gesellschaft', 'Internationales', 'einfach', 'In welcher Stadt befindet sich der Hauptsitz der Vereinten Nationen?', ['Genf', 'Brüssel', 'New York', 'Den Haag'], 2, 'Das UN-Hauptquartier befindet sich in New York City.'),
  q('Politik & Gesellschaft', 'Deutschland', 'mittel', 'In welchem regulären Turnus finden in Deutschland Bundestagswahlen statt?', ['Alle 2 Jahre', 'Alle 4 Jahre', 'Alle 5 Jahre', 'Alle 6 Jahre'], 1, 'Der Bundestag wird regulär alle vier Jahre neu gewählt.'),
  q('Politik & Gesellschaft', 'Staatslehre', 'mittel', 'Was beschreibt der Begriff "Gewaltenteilung"?', ['Die Aufteilung des Staatsgebiets in Länder', 'Die Trennung von Legislative, Exekutive und Judikative', 'Die Verteilung des Staatshaushalts', 'Die Aufteilung der Armee in Einheiten'], 1, 'Gewaltenteilung bezeichnet die Trennung von gesetzgebender, ausführender und rechtsprechender Gewalt.'),
  q('Politik & Gesellschaft', 'Deutschland', 'mittel', 'Welches Amt in Deutschland hat vorwiegend repräsentative Funktion?', ['Bundeskanzler', 'Bundespräsident', 'Bundestagspräsident', 'Ministerpräsident'], 1, 'Der Bundespräsident vertritt Deutschland vor allem repräsentativ nach außen.'),

  // Wirtschaft
  q('Wirtschaft', 'Europa', 'einfach', 'Welche gemeinsame Währung verwenden die meisten Mitgliedstaaten der EU?', ['Franken', 'Euro', 'Pfund', 'Gulden'], 1, 'Der Euro ist die gemeinsame Währung der Eurozone.'),
  q('Wirtschaft', 'Grundbegriffe', 'einfach', 'Wie nennt man eine anhaltende Steigerung des allgemeinen Preisniveaus?', ['Deflation', 'Rezession', 'Inflation', 'Stagnation'], 2, 'Inflation bezeichnet den anhaltenden Anstieg des allgemeinen Preisniveaus.'),
  q('Wirtschaft', 'Kennzahlen', 'mittel', 'Was misst das Bruttoinlandsprodukt (BIP)?', ['Die Staatsverschuldung', 'Den Wert aller in einem Land produzierten Güter und Dienstleistungen', 'Die Arbeitslosenquote', 'Die Höhe der Steuereinnahmen'], 1, 'Das BIP misst den Gesamtwert aller in einer Periode in einem Land erbrachten Güter und Dienstleistungen.'),
  q('Wirtschaft', 'Institutionen', 'mittel', 'Welche Institution legt die Leitzinsen für den Euroraum fest?', ['Die Weltbank', 'Der Internationale Währungsfonds', 'Die Europäische Zentralbank (EZB)', 'Die Deutsche Bundesbank'], 2, 'Die EZB legt die geldpolitischen Leitzinsen für die gesamte Eurozone fest.'),
  q('Wirtschaft', 'Grundbegriffe', 'einfach', 'Was beschreibt der Begriff "Monopol"?', ['Einen Markt mit vielen kleinen Anbietern', 'Einen Markt mit genau einem Anbieter', 'Einen staatlich subventionierten Markt', 'Einen Markt ohne Nachfrage'], 1, 'Ein Monopol liegt vor, wenn nur ein einziger Anbieter einen Markt beherrscht.'),
  q('Wirtschaft', 'Grundbegriffe', 'mittel', 'Wie nennt man das ökonomische Prinzip, wonach Preise durch das Verhältnis von Angebot und Nachfrage bestimmt werden?', ['Preismechanismus', 'Steuerprogression', 'Skaleneffekt', 'Diversifikation'], 0, 'Der Preismechanismus beschreibt, wie sich Preise am Markt durch Angebot und Nachfrage bilden.'),

  // Kunst & Kultur
  q('Kunst & Kultur', 'Malerei', 'einfach', 'Wer malte die Mona Lisa?', ['Michelangelo', 'Raffael', 'Leonardo da Vinci', 'Sandro Botticelli'], 2, 'Die Mona Lisa ist ein Werk von Leonardo da Vinci, entstanden Anfang des 16. Jahrhunderts.'),
  q('Kunst & Kultur', 'Literatur', 'einfach', 'Wer schrieb das Drama "Faust"?', ['Friedrich Schiller', 'Johann Wolfgang von Goethe', 'Heinrich Heine', 'Thomas Mann'], 1, 'Goethe schrieb "Faust" als sein Lebenswerk in zwei Teilen.'),
  q('Kunst & Kultur', 'Malerei', 'mittel', 'Aus welchem Land stammt die Kunstrichtung des Impressionismus?', ['Italien', 'Spanien', 'Frankreich', 'Niederlande'], 2, 'Der Impressionismus entstand im 19. Jahrhundert in Frankreich, u.a. mit Claude Monet.'),
  q('Kunst & Kultur', 'Malerei', 'einfach', 'Welcher Künstler gilt als Mitbegründer des Kubismus?', ['Salvador Dalí', 'Pablo Picasso', 'Vincent van Gogh', 'Gustav Klimt'], 1, 'Pablo Picasso entwickelte gemeinsam mit Georges Braque den Kubismus.'),
  q('Kunst & Kultur', 'Literatur', 'mittel', 'Wer schrieb die Erzählung "Die Verwandlung"?', ['Franz Kafka', 'Thomas Mann', 'Hermann Hesse', 'Bertolt Brecht'], 0, '"Die Verwandlung" ist eine 1915 erschienene Erzählung von Franz Kafka.'),
  q('Kunst & Kultur', 'Architektur', 'mittel', 'In welcher Stadt befindet sich die Sixtinische Kapelle?', ['Florenz', 'Venedig', 'Vatikanstadt', 'Mailand'], 2, 'Die Sixtinische Kapelle liegt im Vatikan und ist berühmt für Michelangelos Deckenfresko.'),

  // Musik
  q('Musik', 'Instrumente', 'einfach', 'Wie viele Saiten hat eine klassische Gitarre üblicherweise?', ['4', '5', '6', '7'], 2, 'Eine klassische Konzertgitarre hat standardmäßig 6 Saiten.'),
  q('Musik', 'Klassik', 'einfach', 'Welcher Komponist schrieb die 9. Sinfonie mit der "Ode an die Freude"?', ['Johannes Brahms', 'Ludwig van Beethoven', 'Joseph Haydn', 'Franz Schubert'], 1, 'Beethovens 9. Sinfonie enthält im Schlusssatz die weltberühmte "Ode an die Freude".'),
  q('Musik', 'Popmusik', 'einfach', 'Aus welcher britischen Stadt stammen die Beatles?', ['London', 'Manchester', 'Liverpool', 'Birmingham'], 2, 'Die Beatles wurden in Liverpool gegründet.'),
  q('Musik', 'Musiktheorie', 'mittel', 'Wie nennt man die Tonfolge von acht Stufen, die zum Ausgangston zurückführt?', ['Terz', 'Oktave', 'Quinte', 'Kadenz'], 1, 'Eine Oktave umfasst acht Tonstufen und endet beim Ausgangston in doppelter bzw. halber Frequenz.'),
  q('Musik', 'Instrumente', 'einfach', 'Welches Tasteninstrument hat traditionell 88 Tasten?', ['Orgel', 'Klavier', 'Cembalo', 'Akkordeon'], 1, 'Ein modernes Klavier hat in der Regel 88 Tasten.'),
  q('Musik', 'Klassik', 'einfach', 'Welcher österreichische Komponist galt bereits als Kind als musikalisches Wunderkind?', ['Joseph Haydn', 'Wolfgang Amadeus Mozart', 'Franz Liszt', 'Anton Bruckner'], 1, 'Mozart komponierte und konzertierte bereits im Kindesalter.'),

  // Sport
  q('Sport', 'Fußball', 'einfach', 'Wie viele Spieler einer Mannschaft stehen beim Fußball gleichzeitig auf dem Feld?', ['9', '10', '11', '12'], 2, 'Jede Mannschaft stellt inklusive Torwart 11 Spieler.'),
  q('Sport', 'Olympia', 'einfach', 'Wie viele Ringe zeigt das olympische Symbol?', ['4', '5', '6', '7'], 1, 'Die olympischen Ringe stehen für die fünf bewohnten Kontinente und sind ein Symbol der Olympischen Spiele.'),
  q('Sport', 'Olympia', 'einfach', 'In welchem regulären Turnus finden die Olympischen Sommerspiele statt?', ['Alle 2 Jahre', 'Alle 3 Jahre', 'Alle 4 Jahre', 'Alle 5 Jahre'], 2, 'Die Olympischen Sommerspiele finden traditionell alle vier Jahre statt.'),
  q('Sport', 'Laufsport', 'mittel', 'Wie lang ist ein Marathonlauf offiziell?', ['40,195 km', '41,195 km', '42,195 km', '43,195 km'], 2, 'Die offizielle Marathondistanz beträgt 42,195 Kilometer.'),
  q('Sport', 'Ballsport', 'mittel', 'In welcher Sportart bezeichnet man einen nicht returnierten Aufschlagpunkt als "Ass"?', ['Tennis', 'Fußball', 'Handball', 'Golf'], 0, 'Im Tennis ist ein Ass ein direkter, nicht erreichbarer Aufschlagpunkt.'),
  q('Sport', 'Ballsport', 'mittel', 'Welche Sportart wird auf einem Feld mit vier "Bases" in Diamantform gespielt?', ['Cricket', 'Baseball', 'Softball-Golf', 'Rugby'], 1, 'Baseball wird auf einem diamantförmigen Feld mit vier Bases gespielt.'),

  // Filmwissenschaften
  q('Filmwissenschaften', 'Kamera', 'einfach', 'Wie nennt man eine Einstellung, die vor allem Kopf und Schultern einer Person zeigt?', ['Totale', 'Nahaufnahme', 'Halbtotale', 'Supertotale'], 1, 'Die Nahaufnahme (auch "Close-up") konzentriert sich auf Kopf und Schultern, um Emotionen zu betonen.'),
  q('Filmwissenschaften', 'Kamera', 'mittel', 'Wie wird eine Kameraperspektive genannt, bei der von unten nach oben gefilmt wird und Personen dadurch mächtiger wirken?', ['Vogelperspektive', 'Normalsicht', 'Untersicht (Froschperspektive)', 'Seitliche Aufsicht'], 2, 'Die Untersicht bzw. Froschperspektive lässt Personen oder Objekte größer und dominanter wirken.'),
  q('Filmwissenschaften', 'Kamera', 'mittel', 'Was beschreibt der Begriff "Schärfentiefe" (Tiefenschärfe)?', ['Die Farbsättigung eines Bildes', 'Den Bereich vor der Kamera, der scharf abgebildet wird', 'Die Brennweite eines Objektivs', 'Die Belichtungszeit einer Aufnahme'], 1, 'Die Schärfentiefe bezeichnet den Bereich im Bild, der scharf erscheint, unabhängig vom Fokuspunkt.'),
  q('Filmwissenschaften', 'Montage', 'mittel', 'Wie nennt man einen Schnitt, der zwei gleichzeitig an unterschiedlichen Orten stattfindende Handlungen abwechselnd zeigt?', ['Kontinuitätsmontage', 'Parallelmontage', 'Match Cut', 'Jump Cut'], 1, 'Die Parallelmontage verschränkt zwei zeitgleiche Handlungsstränge miteinander.'),
  q('Filmwissenschaften', 'Montage', 'mittel', 'Wie nennt man einen Schnitt, der die zeitliche Kontinuität innerhalb derselben Einstellung sprunghaft und sichtbar unterbricht?', ['Jump Cut', 'Match Cut', 'Überblendung', 'Establishing Shot'], 0, 'Ein Jump Cut erzeugt durch das Weglassen von Bildmaterial einen sichtbaren "Sprung" in der Zeit.'),
  q('Filmwissenschaften', 'Montage', 'schwer', 'Wie nennt man einen Schnitt, bei dem zwei Einstellungen durch eine formale oder inhaltliche Ähnlichkeit (z.B. Form oder Bewegung) miteinander verknüpft werden?', ['Cross-Cut', 'Match Cut', 'L-Cut', 'Smash Cut'], 1, 'Ein bekanntes Beispiel ist der Schnitt vom Knochen zum Raumschiff in "2001: Odyssee im Weltraum".'),
  q('Filmwissenschaften', 'Ton', 'mittel', 'Wie nennt man Ton, dessen Quelle innerhalb der erzählten Filmwelt sichtbar oder vorstellbar ist, z.B. Dialog oder Musik aus einem Radio im Bild?', ['Nicht-diegetischer Ton', 'Diegetischer Ton', 'Off-Screen-Ton ausschließlich', 'Score ohne Quelle'], 1, 'Diegetischer Ton entspringt einer Quelle innerhalb der Filmhandlung, im Gegensatz zu nicht-diegetischer Filmmusik.'),
  q('Filmwissenschaften', 'Mise-en-scène', 'schwer', 'Was umfasst der aus dem Theater stammende Begriff "Mise-en-scène" im Film?', ['Nur die Kameraführung', 'Alles, was vor der Kamera arrangiert wird: Licht, Ausstattung, Kostüm, Raumgestaltung', 'Ausschließlich den Filmschnitt', 'Nur die Tonspur'], 1, 'Mise-en-scène bezeichnet die bewusste Gestaltung allem, was im Bild zu sehen ist, bevor überhaupt geschnitten wird.'),
];
