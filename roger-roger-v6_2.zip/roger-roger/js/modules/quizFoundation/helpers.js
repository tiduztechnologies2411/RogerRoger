/**
 * helpers.js – kleiner Hilfsbaustein für die Fundament-Kategorie-Dateien (siehe index.js).
 *
 * Erzeugt stabile, lesbare IDs nach dem Schema `foundation-<prefix>-NNN` (siehe Auftrag
 * "Quiz-Fundament"). Diese IDs sind das Duplikaterkennungsmerkmal beim App-Start
 * (`ensureFoundationSeeded()` in quiz.js) – ein bewusst anderes, einfacheres Merkmal als
 * die hash-basierte `stableQuestionId()`, die separat beim JSON-Import verwendet wird
 * (siehe CLAUDE.md, Abschnitt "Quiz-Fundament" nach v6.0-Ausbau).
 */
export function makeCategoryBuilder(idPrefix, category) {
  let counter = 0;
  return function q(subtopic, difficulty, text, options, correctIndex, explanation) {
    counter += 1;
    const num = String(counter).padStart(3, '0');
    return {
      id: `foundation-${idPrefix}-${num}`,
      category,
      subtopic,
      difficulty, // 'einfach' | 'mittel' | 'schwer'
      text,
      options,
      correctIndex,
      explanation,
    };
  };
}
