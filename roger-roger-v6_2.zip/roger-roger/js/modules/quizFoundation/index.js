/**
 * index.js – Einstiegspunkt des Quiz-Fundaments (V6.0).
 *
 * Fasst die 10 Kategorie-Dateien zu einem einzigen, statischen Datensatz von 1.000
 * Fragen zusammen. Dieser Datensatz ist Teil der Codebasis (nicht der Benutzerdaten in
 * IndexedDB) – siehe quiz.js/ensureFoundationSeeded() für die Bereitstellung beim
 * App-Start und die Abgrenzung zu importierten Benutzerfragen.
 *
 * WICHTIG: Diese Datei absichtlich schlank halten. Die eigentlichen Fragen gehören in
 * die jeweilige Kategorie-Datei (geography.js, history.js, ...), nicht hierher.
 */
import { geography } from './geography.js';
import { history } from './history.js';
import { naturalScience } from './naturalScience.js';
import { filmStudies } from './filmStudies.js';
import { artCulture } from './artCulture.js';
import { languageLiterature } from './languageLiterature.js';
import { technology } from './technology.js';
import { economicsPolitics } from './economicsPolitics.js';
import { sports } from './sports.js';
import { astronomy } from './astronomy.js';

/** Die 10 Fundament-Kategorien in fester, vorgegebener Reihenfolge (siehe Auftrag
 * "Quiz-Fundament"). Bewusst getrennt von den historisch gewachsenen Kategorienamen
 * aus v1.0-v2.0 (z.B. "Filmwissenschaften" statt "Filmwissenschaft", "Musik" separat
 * von "Kunst & Kultur") – beide Kategoriesätze koexistieren unangetastet nebeneinander,
 * siehe CLAUDE.md für die Begründung dieser bewussten Entscheidung. */
export const FOUNDATION_CATEGORIES = [
  'Geografie',
  'Geschichte',
  'Naturwissenschaften',
  'Filmwissenschaft',
  'Kunst & Kultur',
  'Sprache & Literatur',
  'Technik & Informatik',
  'Wirtschaft & Politik',
  'Sport',
  'Astronomie & Weltraum',
];

const RAW_QUESTIONS = [
  ...geography, ...history, ...naturalScience, ...filmStudies, ...artCulture,
  ...languageLiterature, ...technology, ...economicsPolitics, ...sports, ...astronomy,
];

/** Die vollständigen 1.000 Fundamentfragen im tatsächlichen quizQuestions-Schema der
 * App (siehe quiz.js). `source: 'foundation'` unterscheidet sie von Benutzerfragen
 * ('seed' aus v1.0, 'import' aus dem JSON-Import) – rein informativ, beeinflusst keine
 * Filterlogik. `reviewStatus: 'reviewed'` sorgt dafür, dass sie sofort im aktiven Pool
 * erscheinen (siehe getActiveQuestions in quiz.js), analog zu den v1.0-Seed-Fragen. */
export const FOUNDATION_QUESTIONS = RAW_QUESTIONS.map((q) => ({
  ...q,
  tags: [],
  source: 'foundation',
  createdAt: Date.now(),
  reviewStatus: 'reviewed',
  reported: false,
}));
