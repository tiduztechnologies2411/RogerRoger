/**
 * quizPrompt.js – Master-Prompt zur externen Erzeugung von Quizfragen-Katalogen.
 *
 * WICHTIG: Dieser Prompt muss exakt zum Importschema passen, das in quiz.js
 * (validateImportPayload) implementiert ist. Wird das Schema geändert,
 * MUSS PROMPT_VERSION erhöht und der Text hier aktualisiert werden (siehe CLAUDE.md,
 * Regel 6/9).
 */

export const PROMPT_VERSION = 'v1.0';

export const MASTER_PROMPT = `Du erstellst einen Fragenkatalog für die Lern-App "Roger Roger" im
folgenden exakten JSON-Format. Gib AUSSCHLIESSLICH valides JSON zurück –
keinen einleitenden Text, keine Erklärungen, keine Markdown-Codeblock-Markierungen.

FORMAT:
{
  "schemaVersion": "1.0",
  "category": "Name der Kategorie",
  "questions": [
    {
      "text": "Fragetext",
      "options": ["Antwort A", "Antwort B", "Antwort C", "Antwort D"],
      "correctIndex": 0,
      "explanation": "Kurze, fundierte Erklärung, warum diese Antwort korrekt ist.",
      "difficulty": "mittel",
      "subtopic": "Optionales Unterthema",
      "tags": ["optional", "stichworte"]
    }
  ]
}

REGELN:
- "schemaVersion" ist immer der String "1.0".
- "category" auf oberster Ebene gilt für alle Fragen, die kein eigenes "category"-Feld
  besitzen. Einzelne Fragen dürfen optional ein eigenes "category" tragen, falls du
  einen gemischten Katalog mit mehreren Kategorien erzeugst.
- "questions" ist ein Array mit mindestens 1 Frage.
- "text": vollständiger, eindeutig formulierter Fragetext ohne Ja/Nein-Fragen.
- "options": genau 4 Antwortmöglichkeiten (Ausnahme nur wenn fachlich nicht anders
  sinnvoll darstellbar, dann 2-6 erlaubt). Alle Optionen müssen nicht-leer und
  inhaltlich eindeutig unterscheidbar sein (keine Dopplungen, keine Trivial-Distraktoren).
  Falsche Antworten (Distraktoren) müssen plausibel, aber eindeutig falsch sein.
- "correctIndex": nullbasierter Index (0 = erste Option) der EINEN korrekten Antwort.
  Es darf immer nur genau eine Antwort korrekt sein.
- "explanation": 1-2 Sätze, die die richtige Antwort sachlich begründen.
- "difficulty": einer von "einfach", "mittel", "schwer".
- "subtopic" und "tags" sind optional, aber hilfreich für spätere Filterung.
- Sprache: durchgehend Deutsch.
- Nur gesichertes, unstrittiges Allgemeinwissen verwenden, keine Meinungen oder
  tagesaktuellen/veränderlichen Fakten (z.B. keine aktuellen Amtsinhaber).
- Keine doppelten Fragen innerhalb des Katalogs.
- Gib NUR das JSON-Objekt zurück, keinen Text davor oder danach.

Erstelle jetzt einen Fragenkatalog nach diesem Schema für folgendes Thema und
folgende Anzahl an Fragen (vom Nutzer zu ergänzen):

Thema: [z.B. "Europäische Geschichte"]
Anzahl Fragen: [z.B. 100]
Schwierigkeit: [z.B. "gemischt" oder "mittel"]`;
