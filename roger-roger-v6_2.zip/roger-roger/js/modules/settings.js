import { db } from '../core/db.js';
import { icon } from '../core/icons.js';
import { downscaleImage, toast, uid, escapeHtml } from '../core/utils.js';
import { b64ToBytes, deriveKeyFromPin, encryptJSON, decryptJSON } from '../core/crypto.js';
import * as notesModule from './notes.js';
import { ensureFoundationSeeded } from './quiz.js';
import { THEMES, getCurrentTheme, setTheme, loadStoredTheme } from '../core/theme.js';
import {
  MODULE_DEFS, getAllModulesSorted, getModuleConfig, setModuleEnabled, setModuleOrder,
} from '../core/moduleRegistry.js';

const NAME_KEY = 'userName';
const AUTO_BG_KEY = 'autoBackgroundSwitch';
const ACTIVE_BG_KEY = 'activeBackgroundId';

/* ================= App-Daten-Backup (V5.2) =================
 * Baut auf db.exportAll()/db.importAll() auf (bereits generisch über ALLE Stores, siehe
 * db.js) und ergänzt: eine versionierte Hülle mit Metadaten, optionale Verschlüsselung des
 * GESAMTEN Backups mit der bestehenden "Sicher"-PIN-Kryptografie (core/crypto.js – keine
 * eigene Kryptografie), eine Datenübersicht + Bestätigung vor dem Import, sowie ein
 * automatisches Rollback bei fehlgeschlagenem Import (siehe exportBackup/startImportFlow unten).
 *
 * WICHTIG für künftige Claude-Sessions: APP_VERSION hier bei jeder neuen App-Version
 * mit hochzählen (siehe CLAUDE.md Abschnitt 2) – rein informativ fürs Backup-Metadatenfeld,
 * hat keinen Einfluss auf Import-Kompatibilität (die hängt nur von BACKUP_VERSION ab).
 */
const APP_NAME = 'Roger Roger';
const APP_VERSION = 'v6.2';
const BACKUP_VERSION = 1; // Format der Backup-Hülle (meta+data / meta+cipher). Bei künftigen strukturellen Änderungen hochzählen.

export async function getUserName() {
  const row = await db.get(db.STORES.settings, NAME_KEY);
  return row?.value || '';
}

export async function setUserName(name) {
  await db.put(db.STORES.settings, { key: NAME_KEY, value: name });
}

export async function isAutoBackgroundEnabled() {
  const row = await db.get(db.STORES.settings, AUTO_BG_KEY);
  return row?.value ?? true;
}

export async function setAutoBackgroundEnabled(val) {
  await db.put(db.STORES.settings, { key: AUTO_BG_KEY, value: val });
}

export async function getActiveBackgroundId() {
  const row = await db.get(db.STORES.settings, ACTIVE_BG_KEY);
  return row?.value || null;
}

export async function setActiveBackgroundId(id) {
  await db.put(db.STORES.settings, { key: ACTIVE_BG_KEY, value: id });
}

export async function getBackgrounds() {
  return db.getAll(db.STORES.backgrounds);
}

export async function addBackground(file) {
  const blob = await downscaleImage(file);
  const row = { id: uid(), imageBlob: blob, createdAt: Date.now() };
  await db.put(db.STORES.backgrounds, row);
  return row;
}

export async function removeBackground(id) {
  await db.remove(db.STORES.backgrounds, id);
  const active = await getActiveBackgroundId();
  if (active === id) await setActiveBackgroundId(null);
}

/** Wählt zufällig ein anderes Hintergrundbild als das aktuell aktive */
export async function rotateToNextBackground() {
  const all = await getBackgrounds();
  if (!all.length) return null;
  const current = await getActiveBackgroundId();
  const candidates = all.filter((b) => b.id !== current);
  const pick = candidates.length ? candidates[Math.floor(Math.random() * candidates.length)] : all[0];
  await setActiveBackgroundId(pick.id);
  return pick;
}

export async function render(container) {
  const name = await getUserName();
  const autoBg = await isAutoBackgroundEnabled();
  const backgrounds = await getBackgrounds();
  const activeBgId = await getActiveBackgroundId();
  const modules = await getAllModulesSorted();
  const config = await getModuleConfig();

  container.innerHTML = `
    <h1>Einstellungen</h1>

    <section class="settings-group">
      <h2>Persönlich</h2>
      <div class="card">
        <div class="field" style="margin-bottom:0">
          <label for="set-name">Name</label>
          <input id="set-name" type="text" value="${escAttr(name)}" placeholder="Wie soll die App dich nennen?" maxlength="40" />
        </div>
      </div>
    </section>

    <section class="settings-group">
      <h2>Design</h2>
      <div class="theme-picker" id="theme-picker" role="radiogroup" aria-label="Design auswählen">
        ${THEMES.map((t) => themeCard(t, t.id === getCurrentTheme())).join('')}
      </div>
    </section>

    <section class="settings-group">
      <h2>Module</h2>
      <p class="field-hint" style="margin-bottom:var(--sp-3)">Ziehe die Griffe, um die Reihenfolge auf dem Dashboard zu ändern. Deaktivierte Module verlieren keine Daten.</p>
      <div class="list" id="module-list">
        ${modules.map((m) => moduleRow(m, config[m.id]?.enabled)).join('')}
      </div>
    </section>

    <section class="settings-group">
      <h2>Hintergrundbilder</h2>
      <div class="card">
        <div class="bg-gallery" id="bg-gallery">
          ${backgrounds.map((b) => bgThumb(b, b.id === activeBgId)).join('')}
          <button class="bg-add" id="bg-add-btn" type="button" aria-label="Bild hinzufügen">${icon('plus')}</button>
        </div>
        <input type="file" id="bg-file-input" accept="image/*" multiple hidden />
        <div class="checkbox-row" style="margin-top:var(--sp-4)">
          <input type="checkbox" id="auto-bg-toggle" ${autoBg ? 'checked' : ''} />
          <label for="auto-bg-toggle" style="margin:0">Beim Öffnen automatisch wechseln</label>
        </div>
      </div>
    </section>

    <section class="settings-group">
      <h2>Daten &amp; Backup</h2>
      <div class="card list">
        <button class="btn btn-secondary btn-block" id="export-btn" type="button">${icon('download')} App-Daten exportieren</button>
        <button class="btn btn-secondary btn-block" id="import-btn" type="button">${icon('upload')} App-Daten importieren</button>
        <input type="file" id="import-file-input" accept="application/json" hidden />
        <p class="field-hint">Das Backup enthält alle lokalen Daten – Quiz, Sport, Kalender, Notizen, Filme &amp; Serien, Dailies/Schritte, Hintergrundbilder und Einstellungen – als versionierte JSON-Datei zur Sicherung oder Übertragung auf ein anderes Gerät. Inhalte aus "Sicher" bleiben dabei immer verschlüsselt.</p>
      </div>
    </section>
  `;

  container.querySelector('#set-name').addEventListener('change', async (e) => {
    await setUserName(e.target.value.trim());
    toast('Name gespeichert');
  });

  // Design wählen (V6.1): sofort anwenden + dauerhaft speichern, kein Neuladen
  container.querySelectorAll('[data-theme-select]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.themeSelect;
      if (id === getCurrentTheme()) return;
      await setTheme(id);
      container.querySelectorAll('[data-theme-select]').forEach((b) => {
        const active = b.dataset.themeSelect === id;
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-checked', String(active));
      });
      toast(`Design „${THEMES.find((t) => t.id === id).label}“ aktiv`);
    });
  });

  // Module aktivieren/deaktivieren
  container.querySelectorAll('[data-module-toggle]').forEach((el) => {
    el.addEventListener('change', async (e) => {
      await setModuleEnabled(el.dataset.moduleToggle, e.target.checked);
      toast(e.target.checked ? 'Modul aktiviert' : 'Modul deaktiviert');
      window.dispatchEvent(new CustomEvent('rr:modules-changed'));
    });
  });

  setupModuleDragDrop(container);

  // Hintergrundbilder
  const fileInput = container.querySelector('#bg-file-input');
  container.querySelector('#bg-add-btn').addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', async (e) => {
    const files = Array.from(e.target.files || []);
    for (const file of files) {
      try {
        await addBackground(file);
      } catch (err) {
        toast('Bild konnte nicht importiert werden', 'danger');
      }
    }
    fileInput.value = '';
    render(container);
  });

  container.querySelectorAll('[data-bg-remove]').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      await removeBackground(btn.dataset.bgRemove);
      render(container);
    });
  });
  container.querySelectorAll('[data-bg-select]').forEach((thumb) => {
    thumb.addEventListener('click', async () => {
      await setActiveBackgroundId(thumb.dataset.bgSelect);
      render(container);
    });
  });
  container.querySelector('#auto-bg-toggle').addEventListener('change', async (e) => {
    await setAutoBackgroundEnabled(e.target.checked);
  });

  // Export / Import (V5.2, siehe exportBackup/startImportFlow unten)
  container.querySelector('#export-btn').addEventListener('click', () => startExportFlow());
  const importInput = container.querySelector('#import-file-input');
  container.querySelector('#import-btn').addEventListener('click', () => importInput.click());
  importInput.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    importInput.value = ''; // sofort zurücksetzen, damit dieselbe Datei erneut wählbar ist
    if (!file) return;
    await startImportFlow(file, container);
  });
}

/** Vorschaukarte für ein Theme (V6.1). Die Farben stammen aus THEMES.preview und sind bewusst
 *  fest (sie zeigen das jeweilige Theme, nicht das gerade aktive). */
function themeCard(theme, isActive) {
  const p = theme.preview;
  return `
    <button type="button" class="theme-card ${isActive ? 'is-active' : ''}" data-theme-select="${theme.id}" role="radio" aria-checked="${isActive}">
      <span class="theme-card__preview" style="background:${p.bg};border-color:${p.border}">
        <span class="theme-card__sheet" style="background:${p.card};border-color:${p.border}">
          <span class="theme-card__line" style="background:${p.ink}"></span>
          <span class="theme-card__line theme-card__line--short" style="background:${p.ink}"></span>
          <span class="theme-card__bar" style="background:${p.gradient}"></span>
        </span>
      </span>
      <span class="theme-card__name">${escapeHtml(theme.label)}</span>
      <span class="theme-card__desc">${escapeHtml(theme.desc)}</span>
      <span class="theme-card__check" aria-hidden="true">${icon('check')}</span>
    </button>`;
}

function moduleRow(def, enabled) {
  return `
    <div class="settings-module-row" draggable="true" data-module-id="${def.id}">
      <span class="settings-module-row__handle" aria-hidden="true">⠿</span>
      <span class="module-tile__icon" style="width:32px;height:32px">${icon(def.icon)}</span>
      <span style="flex:1;font-weight:600">${def.label}</span>
      <label class="switch">
        <input type="checkbox" data-module-toggle="${def.id}" ${enabled ? 'checked' : ''} />
        <span class="switch__track"></span>
        <span class="switch__thumb"></span>
      </label>
    </div>`;
}

function bgThumb(bg, isActive) {
  const url = URL.createObjectURL(bg.imageBlob);
  return `
    <div class="bg-thumb ${isActive ? 'is-active' : ''}" data-bg-select="${bg.id}">
      <img src="${url}" alt="Hintergrundbild" loading="lazy" />
      <button class="bg-thumb__remove" data-bg-remove="${bg.id}" type="button" aria-label="Entfernen">${icon('x')}</button>
    </div>`;
}

function setupModuleDragDrop(container) {
  const list = container.querySelector('#module-list');
  let dragEl = null;
  list.querySelectorAll('.settings-module-row').forEach((row) => {
    row.addEventListener('dragstart', () => { dragEl = row; row.classList.add('is-dragging'); });
    row.addEventListener('dragend', () => { row.classList.remove('is-dragging'); dragEl = null; persistOrder(list); });
    row.addEventListener('dragover', (e) => {
      e.preventDefault();
      if (!dragEl || dragEl === row) return;
      const rect = row.getBoundingClientRect();
      const before = e.clientY < rect.top + rect.height / 2;
      list.insertBefore(dragEl, before ? row : row.nextSibling);
    });
  });
}

async function persistOrder(list) {
  const ids = Array.from(list.querySelectorAll('.settings-module-row')).map((r) => r.dataset.moduleId);
  await setModuleOrder(ids);
  window.dispatchEvent(new CustomEvent('rr:modules-changed'));
}

/* ---------- Export ---------- */

async function startExportFlow() {
  const hasPin = await notesModule.hasSecurePin();
  if (!hasPin) {
    await exportBackup(null);
    return;
  }
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Backup verschlüsseln?</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <p class="field-hint">Du hast einen geschützten Bereich ("Sicher") eingerichtet. Inhalte aus "Sicher" sind in jedem Fall verschlüsselt. Zusätzlich kannst du das <strong>gesamte</strong> Backup mit deiner Sicher-PIN verschlüsseln – empfehlenswert, wenn du die Datei teilst oder extern speicherst.</p>
    <div class="list">
      <button class="btn btn-primary btn-block" id="export-encrypted-btn">${icon('lock')} Mit PIN verschlüsseln</button>
      <button class="btn btn-secondary btn-block" id="export-plain-btn">Ohne zusätzliche Verschlüsselung</button>
    </div>
  `);
  dlg.querySelector('#export-plain-btn').addEventListener('click', async () => {
    dlg.close();
    await exportBackup(null);
  });
  dlg.querySelector('#export-encrypted-btn').addEventListener('click', async () => {
    dlg.close();
    const pin = await promptPin('PIN für die Backup-Verschlüsselung', 'Gib deine Sicher-PIN ein, um damit das gesamte Backup zu verschlüsseln.');
    if (pin == null) return; // abgebrochen
    const cfg = await notesModule.getSecureAuthConfig();
    let key;
    try {
      key = await deriveKeyFromPin(pin, b64ToBytes(cfg.salt));
      await decryptJSON(key, cfg.verifierCipher, cfg.verifierIv); // wirft bei falscher PIN
    } catch (e) {
      toast('Die Eingabe ist nicht korrekt.', 'danger');
      return;
    }
    await exportBackup({ key, saltB64: cfg.salt });
  });
}

/** encryption: null für Klartext-Hülle, sonst { key, saltB64 } (Schlüssel bereits aus der PIN abgeleitet). */
async function exportBackup(encryption) {
  const data = await db.exportAll();
  const meta = {
    appName: APP_NAME,
    backupVersion: BACKUP_VERSION,
    appVersion: APP_VERSION,
    createdAt: new Date().toISOString(),
    encrypted: !!encryption,
  };
  let payload;
  if (encryption) {
    const { cipher, iv } = await encryptJSON(encryption.key, { data });
    payload = { meta: { ...meta, salt: encryption.saltB64, iv }, cipher };
  } else {
    payload = { meta, data };
  }

  const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const stamp = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `roger-roger-backup-${stamp}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  toast(`Backup erfolgreich erstellt (${formatBytes(blob.size)})`);
}

/* ---------- Import ---------- */

async function startImportFlow(file, container) {
  let text;
  try {
    text = await file.text();
  } catch (e) {
    toast('Diese Datei konnte nicht gelesen werden.', 'danger');
    return;
  }

  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch (e) {
    toast('Diese Datei ist kein gültiges Roger-Roger-Backup.', 'danger');
    return;
  }

  const parsedResult = interpretBackupFile(parsed);
  if (parsedResult.error) {
    toast(parsedResult.error, 'danger');
    return;
  }

  let { data, encrypted, meta } = parsedResult;

  if (encrypted) {
    const pin = await promptPin('Backup entschlüsseln', 'Dieses Backup ist verschlüsselt. Gib die zugehörige PIN ein.');
    if (pin == null) return; // abgebrochen
    try {
      const key = await deriveKeyFromPin(pin, b64ToBytes(meta.salt));
      const decrypted = await decryptJSON(key, parsedResult.cipher, meta.iv);
      data = decrypted.data;
    } catch (e) {
      toast('Die Eingabe ist nicht korrekt.', 'danger');
      return;
    }
  }

  if (!isPlausibleBackupData(data)) {
    toast('Das Backup konnte nicht vollständig gelesen werden.', 'danger');
    return;
  }

  const proceed = await confirmImportWithSummary(data, meta);
  if (!proceed) return;

  await performImportWithRollback(data, container);
}

/** Erkennt das Backup-Format: neue versionierte Hülle (V5.2) oder alte, hüllenlose Rohform
 * (v1.0–v5.1, direkt db.exportAll()-Output). Baut keine echte Migrationsarchitektur – prüft
 * nur, ob die vorliegende backupVersion von diesem Code verstanden wird. */
function interpretBackupFile(parsed) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { error: 'Diese Datei ist kein gültiges Roger-Roger-Backup.' };
  }
  if (parsed.meta && typeof parsed.meta === 'object') {
    const meta = parsed.meta;
    if (typeof meta.backupVersion !== 'number') {
      return { error: 'Diese Datei ist kein gültiges Roger-Roger-Backup.' };
    }
    if (meta.backupVersion > BACKUP_VERSION) {
      return { error: 'Diese Backup-Version wird von dieser App-Version nicht unterstützt.' };
    }
    if (meta.encrypted) {
      if (typeof parsed.cipher !== 'string' || !meta.salt || !meta.iv) {
        return { error: 'Das Backup konnte nicht vollständig gelesen werden.' };
      }
      return { encrypted: true, cipher: parsed.cipher, meta };
    }
    if (!parsed.data || typeof parsed.data !== 'object') {
      return { error: 'Das Backup konnte nicht vollständig gelesen werden.' };
    }
    return { encrypted: false, data: parsed.data, meta };
  }
  // Alte, hüllenlose Rohform (kein "meta"): gilt als backupVersion 0, direkt db.exportAll()-Output
  const knownStoreKeys = Object.values(db.STORES);
  const looksLikeLegacyExport = Object.keys(parsed).some((k) => knownStoreKeys.includes(k));
  if (!looksLikeLegacyExport) {
    return { error: 'Diese Datei ist kein gültiges Roger-Roger-Backup.' };
  }
  return { encrypted: false, data: parsed, meta: { backupVersion: 0, createdAt: null } };
}

/** Grobe Plausibilitätsprüfung ohne vollständige Schema-Validierung (siehe Auftrag: keine
 * unnötig komplexe Migrationsarchitektur) – reicht aus, um ein beschädigtes/leeres/falsches
 * JSON zu erkennen, bevor irgendetwas importiert wird. */
function isPlausibleBackupData(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return false;
  const knownStoreKeys = Object.values(db.STORES);
  return Object.keys(data).some((k) => knownStoreKeys.includes(k) && Array.isArray(data[k]));
}

/** Für die Datenübersicht vor dem Import (Auftrag Abschnitt 12) – nur die Bereiche zählen,
 * die für den Nutzer sichtbar/bedeutsam sind, nicht jeden technischen Store einzeln. */
function summarizeBackupData(data) {
  const count = (store) => (Array.isArray(data[store]) ? data[store].length : 0);
  const entries = [
    ['Quizfragen', count(db.STORES.quizQuestions)],
    ['Trainingspläne', count(db.STORES.trainingPlans)],
    ['absolvierte Trainings', count(db.STORES.workoutSessions)],
    ['Kalendertermine', count(db.STORES.appointments)],
    ['Geburtstage', count(db.STORES.birthdays)],
    ['Notizen', count(db.STORES.notes)],
    ['Filme/Serien', count(db.STORES.watchlist)],
    ['geschützte Notizen', count(db.STORES.secureNotes)],
    ['Dailies', count(db.STORES.dailies)],
  ];
  return entries.filter(([, n]) => n > 0);
}

async function confirmImportWithSummary(data, meta) {
  const summary = summarizeBackupData(data);
  const dateLabel = meta?.createdAt ? new Date(meta.createdAt).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }) : null;
  return new Promise((resolve) => {
    const dlg = createSheet(`
      <div class="sheet__header"><h2>Backup importieren</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
      <p>Dieses Backup${dateLabel ? ` (erstellt am ${dateLabel})` : ''} enthält:</p>
      <ul class="field-hint" style="margin:0 0 var(--sp-4);padding-left:1.2em">
        ${summary.length ? summary.map(([label, n]) => `<li>${n} ${escapeHtml(label)}</li>`).join('') : '<li>keine erkennbaren Daten</li>'}
      </ul>
      <p class="field-hint" style="color:var(--color-danger)">Der Import ersetzt <strong>alle</strong> vorhandenen lokalen Daten mit dem Inhalt dieser Datei. Dieser Schritt kann nicht rückgängig gemacht werden, sobald du die Seite danach neu lädst.</p>
      <div class="field-row">
        <button class="btn btn-secondary btn-block" data-close>Abbrechen</button>
        <button class="btn btn-danger btn-block" id="confirm-import-btn">Importieren</button>
      </div>
    `);
    let decided = false;
    dlg.querySelector('#confirm-import-btn').addEventListener('click', () => { decided = true; dlg.close(); resolve(true); });
    dlg.addEventListener('close', () => { if (!decided) resolve(false); });
  });
}

/** Sichert den aktuellen Zustand vor dem Import im Arbeitsspeicher (kein zweiter Download) und
 * stellt ihn automatisch wieder her, falls der Import fehlschlägt (Auftrag Abschnitt 13). */
async function performImportWithRollback(data, container) {
  const previousData = await db.exportAll();
  try {
    await db.importAll(data);
  } catch (e) {
    try {
      await db.importAll(previousData);
      toast('Import fehlgeschlagen – vorheriger Zustand wurde wiederhergestellt.', 'danger');
    } catch (rollbackError) {
      toast('Import fehlgeschlagen und Wiederherstellung des vorherigen Zustands ebenfalls fehlgeschlagen. Bitte Seite neu laden.', 'danger');
    }
    return;
  }
  // V6.0: Ein Backup-Restore ist aktuell der einzige Weg, mit dem in dieser App alle
  // lokalen Daten auf einen Schlag ersetzt werden (es gibt keinen separaten "Alle Daten
  // löschen"-Button). Das Quiz-Fundament (1.000 Fragen) gehört zur App selbst, nicht zu
  // den Benutzerdaten im Backup, und darf durch einen Restore nicht dauerhaft verloren
  // gehen – auch dann nicht, wenn das eingespielte Backup älter ist und das Fundament
  // noch gar nicht kannte, oder wenn es überhaupt keine Quizfragen enthielt.
  await ensureFoundationSeeded();
  await loadStoredTheme(); // V6.1: Theme aus dem wiederhergestellten Backup übernehmen (fehlt es dort → Neon Core)
  toast('Backup erfolgreich wiederhergestellt. Ein Neuladen der Seite wird empfohlen.');
  window.dispatchEvent(new CustomEvent('rr:modules-changed'));
  render(container);
}

/* ---------- kleine UI-Helfer (Backup) ---------- */

function promptPin(title, hint) {
  return new Promise((resolve) => {
    const dlg = createSheet(`
      <div class="sheet__header"><h2>${escapeHtml(title)}</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
      <p class="field-hint">${escapeHtml(hint)}</p>
      <form id="pin-prompt-form">
        <div class="field"><label for="pin-prompt-input">PIN</label><input type="password" inputmode="numeric" id="pin-prompt-input" placeholder="••••" autofocus /></div>
        <button class="btn btn-primary btn-block" type="submit">${icon('check')} Bestätigen</button>
      </form>
    `);
    let decided = false;
    dlg.querySelector('#pin-prompt-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const pin = dlg.querySelector('#pin-prompt-input').value;
      decided = true;
      dlg.close();
      resolve(pin);
    });
    dlg.addEventListener('close', () => { if (!decided) resolve(null); });
  });
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function createSheet(innerHtml) {
  const dlg = document.createElement('dialog');
  dlg.className = 'sheet';
  dlg.innerHTML = `<div class="sheet__handle"></div><div class="sheet__body">${innerHtml}</div>`;
  document.body.appendChild(dlg);
  dlg.addEventListener('close', () => dlg.remove());
  dlg.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => dlg.close()));
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  dlg.showModal();
  return dlg;
}

function escAttr(str = '') {
  return String(str).replaceAll('"', '&quot;');
}
