import { db } from '../core/db.js';
import { icon } from '../core/icons.js';
import { uid, todayIso, isoDate, isoWeekday, WEEKDAY_SHORT_LABELS, escapeHtml, toast } from '../core/utils.js';
import { getActiveQuestions, logAnswer } from './quiz.js';
import { TRAINING_PROMPT_VERSION, TRAINING_PROMPT, PLAN_SCHEMA_VERSION, EXPORT_SCHEMA_VERSION } from './sportPrompt.js';

const S = db.STORES;

/* ==========================================================================
 * Konstanten / Register
 * ========================================================================== */

/** Widerstandsquellen: bewusst als Map mit fest zugeordneter Einheit (kein Freitext),
 * siehe CLAUDE.md. Körpergewicht bekommt explizit KEINE Gewichtseinheit (nicht 0 kg). */
export const RESISTANCE_TYPES = {
  weight: { label: 'Kurzhantel', unit: 'kg' },
  band: { label: 'Widerstandsband', unit: 'lbs' },
  bodyweight: { label: 'Körpergewicht', unit: '' },
};

export const MEASURE_TYPES = {
  reps: { label: 'Wiederholungen' },
  time: { label: 'Zeit (Sek.)' },
};

export const BUILTIN_METRIC_TYPES = [
  { key: 'weight', label: 'Gewicht', unit: 'kg' },
  { key: 'waist', label: 'Bauchumfang', unit: 'cm' },
  { key: 'chest', label: 'Brustumfang', unit: 'cm' },
  { key: 'arm', label: 'Armumfang', unit: 'cm' },
  { key: 'leg', label: 'Beinumfang', unit: 'cm' },
];

/* ==========================================================================
 * Normalisierung (Abwärtskompatibilität zu v1.0-Datenformaten)
 * ========================================================================== */

function mapLegacyEquipment(eq) {
  if (eq === 'dumbbell') return 'weight';
  if (eq === 'resistance_band') return 'band';
  return 'bodyweight';
}

/** Alte (v1.0) Übungen hatten equipment/weight/sets/reps statt resistanceType/measureType. */
export function normalizeExercise(ex) {
  if (ex.resistanceType) return ex;
  return {
    ...ex,
    resistanceType: mapLegacyEquipment(ex.equipment),
    measureType: 'reps',
    unit: RESISTANCE_TYPES[mapLegacyEquipment(ex.equipment)].unit,
    muscleGroups: ex.muscleGroups || [],
  };
}

/** Alte (v1.0) Pläne hatten day.exercises[] statt day.blocks[]. Wird nicht destruktiv
 * migriert, sondern beim Lesen "on the fly" in die neue Struktur übersetzt.
 * V4.0: `weekdays` (ISO-Wochentage 1-7, an denen dieser Tag im Kalender erscheinen soll)
 * ist optional und fehlt bei alten Tagen – Default leeres Array (kein automatischer
 * Kalendereintrag, bis der Nutzer bewusst Wochentage zuweist). `startDate` auf Plan-Ebene
 * fehlt bei alten Plänen – Default ist das Erstellungsdatum, damit ein nachträglich
 * zugewiesener Wochentag nicht rückwirkend Termine in der Vergangenheit erzeugt. */
export function normalizePlan(plan) {
  const days = (plan.days || []).map((day) => {
    if (Array.isArray(day.blocks)) return { ...day, weekdays: Array.isArray(day.weekdays) ? day.weekdays : [] };
    const blocks = (day.exercises || []).map((e) => {
      const resistanceType = mapLegacyEquipment(e.equipment);
      return {
        id: uid(),
        targetSets: e.sets || 1,
        restSeconds: 90,
        exercises: [{
          exerciseId: null,
          name: e.name,
          resistanceType,
          measureType: 'reps',
          targetReps: e.reps || null,
          targetTime: null,
          targetWeight: resistanceType === 'bodyweight' ? null : (e.weight ?? null),
          unit: RESISTANCE_TYPES[resistanceType].unit,
          note: e.note || '',
        }],
      };
    });
    return { id: day.id || uid(), title: day.title, blocks, weekdays: Array.isArray(day.weekdays) ? day.weekdays : [] };
  });
  return {
    ...plan,
    days,
    description: plan.description || '',
    active: plan.active !== false,
    startDate: plan.startDate || isoDate(new Date(plan.createdAt || Date.now())),
  };
}

/** Eine abgeschlossene Session hat entweder das neue Format (rounds[]) oder das
 * alte v1.0-Format (entries[]). Beide werden in der Historie angezeigt. */
function isLegacySession(s) { return Array.isArray(s.entries) && !Array.isArray(s.rounds); }

/* ==========================================================================
 * Datenzugriff: Übungen
 * ========================================================================== */

export async function getExercises() {
  const rows = await db.getAll(S.exercises);
  return rows.map(normalizeExercise).sort((a, b) => a.name.localeCompare(b.name, 'de'));
}
export async function saveExercise(ex) {
  const row = { ...ex, id: ex.id || uid(), createdAt: ex.createdAt || Date.now() };
  await db.put(S.exercises, row);
  return row;
}
export async function deleteExercise(id) { await db.remove(S.exercises, id); }
export async function duplicateExercise(ex) {
  const { id, ...rest } = ex;
  return saveExercise({ ...rest, name: `${rest.name} (Kopie)` });
}

/** Findet eine Übung anhand des Namens (case-insensitive) oder legt sie neu an.
 * Genutzt beim Trainingsplan-Import und beim freien Training. */
export async function ensureExerciseByName(name, resistanceType, measureType, unit) {
  const trimmed = (name || '').trim();
  if (!trimmed) return null;
  const existing = await getExercises();
  const found = existing.find((e) => e.name.toLowerCase() === trimmed.toLowerCase());
  if (found) return found;
  return saveExercise({ name: trimmed, resistanceType, measureType, unit, muscleGroups: [], note: '' });
}

/* ==========================================================================
 * Datenzugriff: Trainingspläne
 * ========================================================================== */

export async function getPlans() {
  const rows = await db.getAll(S.trainingPlans);
  return rows.map(normalizePlan).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}
export async function savePlan(plan) {
  const row = {
    ...plan,
    id: plan.id || uid(),
    createdAt: plan.createdAt || Date.now(),
    startDate: plan.startDate || todayIso(), // V4.0: Anker für die Kalender-Wochentagszuordnung, keine Termine vor diesem Datum
  };
  await db.put(S.trainingPlans, row);
  return row;
}
export async function deletePlan(id) { await db.remove(S.trainingPlans, id); }
export async function setPlanActive(id, active) {
  const plan = normalizePlan(await db.get(S.trainingPlans, id));
  if (plan) await savePlan({ ...plan, active });
}

/* ---- Plan-Import (KI-generiertes JSON) ---- */

export function validateImportPlan(rawText) {
  const errors = [];
  let data;
  try { data = JSON.parse(rawText); }
  catch { return { valid: false, errors: ['Der eingefügte Text ist kein gültiges JSON. Bitte den Plan unverändert aus der KI-Antwort kopieren.'], plan: null }; }

  if (data.schemaVersion !== PLAN_SCHEMA_VERSION) {
    errors.push(`Unbekannte Schema-Version. Erwartet wird "schemaVersion": "${PLAN_SCHEMA_VERSION}".`);
  }
  if (!data.name || typeof data.name !== 'string') errors.push('Feld "name" (Titel des Plans) fehlt.');
  if (data.startDate != null && !/^\d{4}-\d{2}-\d{2}$/.test(data.startDate)) {
    errors.push('Feld "startDate" muss, falls angegeben, im Format JJJJ-MM-TT sein.');
  }
  if (!Array.isArray(data.days) || data.days.length === 0) {
    errors.push('Feld "days" fehlt oder ist leer – ein Plan braucht mindestens einen Trainingstag.');
  } else {
    data.days.forEach((day, di) => {
      const dl = `Tag ${di + 1}`;
      if (!day.title) errors.push(`${dl}: "title" fehlt.`);
      if (day.weekdays != null) {
        const validArray = Array.isArray(day.weekdays)
          && day.weekdays.every((w) => Number.isInteger(w) && w >= 1 && w <= 7);
        if (!validArray) errors.push(`${dl}: "weekdays" muss, falls angegeben, ein Array aus Zahlen 1-7 (Mo-So) sein.`);
      }
      if (!Array.isArray(day.blocks) || day.blocks.length === 0) {
        errors.push(`${dl}: "blocks" fehlt oder ist leer.`);
        return;
      }
      day.blocks.forEach((block, bi) => {
        const bl = `${dl}, Block ${bi + 1}`;
        if (block.targetSets != null && (!Number.isFinite(block.targetSets) || block.targetSets <= 0)) {
          errors.push(`${bl}: "targetSets" muss eine positive Zahl sein.`);
        }
        if (block.restSeconds != null && (!Number.isFinite(block.restSeconds) || block.restSeconds < 0)) {
          errors.push(`${bl}: "restSeconds" muss eine Zahl ≥ 0 sein.`);
        }
        if (!Array.isArray(block.exercises) || block.exercises.length === 0) {
          errors.push(`${bl}: "exercises" fehlt oder ist leer.`);
          return;
        }
        block.exercises.forEach((ex, ei) => {
          const el = `${bl}, Übung ${ei + 1}`;
          if (!ex.name) errors.push(`${el}: "name" fehlt.`);
          if (!RESISTANCE_TYPES[ex.resistanceType]) errors.push(`${el}: unbekannter "resistanceType" ("${ex.resistanceType}").`);
          if (!MEASURE_TYPES[ex.measureType]) errors.push(`${el}: unbekannter "measureType" ("${ex.measureType}").`);
          if (ex.measureType === 'reps' && (!Number.isFinite(ex.targetReps) || ex.targetReps <= 0)) {
            errors.push(`${el}: "targetReps" muss bei measureType "reps" eine positive Zahl sein.`);
          }
          if (ex.measureType === 'time' && (!Number.isFinite(ex.targetTime) || ex.targetTime <= 0)) {
            errors.push(`${el}: "targetTime" muss bei measureType "time" eine positive Zahl sein.`);
          }
          if ((ex.resistanceType === 'weight' || ex.resistanceType === 'band') && (!Number.isFinite(ex.targetWeight) || ex.targetWeight <= 0)) {
            errors.push(`${el}: "targetWeight" muss bei resistanceType "${ex.resistanceType}" eine positive Zahl sein.`);
          }
        });
      });
    });
  }
  return { valid: errors.length === 0, errors, plan: errors.length === 0 ? data : null };
}

export async function importValidatedPlan(planData) {
  const days = [];
  for (const day of planData.days) {
    const blocks = [];
    for (const block of day.blocks) {
      const exercises = [];
      for (const ex of block.exercises) {
        const unit = ex.unit || RESISTANCE_TYPES[ex.resistanceType].unit;
        const libEx = await ensureExerciseByName(ex.name, ex.resistanceType, ex.measureType, unit);
        exercises.push({
          exerciseId: libEx?.id || null,
          name: ex.name,
          resistanceType: ex.resistanceType,
          measureType: ex.measureType,
          targetReps: ex.measureType === 'reps' ? ex.targetReps : null,
          targetTime: ex.measureType === 'time' ? ex.targetTime : null,
          targetWeight: ex.resistanceType === 'bodyweight' ? null : (ex.targetWeight ?? null),
          unit,
          note: ex.note || '',
        });
      }
      blocks.push({ id: uid(), targetSets: block.targetSets || 1, restSeconds: block.restSeconds ?? 90, exercises });
    }
    days.push({ id: uid(), title: day.title, blocks, weekdays: Array.isArray(day.weekdays) ? day.weekdays : [] });
  }
  return savePlan({
    name: planData.name, description: planData.description || '', days, active: true,
    source: 'import', importedAt: Date.now(), startDate: planData.startDate || todayIso(),
  });
}

/* ==========================================================================
 * Kalender-Integration (V4.0)
 *
 * Der Trainingsplan bleibt die alleinige Quelle der Wahrheit für geplante
 * Trainingstage. Statt bei jeder Wochentags-/Startdatum-Zuweisung Kopien in
 * einen anderen Store zu schreiben, wird die Zuordnung Plan-Tag → Kalendertag
 * bei jedem Aufruf frisch berechnet ("logische/dynamische Verbindung", siehe
 * Auftrag). Ändert sich ein Plan oder wird er deaktiviert/gelöscht, verschwinden
 * die entsprechenden Kalendereinträge dadurch automatisch – es gibt nichts
 * Veraltetes, das aufgeräumt werden müsste.
 * ========================================================================== */

/** Liefert die aus aktiven Trainingsplänen resultierenden (virtuellen) Trainingstermine
 * für ein gegebenes Datum. Jeder Eintrag trägt planId/dayId als Herkunftsreferenz
 * (sourceType: 'trainingPlan') sowie `done`, falls für diesen Tag bereits eine
 * passende, nicht abgebrochene Session existiert. Wird von calendar.js genutzt;
 * Sport funktioniert unverändert auch ohne dass der Kalender diese Funktion aufruft. */
export async function getPlannedTrainingsForDate(dateObj) {
  const iso = isoDate(dateObj);
  const weekday = isoWeekday(dateObj);
  const [plans, sessions] = await Promise.all([getPlans(), getSessions()]);
  const out = [];
  for (const plan of plans) {
    if (plan.active === false) continue;
    if (!plan.startDate || iso < plan.startDate) continue;
    for (const day of plan.days) {
      if (!(day.weekdays || []).includes(weekday)) continue;
      const done = sessions.some((s) => !s.aborted && s.date === iso
        && s.planId === plan.id && (s.dayId ? s.dayId === day.id : true));
      out.push({
        sourceType: 'trainingPlan', planId: plan.id, dayId: day.id,
        planName: plan.name, title: day.title, done,
      });
    }
  }
  return out;
}

/* ==========================================================================
 * Datenzugriff: Trainingshistorie (abgeschlossene Sessions)
 * ========================================================================== */

export async function getSessions() {
  const rows = await db.getAll(S.workoutSessions);
  return rows.sort((a, b) => (b.startTime || 0) - (a.startTime || 0));
}
export async function saveCompletedSession(session) {
  const row = { ...session, id: session.id || uid() };
  await db.put(S.workoutSessions, row);
  return row;
}
export async function deleteSession(id) { await db.remove(S.workoutSessions, id); }

/* ---- Aktives Training (reload-sicher) ---- */

export async function getActiveWorkout() { return db.get(S.activeWorkout, 'current'); }
export async function saveActiveWorkout(state) { await db.put(S.activeWorkout, { ...state, id: 'current' }); return state; }
export async function clearActiveWorkout() { await db.remove(S.activeWorkout, 'current'); }

/* ==========================================================================
 * Fortschritt / Persönliche Bestleistungen / Statistik
 * ========================================================================== */

/** Alle geloggten Übungs-Einzelleistungen aus abgeschlossenen (neuen) Sessions, flach. */
async function getAllLoggedEntries() {
  const sessions = await getSessions();
  const out = [];
  sessions.forEach((s) => {
    if (isLegacySession(s)) return;
    (s.rounds || []).forEach((round) => {
      (round.entries || []).forEach((entry) => {
        if (entry.skipped) return;
        out.push({ ...entry, date: s.date, sessionId: s.id, timestamp: s.startTime || 0 });
      });
    });
  });
  return out.sort((a, b) => a.timestamp - b.timestamp);
}

function keyForEntry(e) { return e.exerciseId || e.name; }

/** Persönliche Bestleistung für eine Liste von Einträgen EINER Übung, passend zur Messart. */
function bestFor(entries) {
  if (!entries.length) return null;
  const { resistanceType, measureType } = entries[entries.length - 1];
  if (measureType === 'time') {
    const best = entries.reduce((m, e) => Math.max(m, e.actualTime || 0), 0);
    return { type: 'time', value: best };
  }
  if (resistanceType === 'bodyweight') {
    const best = entries.reduce((m, e) => Math.max(m, e.actualReps || 0), 0);
    return { type: 'reps', value: best };
  }
  const bestWeight = entries.reduce((m, e) => Math.max(m, e.actualWeight || 0), 0);
  const bestVolume = entries.reduce((m, e) => Math.max(m, (e.actualWeight || 0) * (e.actualReps || 0)), 0);
  return { type: 'weight', value: bestWeight, unit: entries[0].unit, volume: bestVolume };
}

/** Fortschritts-/PR-Übersicht pro Übung + Gesamtstatistik. Rein aus tatsächlichen Trainingsdaten berechnet. */
export async function getOverallSportStats() {
  const [entries, sessions] = await Promise.all([getAllLoggedEntries(), getSessions()]);
  const completed = sessions.filter((s) => !s.aborted);
  const now = new Date();
  const weekAgo = Date.now() - 7 * 86400000;
  const monthKey = todayIso().slice(0, 7);

  const totalVolume = entries.reduce((sum, e) => sum + (e.resistanceType !== 'bodyweight' && e.measureType === 'reps' ? (e.actualWeight || 0) * (e.actualReps || 0) : 0), 0);
  const totalDurationSeconds = completed.reduce((sum, s) => sum + (s.durationSeconds || 0), 0);

  const byExercise = {};
  entries.forEach((e) => {
    const key = keyForEntry(e);
    (byExercise[key] ??= { name: e.name, resistanceType: e.resistanceType, measureType: e.measureType, unit: e.unit, entries: [] }).entries.push(e);
  });
  const exerciseProgress = Object.values(byExercise).map((g) => ({
    name: g.name,
    resistanceType: g.resistanceType,
    measureType: g.measureType,
    unit: g.unit,
    pr: bestFor(g.entries),
    history: g.entries.map((e) => ({ date: e.date, value: e.measureType === 'time' ? e.actualTime : (g.resistanceType === 'bodyweight' ? e.actualReps : e.actualWeight) })),
  })).sort((a, b) => a.name.localeCompare(b.name, 'de'));

  return {
    totalSessions: completed.length,
    sessionsThisWeek: completed.filter((s) => (s.startTime || 0) >= weekAgo).length,
    sessionsThisMonth: completed.filter((s) => (s.date || '').startsWith(monthKey)).length,
    totalDurationSeconds,
    totalVolume,
    exerciseProgress,
  };
}

/** Ermittelt, welche Einträge einer eben abgeschlossenen Session neue persönliche
 * Bestleistungen sind (Vergleich gegen alle VORHERIGEN Sessions). */
async function detectNewPRs(newRounds) {
  const priorEntries = await getAllLoggedEntries(); // Session ist zu diesem Zeitpunkt noch nicht gespeichert
  const priorByKey = {};
  priorEntries.forEach((e) => { (priorByKey[keyForEntry(e)] ??= []).push(e); });

  const newPRs = [];
  newRounds.forEach((round) => {
    (round.entries || []).forEach((e) => {
      if (e.skipped) return;
      const key = keyForEntry(e);
      const priorBest = bestFor(priorByKey[key] || []);
      if (e.measureType === 'time') {
        if (!priorBest || (e.actualTime || 0) > priorBest.value) newPRs.push({ name: e.name, text: `${e.actualTime}s (neue Bestzeit)` });
      } else if (e.resistanceType === 'bodyweight') {
        if (!priorBest || (e.actualReps || 0) > priorBest.value) newPRs.push({ name: e.name, text: `${e.actualReps} Wdh. (neue Bestleistung)` });
      } else {
        if (!priorBest || (e.actualWeight || 0) > priorBest.value) newPRs.push({ name: e.name, text: `${e.actualWeight}${e.unit} (neues Bestgewicht)` });
      }
    });
  });
  return newPRs;
}

/* ==========================================================================
 * Export
 * ========================================================================== */

export async function exportSportData() {
  const [exercises, trainingPlans, workoutSessions] = await Promise.all([getExercises(), getPlans(), getSessions()]);
  const data = { schemaVersion: EXPORT_SCHEMA_VERSION, exportedAt: new Date().toISOString(), exercises, trainingPlans, workoutSessions };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `roger-roger-trainingsdaten-${todayIso()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ==========================================================================
 * Datenzugriff: Körpermessungen (unverändert gegenüber v1.0)
 * ========================================================================== */

export async function getBodyMetrics() {
  const rows = await db.getAll(S.bodyMetrics);
  return rows.sort((a, b) => a.date.localeCompare(b.date));
}
export async function saveBodyMetric(m) { const row = { ...m, id: m.id || uid() }; await db.put(S.bodyMetrics, row); return row; }
export async function deleteBodyMetric(id) { await db.remove(S.bodyMetrics, id); }

/* ==========================================================================
 * UI
 * ========================================================================== */

const TABS = [
  { id: 'plans', label: 'Pläne' },
  { id: 'exercises', label: 'Übungen' },
  { id: 'training', label: 'Training' },
  { id: 'history', label: 'Historie' },
  { id: 'progress', label: 'Fortschritt' },
  { id: 'body', label: 'Körperdaten' },
];

export async function render(container, params = {}) {
  const activeTab = TABS.some((t) => t.id === params.tab) ? params.tab : 'plans';
  container.innerHTML = `
    <h1>Sport</h1>
    <div class="tabs" role="tablist">
      ${TABS.map((t) => `<button class="tabs__btn ${t.id === activeTab ? 'is-active' : ''}" data-tab="${t.id}">${t.label}</button>`).join('')}
    </div>
    <div id="sport-tab-content"></div>
  `;
  container.querySelectorAll('[data-tab]').forEach((btn) => {
    btn.addEventListener('click', () => render(container, { tab: btn.dataset.tab }));
  });
  const content = container.querySelector('#sport-tab-content');
  document.querySelectorAll('.fab').forEach((f) => f.remove());
  if (activeTab === 'plans') await renderPlansTab(content);
  else if (activeTab === 'exercises') await renderExercisesTab(content);
  else if (activeTab === 'training') await renderTrainingTab(content);
  else if (activeTab === 'history') await renderHistoryTab(content);
  else if (activeTab === 'progress') await renderProgressTab(content);
  else await renderBodyTab(content);
  if (activeTab !== 'training') installFab(activeTab, container);
}

function installFab(activeTab, container) {
  const fab = document.createElement('button');
  fab.className = 'fab';
  fab.setAttribute('aria-label', 'Hinzufügen');
  fab.innerHTML = icon('plus');
  fab.addEventListener('click', () => {
    const content = container.querySelector('#sport-tab-content');
    if (activeTab === 'plans') openPlanEditorSheet(content);
    else if (activeTab === 'exercises') openExerciseForm(content);
    else if (activeTab === 'body') openBodyMetricSheet(content);
  });
  document.body.appendChild(fab);
}

/* ---------------- Tab: Pläne ---------------- */

async function renderPlansTab(root) {
  const plans = await getPlans();
  root.innerHTML = `
    <div class="card list" style="margin-bottom:var(--sp-4)">
      <button class="btn btn-secondary btn-block" id="import-plan-btn">${icon('upload')} Trainingsplan importieren</button>
      <button class="btn btn-ghost btn-block" id="prompt-btn">${icon('copy')} Prompt für neuen Plan</button>
      <button class="btn btn-ghost btn-block" id="new-plan-btn">${icon('plus')} Plan manuell erstellen</button>
    </div>
    ${plans.length ? plans.map(planCard).join('') : emptyState('Noch kein Trainingsplan vorhanden. Lass dir von einer KI einen Plan erzeugen und importiere ihn, oder erstelle einen manuell.')}
  `;
  root.querySelector('#import-plan-btn').addEventListener('click', () => openImportSheet(root));
  root.querySelector('#prompt-btn').addEventListener('click', () => openPromptSheet());
  root.querySelector('#new-plan-btn').addEventListener('click', () => openPlanEditorSheet(root));
  root.querySelectorAll('[data-edit-plan]').forEach((b) => b.addEventListener('click', async () => {
    const plan = plans.find((p) => p.id === b.dataset.editPlan);
    openPlanEditorSheet(root, plan);
  }));
  root.querySelectorAll('[data-toggle-plan]').forEach((b) => b.addEventListener('click', async () => {
    const plan = plans.find((p) => p.id === b.dataset.togglePlan);
    await setPlanActive(plan.id, !plan.active);
    renderPlansTab(root);
  }));
  root.querySelectorAll('[data-delete-plan]').forEach((b) => b.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!confirm('Trainingsplan wirklich löschen? Bereits absolvierte Trainings in der Historie bleiben erhalten.')) return;
    await deletePlan(b.dataset.deletePlan);
    renderPlansTab(root);
  }));
  root.querySelectorAll('[data-start-plan]').forEach((b) => b.addEventListener('click', async () => {
    const plan = plans.find((p) => p.id === b.dataset.startPlan);
    await startPlanWorkout(plan);
    navigateToTraining();
  }));
}

function planCard(plan) {
  const blockCount = plan.days.reduce((sum, d) => sum + d.blocks.length, 0);
  return `
    <div class="plan-card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <div class="plan-card__title">${escapeHtml(plan.name)}${plan.active === false ? ' <span class="field-hint">(inaktiv)</span>' : ''}</div>
          <div class="plan-card__days">${plan.days.length} Trainingstag(e) · ${blockCount} Satz-Block(s)</div>
          ${plan.description ? `<div class="item-row__desc" style="margin-bottom:var(--sp-2)">${escapeHtml(plan.description)}</div>` : ''}
        </div>
        <div class="item-row__actions">
          <button class="btn-icon" data-edit-plan="${plan.id}" aria-label="Bearbeiten">${icon('edit')}</button>
          <button class="btn-icon" data-delete-plan="${plan.id}" aria-label="Löschen">${icon('trash')}</button>
        </div>
      </div>
      ${plan.days.map((d) => `
        <div class="plan-day">
          <div class="plan-day__title">${escapeHtml(d.title)}${d.weekdays?.length ? ` <span class="field-hint">· ${d.weekdays.slice().sort().map((w) => WEEKDAY_SHORT_LABELS[w - 1]).join(', ')}</span>` : ''}</div>
          ${d.blocks.map((b) => `
            <div class="plan-exercise-line">
              <span>${b.exercises.map((e) => escapeHtml(e.name)).join(' + ')}</span>
              <span style="font-family:var(--font-mono)">${b.targetSets}× ${b.exercises.map((e) => targetLabel(e)).join(' / ')}</span>
            </div>`).join('')}
        </div>`).join('')}
      <div style="display:flex;gap:var(--sp-2);margin-top:var(--sp-3)">
        <button class="btn btn-primary btn-block" data-start-plan="${plan.id}">${icon('play')} Training starten</button>
        <button class="btn btn-ghost" data-toggle-plan="${plan.id}">${plan.active === false ? 'Aktivieren' : 'Deaktivieren'}</button>
      </div>
    </div>`;
}

function targetLabel(e) {
  if (e.measureType === 'time') return `${e.targetTime}s`;
  const w = e.resistanceType === 'bodyweight' ? '' : ` · ${e.targetWeight}${e.unit}`;
  return `${e.targetReps}${w}`;
}

function openPromptSheet() {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Prompt für neuen Plan</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <p class="field-hint">Prompt-Version: ${TRAINING_PROMPT_VERSION} — vollständig kopieren und einer KI geben, dort die eckigen Klammern ausfüllen.</p>
    <div class="quiz-explanation" style="font-family:var(--font-mono);white-space:pre-wrap;word-break:break-word;max-height:50vh;overflow:auto">${escapeHtml(TRAINING_PROMPT)}</div>
    <button class="btn btn-primary btn-block" id="copy-prompt-btn" style="margin-top:var(--sp-3)">${icon('copy')} Prompt kopieren</button>
  `);
  dlg.querySelector('#copy-prompt-btn').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(TRAINING_PROMPT);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = TRAINING_PROMPT;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    toast('Prompt kopiert');
  });
}

function openImportSheet(root) {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Trainingsplan importieren</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <p class="field-hint">Füge den von einer KI erzeugten Plan im Roger-Roger-Format ein, oder wähle eine Datei.</p>
    <textarea class="import-box" id="import-textarea" placeholder="JSON hier einfügen …"></textarea>
    <input type="file" id="import-file" accept="application/json" style="margin-top:var(--sp-2)" />
    <div id="import-preview"></div>
    <button class="btn btn-primary btn-block" id="preview-btn" style="margin-top:var(--sp-3)">Vorschau prüfen</button>
  `);
  dlg.querySelector('#import-file').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file) dlg.querySelector('#import-textarea').value = await file.text();
  });
  dlg.querySelector('#preview-btn').addEventListener('click', () => {
    const text = dlg.querySelector('#import-textarea').value.trim();
    const { valid, errors, plan } = validateImportPlan(text);
    const previewEl = dlg.querySelector('#import-preview');
    if (!valid) {
      previewEl.innerHTML = `<div class="field-error">${errors.map(escapeHtml).join('<br/>')}</div>`;
      return;
    }
    const blockCount = plan.days.reduce((sum, d) => sum + d.blocks.length, 0);
    previewEl.innerHTML = `
      <div class="quiz-explanation">
        <strong>${escapeHtml(plan.name)}</strong> – ${plan.days.length} Trainingstag(e), ${blockCount} Satz-Block(s) erkannt. Sieht das korrekt aus?
      </div>
      <button class="btn btn-primary btn-block" id="confirm-import-btn">${icon('check')} Importieren</button>
    `;
    previewEl.querySelector('#confirm-import-btn').addEventListener('click', async () => {
      await importValidatedPlan(plan);
      toast('Trainingsplan importiert');
      dlg.close();
      renderPlansTab(root);
    });
  });
}

/* ---- Plan manuell erstellen/bearbeiten ---- */

function openPlanEditorSheet(root, existing = null) {
  const state = existing
    ? JSON.parse(JSON.stringify(existing))
    : { name: '', description: '', startDate: todayIso(), days: [{ id: uid(), title: 'Tag 1', blocks: [], weekdays: [] }] };
  const dlg = createSheet(`
    <div class="sheet__header"><h2>${existing ? 'Plan bearbeiten' : 'Neuer Plan'}</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <div class="field"><label for="p-name">Name</label><input id="p-name" value="${escapeHtml(state.name)}" /></div>
    <div class="field"><label for="p-desc">Beschreibung (optional)</label><textarea id="p-desc">${escapeHtml(state.description)}</textarea></div>
    <div class="field">
      <label for="p-start">Startdatum</label>
      <input id="p-start" type="date" value="${state.startDate || todayIso()}" />
      <p class="field-hint">Ab diesem Datum erscheinen die unten zugewiesenen Wochentage im Kalender. Kein Trainingstermin vor diesem Datum.</p>
    </div>
    <div id="days-host"></div>
    <button class="btn btn-secondary btn-block" id="add-day-btn" style="margin:var(--sp-2) 0 var(--sp-4)">${icon('plus')} Trainingstag hinzufügen</button>
    <div class="field-error" id="p-error" hidden></div>
    <button class="btn btn-primary btn-block" id="save-plan-btn">${icon('check')} Plan speichern</button>
  `);
  const daysHost = dlg.querySelector('#days-host');

  function renderDays() {
    daysHost.innerHTML = state.days.map((day, di) => `
      <div class="card" style="margin-bottom:var(--sp-3)" data-day="${di}">
        <div class="field-row" style="align-items:center">
          <input class="field" data-day-title="${di}" value="${escapeHtml(day.title)}" placeholder="Titel des Tages" style="flex:1;padding:8px" />
          <button type="button" class="btn-icon" data-del-day="${di}" aria-label="Tag löschen">${icon('trash')}</button>
        </div>
        <p class="field-hint" style="margin-top:var(--sp-2)">An welchen Wochentagen? (optional – für die automatische Anzeige im Kalender)</p>
        <div class="weekday-picker">
          ${WEEKDAY_SHORT_LABELS.map((label, wi) => `
            <button type="button" class="weekday-chip ${(day.weekdays || []).includes(wi + 1) ? 'is-active' : ''}" data-day-weekday="${di}:${wi + 1}">${label}</button>
          `).join('')}
        </div>
        <div data-blocks-host="${di}"></div>
        <button type="button" class="btn btn-ghost btn-block" data-add-block="${di}" style="margin-top:var(--sp-2)">${icon('plus')} Satz-Block hinzufügen</button>
      </div>`).join('');

    state.days.forEach((day, di) => {
      const blocksHost = daysHost.querySelector(`[data-blocks-host="${di}"]`);
      blocksHost.innerHTML = day.blocks.map((block, bi) => `
        <div class="card" style="margin:var(--sp-2) 0;background:var(--color-surface-raised)" data-block="${bi}">
          <div class="field-row">
            <div class="field"><label>Sätze</label><input type="number" min="1" value="${block.targetSets}" data-block-sets="${di}:${bi}" /></div>
            <div class="field"><label>Pause (Sek.)</label><input type="number" min="0" value="${block.restSeconds}" data-block-rest="${di}:${bi}" /></div>
            <button type="button" class="btn-icon" data-del-block="${di}:${bi}" aria-label="Block löschen">${icon('trash')}</button>
          </div>
          <div data-exercises-host="${di}:${bi}"></div>
          <button type="button" class="btn btn-ghost btn-block" data-add-exercise="${di}:${bi}">${icon('plus')} Übung im Block</button>
        </div>`).join('');

      day.blocks.forEach((block, bi) => {
        const exHost = blocksHost.querySelector(`[data-exercises-host="${di}:${bi}"]`);
        exHost.innerHTML = block.exercises.map((ex, ei) => `
          <div class="field-row" style="align-items:flex-end;flex-wrap:wrap" data-exercise="${ei}">
            <div class="field" style="flex:2;min-width:120px"><label>Übung</label><input data-ex-name="${di}:${bi}:${ei}" value="${escapeHtml(ex.name)}" /></div>
            <div class="field"><label>Gerät</label><select data-ex-resistance="${di}:${bi}:${ei}">${resistanceOptions(ex.resistanceType)}</select></div>
            <div class="field"><label>Messart</label><select data-ex-measure="${di}:${bi}:${ei}"><option value="reps" ${ex.measureType === 'reps' ? 'selected' : ''}>Wdh.</option><option value="time" ${ex.measureType === 'time' ? 'selected' : ''}>Zeit (Sek.)</option></select></div>
            <div class="field" style="max-width:90px"><label>${ex.measureType === 'time' ? 'Sek.' : 'Wdh.'}</label><input type="number" min="0" value="${ex.measureType === 'time' ? (ex.targetTime ?? '') : (ex.targetReps ?? '')}" data-ex-target="${di}:${bi}:${ei}" /></div>
            ${ex.resistanceType === 'bodyweight' ? '' : `<div class="field" style="max-width:90px"><label>${RESISTANCE_TYPES[ex.resistanceType].unit}</label><input type="number" step="0.5" min="0" value="${ex.targetWeight ?? ''}" data-ex-weight="${di}:${bi}:${ei}" /></div>`}
            <button type="button" class="btn-icon" data-del-exercise="${di}:${bi}:${ei}" aria-label="Übung löschen">${icon('x')}</button>
          </div>`).join('');
      });
    });

    daysHost.querySelectorAll('[data-day-title]').forEach((el) => el.addEventListener('input', (e) => { state.days[+el.dataset.dayTitle].title = e.target.value; }));
    daysHost.querySelectorAll('[data-del-day]').forEach((el) => el.addEventListener('click', () => { state.days.splice(+el.dataset.delDay, 1); renderDays(); }));
    daysHost.querySelectorAll('[data-day-weekday]').forEach((el) => el.addEventListener('click', () => {
      const [di, wd] = el.dataset.dayWeekday.split(':').map(Number);
      const day = state.days[di];
      day.weekdays = day.weekdays || [];
      const idx = day.weekdays.indexOf(wd);
      if (idx === -1) day.weekdays.push(wd); else day.weekdays.splice(idx, 1);
      renderDays();
    }));
    daysHost.querySelectorAll('[data-add-block]').forEach((el) => el.addEventListener('click', () => {
      state.days[+el.dataset.addBlock].blocks.push({ id: uid(), targetSets: 3, restSeconds: 90, exercises: [] });
      renderDays();
    }));
    daysHost.querySelectorAll('[data-del-block]').forEach((el) => el.addEventListener('click', () => {
      const [di, bi] = el.dataset.delBlock.split(':').map(Number);
      state.days[di].blocks.splice(bi, 1);
      renderDays();
    }));
    daysHost.querySelectorAll('[data-add-exercise]').forEach((el) => el.addEventListener('click', () => {
      const [di, bi] = el.dataset.addExercise.split(':').map(Number);
      state.days[di].blocks[bi].exercises.push({ exerciseId: null, name: '', resistanceType: 'bodyweight', measureType: 'reps', targetReps: 10, targetTime: null, targetWeight: null, unit: '', note: '' });
      renderDays();
    }));
    daysHost.querySelectorAll('[data-del-exercise]').forEach((el) => el.addEventListener('click', () => {
      const [di, bi, ei] = el.dataset.delExercise.split(':').map(Number);
      state.days[di].blocks[bi].exercises.splice(ei, 1);
      renderDays();
    }));
    daysHost.querySelectorAll('[data-ex-name]').forEach((el) => el.addEventListener('input', (e) => {
      const [di, bi, ei] = el.dataset.exName.split(':').map(Number);
      state.days[di].blocks[bi].exercises[ei].name = e.target.value;
    }));
    daysHost.querySelectorAll('[data-ex-resistance]').forEach((el) => el.addEventListener('change', (e) => {
      const [di, bi, ei] = el.dataset.exResistance.split(':').map(Number);
      const ex = state.days[di].blocks[bi].exercises[ei];
      ex.resistanceType = e.target.value;
      ex.unit = RESISTANCE_TYPES[ex.resistanceType].unit;
      if (ex.resistanceType === 'bodyweight') ex.targetWeight = null;
      renderDays();
    }));
    daysHost.querySelectorAll('[data-ex-measure]').forEach((el) => el.addEventListener('change', (e) => {
      const [di, bi, ei] = el.dataset.exMeasure.split(':').map(Number);
      state.days[di].blocks[bi].exercises[ei].measureType = e.target.value;
      renderDays();
    }));
    daysHost.querySelectorAll('[data-ex-target]').forEach((el) => el.addEventListener('input', (e) => {
      const [di, bi, ei] = el.dataset.exTarget.split(':').map(Number);
      const ex = state.days[di].blocks[bi].exercises[ei];
      if (ex.measureType === 'time') ex.targetTime = numOrNull(e.target.value); else ex.targetReps = numOrNull(e.target.value);
    }));
    daysHost.querySelectorAll('[data-ex-weight]').forEach((el) => el.addEventListener('input', (e) => {
      const [di, bi, ei] = el.dataset.exWeight.split(':').map(Number);
      state.days[di].blocks[bi].exercises[ei].targetWeight = numOrNull(e.target.value);
    }));
    daysHost.querySelectorAll('[data-block-sets]').forEach((el) => el.addEventListener('input', (e) => {
      const [di, bi] = el.dataset.blockSets.split(':').map(Number);
      state.days[di].blocks[bi].targetSets = Number(e.target.value) || 1;
    }));
    daysHost.querySelectorAll('[data-block-rest]').forEach((el) => el.addEventListener('input', (e) => {
      const [di, bi] = el.dataset.blockRest.split(':').map(Number);
      state.days[di].blocks[bi].restSeconds = Number(e.target.value) || 0;
    }));
  }
  renderDays();

  dlg.querySelector('#add-day-btn').addEventListener('click', () => {
    state.days.push({ id: uid(), title: `Tag ${state.days.length + 1}`, blocks: [], weekdays: [] });
    renderDays();
  });

  dlg.querySelector('#save-plan-btn').addEventListener('click', async () => {
    state.name = dlg.querySelector('#p-name').value.trim();
    state.description = dlg.querySelector('#p-desc').value.trim();
    state.startDate = dlg.querySelector('#p-start').value || todayIso();
    const errEl = dlg.querySelector('#p-error');
    if (!state.name) { errEl.textContent = 'Bitte einen Namen für den Plan eintragen.'; errEl.hidden = false; return; }
    if (!state.days.some((d) => d.blocks.some((b) => b.exercises.some((e) => e.name.trim())))) {
      errEl.textContent = 'Bitte mindestens eine Übung in einem Block eintragen.';
      errEl.hidden = false;
      return;
    }
    for (const day of state.days) {
      for (const block of day.blocks) {
        for (const ex of block.exercises) {
          if (!ex.name.trim()) continue;
          const lib = await ensureExerciseByName(ex.name, ex.resistanceType, ex.measureType, ex.unit);
          ex.exerciseId = lib?.id || null;
        }
      }
      day.blocks = day.blocks.map((b) => ({ ...b, exercises: b.exercises.filter((e) => e.name.trim()) })).filter((b) => b.exercises.length);
    }
    await savePlan({ ...state, id: existing?.id, active: existing ? existing.active : true, source: existing?.source || 'manual' });
    toast('Plan gespeichert');
    dlg.close();
    renderPlansTab(root);
  });
}

function resistanceOptions(selected) {
  return Object.entries(RESISTANCE_TYPES).map(([key, v]) => `<option value="${key}" ${key === selected ? 'selected' : ''}>${v.label}</option>`).join('');
}

/* ---------------- Tab: Übungen ---------------- */

async function renderExercisesTab(root) {
  const exercises = await getExercises();
  root.innerHTML = `
    <div class="section-title"><h2>Übungsbibliothek</h2></div>
    ${exercises.length ? `<div class="list">${exercises.map(exerciseRow).join('')}</div>` : emptyState('Noch keine Übungen angelegt. Übungen entstehen auch automatisch beim Anlegen von Plänen oder freiem Training.')}
  `;
  root.querySelectorAll('[data-edit-ex]').forEach((b) => b.addEventListener('click', () => {
    openExerciseForm(root, exercises.find((x) => x.id === b.dataset.editEx));
  }));
  root.querySelectorAll('[data-dup-ex]').forEach((b) => b.addEventListener('click', async () => {
    await duplicateExercise(exercises.find((x) => x.id === b.dataset.dupEx));
    toast('Übung dupliziert');
    renderExercisesTab(root);
  }));
  root.querySelectorAll('[data-del-ex]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('Übung wirklich löschen? Bestehende Pläne/Historie behalten den Namen, verlieren aber die Verknüpfung.')) return;
    await deleteExercise(b.dataset.delEx);
    renderExercisesTab(root);
  }));
}

function exerciseRow(ex) {
  const r = RESISTANCE_TYPES[ex.resistanceType];
  return `
    <div class="item-row">
      <div class="item-row__main">
        <div class="item-row__title">${escapeHtml(ex.name)}</div>
        <div class="item-row__meta">${r.label} · ${MEASURE_TYPES[ex.measureType].label}${ex.muscleGroups?.length ? ` · ${ex.muscleGroups.join(', ')}` : ''}</div>
        ${ex.note ? `<div class="item-row__desc">${escapeHtml(ex.note)}</div>` : ''}
      </div>
      <div class="item-row__actions">
        <button class="btn-icon" data-edit-ex="${ex.id}" aria-label="Bearbeiten">${icon('edit')}</button>
        <button class="btn-icon" data-dup-ex="${ex.id}" aria-label="Duplizieren">${icon('plus')}</button>
        <button class="btn-icon" data-del-ex="${ex.id}" aria-label="Löschen">${icon('trash')}</button>
      </div>
    </div>`;
}

function openExerciseForm(root, existing = null) {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>${existing ? 'Übung bearbeiten' : 'Neue Übung'}</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <form id="ex-form">
      <div class="field"><label for="e-name">Name</label><input id="e-name" required value="${existing ? escapeHtml(existing.name) : ''}" /></div>
      <div class="field-row">
        <div class="field"><label for="e-resistance">Gerät</label><select id="e-resistance">${resistanceOptions(existing?.resistanceType || 'bodyweight')}</select></div>
        <div class="field"><label for="e-measure">Messart</label><select id="e-measure"><option value="reps" ${(!existing || existing.measureType === 'reps') ? 'selected' : ''}>Wiederholungen</option><option value="time" ${existing?.measureType === 'time' ? 'selected' : ''}>Zeit</option></select></div>
      </div>
      <div class="field"><label for="e-muscles">Muskelgruppen (optional, Komma-getrennt)</label><input id="e-muscles" value="${existing?.muscleGroups?.join(', ') || ''}" /></div>
      <div class="field"><label for="e-note">Notiz (optional)</label><textarea id="e-note">${existing ? escapeHtml(existing.note || '') : ''}</textarea></div>
      <button class="btn btn-primary btn-block" type="submit">${icon('check')} Speichern</button>
    </form>
  `);
  dlg.querySelector('#ex-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = dlg.querySelector('#e-name').value.trim();
    if (!name) return;
    const resistanceType = dlg.querySelector('#e-resistance').value;
    await saveExercise({
      id: existing?.id,
      name,
      resistanceType,
      measureType: dlg.querySelector('#e-measure').value,
      unit: RESISTANCE_TYPES[resistanceType].unit,
      muscleGroups: dlg.querySelector('#e-muscles').value.split(',').map((s) => s.trim()).filter(Boolean),
      note: dlg.querySelector('#e-note').value.trim(),
    });
    toast('Übung gespeichert');
    dlg.close();
    renderExercisesTab(document.getElementById('sport-tab-content'));
  });
}

/* ---------------- Tab: Training (Start + aktives Training) ---------------- */

let timerHandle = null; // gemeinsamer Interval-Handle für Pausentimer/Elapsed-Anzeige

function navigateToTraining() {
  document.querySelector('[data-tab="training"]')?.click();
}

async function renderTrainingTab(root) {
  clearInterval(timerHandle);
  const activeWorkout = await getActiveWorkout();
  if (activeWorkout) { await renderActiveWorkout(root, activeWorkout); return; }

  const plans = (await getPlans()).filter((p) => p.active !== false);
  root.innerHTML = `
    <div class="section-title"><h2>Training starten</h2></div>
    ${plans.length ? plans.map((p) => `
      <div class="item-row" style="margin-bottom:var(--sp-2)">
        <div class="item-row__main">
          <div class="item-row__title">${escapeHtml(p.name)}</div>
          <div class="item-row__meta">${p.days.length} Trainingstag(e)</div>
        </div>
        <button class="btn btn-primary" data-start-plan="${p.id}">${icon('play')} Starten</button>
      </div>`).join('') : emptyState('Noch kein aktiver Trainingsplan. Lege einen im Tab "Pläne" an oder starte direkt ein freies Training.')}
    <button class="btn btn-secondary btn-block" id="free-training-btn" style="margin-top:var(--sp-4)">${icon('plus')} Freies Training starten</button>
    <button class="btn btn-ghost btn-block" id="interval-timer-btn" style="margin-top:var(--sp-3)">${icon('clock')} Intervalltimer</button>
  `;
  root.querySelectorAll('[data-start-plan]').forEach((b) => b.addEventListener('click', async () => {
    const plan = plans.find((p) => p.id === b.dataset.startPlan);
    await startPlanWorkout(plan);
    renderTrainingTab(root);
  }));
  root.querySelector('#free-training-btn').addEventListener('click', async () => {
    await startFreeWorkout();
    renderTrainingTab(root);
  });
  root.querySelector('#interval-timer-btn').addEventListener('click', () => openIntervalTimerSheet());
}

async function startPlanWorkout(plan) {
  let day = plan.days[0];
  if (plan.days.length > 1) {
    day = await new Promise((resolve) => {
      const dlg = createSheet(`
        <div class="sheet__header"><h2>Welcher Tag?</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
        <div class="list">${plan.days.map((d, i) => `<button class="btn btn-secondary btn-block" data-day-pick="${i}" style="margin-bottom:var(--sp-2)">${escapeHtml(d.title)}</button>`).join('')}</div>
      `);
      dlg.querySelectorAll('[data-day-pick]').forEach((b) => b.addEventListener('click', () => { resolve(plan.days[+b.dataset.dayPick]); dlg.close(); }));
      dlg.addEventListener('close', () => resolve(plan.days[0]));
    });
  }
  const state = {
    planId: plan.id,
    planName: plan.name,
    dayId: day.id,
    dayTitle: day.title,
    blocks: JSON.parse(JSON.stringify(day.blocks)),
    blockIndex: 0,
    roundNumber: 1,
    rounds: [],
    isFree: false,
    startTime: Date.now(),
    date: todayIso(),
    phase: 'active', // 'active' | 'pause'
    pause: null,
  };
  await saveActiveWorkout(state);
}

async function startFreeWorkout() {
  const state = {
    planId: null, planName: null, dayTitle: 'Freies Training',
    blocks: [], blockIndex: 0, roundNumber: 1, rounds: [],
    isFree: true, startTime: Date.now(), date: todayIso(), phase: 'active', pause: null,
  };
  await saveActiveWorkout(state);
}

async function renderActiveWorkout(root, w) {
  const currentBlock = w.blocks[w.blockIndex] || null;

  if (w.phase === 'pause') { renderPausePhase(root, w); return; }

  root.innerHTML = `
    <div class="card" style="margin-bottom:var(--sp-3);display:flex;justify-content:space-between;align-items:center">
      <div>
        <strong>${escapeHtml(w.dayTitle)}</strong>
        <div class="field-hint" id="elapsed-time">Dauer: 00:00</div>
      </div>
      <button class="btn btn-danger" id="finish-btn">${icon('check')} Abschließen</button>
    </div>
    <div id="round-host"></div>
    <button class="btn btn-ghost btn-block" id="abort-btn" style="margin-top:var(--sp-4)">Training abbrechen</button>
  `;
  startElapsedTicker(w.startTime);
  root.querySelector('#finish-btn').addEventListener('click', () => finishWorkout(root, w));
  root.querySelector('#abort-btn').addEventListener('click', () => abortWorkout(root, w));

  const roundHost = root.querySelector('#round-host');
  if (w.isFree) renderFreeRoundEditor(roundHost, root, w);
  else if (currentBlock) renderPlanRoundEditor(roundHost, root, w, currentBlock);
  else renderNothingLeft(roundHost, root, w);
}

function renderNothingLeft(host) {
  host.innerHTML = `<div class="card">Alle geplanten Sätze sind erledigt. Du kannst das Training jetzt abschließen oder weitere freie Sätze ergänzen.</div>`;
}

function renderPlanRoundEditor(host, root, w, block) {
  host.innerHTML = `
    <div class="section-title"><h2>Satz ${w.roundNumber} / ${block.targetSets}</h2></div>
    ${block.exercises.map((ex, i) => exerciseLogCard(ex, i)).join('')}
    <button class="btn btn-primary btn-block" id="log-round-btn" style="margin-top:var(--sp-3)">${icon('check')} Satz protokollieren</button>
  `;
  host.querySelector('#log-round-btn').addEventListener('click', async () => {
    const entries = block.exercises.map((ex, i) => readExerciseLogCard(host, ex, i));
    w.rounds.push({ blockIndex: w.blockIndex, roundNumber: w.roundNumber, entries, completedAt: Date.now() });
    if (w.roundNumber < block.targetSets) { w.roundNumber += 1; }
    else { w.blockIndex += 1; w.roundNumber = 1; }
    w.phase = 'pause';
    w.pause = { secondsTotal: block.restSeconds ?? 60, secondsLeft: block.restSeconds ?? 60, running: false, showQuiz: false };
    await saveActiveWorkout(w);
    renderActiveWorkout(root, w);
  });
}

function renderFreeRoundEditor(host, root, w) {
  if (!w._freeDraft) w._freeDraft = [];
  host.innerHTML = `
    <div class="section-title"><h2>Freier Satz ${w.rounds.filter((r) => r.blockIndex === null).length + 1}</h2></div>
    <div id="free-exercises">${w._freeDraft.map((ex, i) => exerciseLogCard(ex, i)).join('')}</div>
    <button class="btn btn-secondary btn-block" id="add-free-ex-btn" style="margin:var(--sp-2) 0">${icon('plus')} Übung hinzufügen</button>
    ${w._freeDraft.length ? `<button class="btn btn-primary btn-block" id="log-free-round-btn">${icon('check')} Satz protokollieren</button>` : ''}
  `;
  host.querySelector('#add-free-ex-btn').addEventListener('click', () => openFreeExercisePicker(async (chosen) => {
    w._freeDraft.push(chosen);
    renderFreeRoundEditor(host, root, w);
  }));
  const logBtn = host.querySelector('#log-free-round-btn');
  if (logBtn) logBtn.addEventListener('click', async () => {
    const entries = w._freeDraft.map((ex, i) => readExerciseLogCard(host, ex, i));
    w.rounds.push({ blockIndex: null, roundNumber: null, entries, completedAt: Date.now() });
    w._freeDraft = [];
    w.phase = 'pause';
    w.pause = { secondsTotal: 60, secondsLeft: 60, running: false, showQuiz: false };
    await saveActiveWorkout(w);
    renderActiveWorkout(root, w);
  });
}

function openFreeExercisePicker(onChosen) {
  getExercises().then((exercises) => {
    const dlg = createSheet(`
      <div class="sheet__header"><h2>Übung wählen</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
      <div class="field"><label>Aus Bibliothek</label><select id="fx-pick"><option value="">— Neue Übung —</option>${exercises.map((e) => `<option value="${e.id}">${escapeHtml(e.name)}</option>`).join('')}</select></div>
      <div class="field"><label>Name (falls neu)</label><input id="fx-name" /></div>
      <div class="field-row">
        <div class="field"><label>Gerät</label><select id="fx-resistance">${resistanceOptions('bodyweight')}</select></div>
        <div class="field"><label>Messart</label><select id="fx-measure"><option value="reps">Wdh.</option><option value="time">Zeit</option></select></div>
      </div>
      <button class="btn btn-primary btn-block" id="fx-confirm">${icon('check')} Übernehmen</button>
    `);
    const pick = dlg.querySelector('#fx-pick');
    pick.addEventListener('change', () => {
      const ex = exercises.find((e) => e.id === pick.value);
      if (ex) {
        dlg.querySelector('#fx-name').value = ex.name;
        dlg.querySelector('#fx-resistance').value = ex.resistanceType;
        dlg.querySelector('#fx-measure').value = ex.measureType;
      }
    });
    dlg.querySelector('#fx-confirm').addEventListener('click', () => {
      const resistanceType = dlg.querySelector('#fx-resistance').value;
      const name = dlg.querySelector('#fx-name').value.trim() || exercises.find((e) => e.id === pick.value)?.name;
      if (!name) return;
      onChosen({
        exerciseId: pick.value || null,
        name,
        resistanceType,
        measureType: dlg.querySelector('#fx-measure').value,
        unit: RESISTANCE_TYPES[resistanceType].unit,
        targetReps: null, targetTime: null, targetWeight: null,
      });
      dlg.close();
    });
  });
}

function exerciseLogCard(ex, i) {
  const targetStr = ex.targetReps || ex.targetTime || ex.targetWeight
    ? `<span class="field-hint">Ziel: ${targetLabel(ex)}</span>` : '';
  return `
    <div class="card" style="margin-bottom:var(--sp-2)" data-log-card="${i}">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <strong>${escapeHtml(ex.name)}</strong>
        ${targetStr}
      </div>
      <div class="field-row">
        ${ex.measureType === 'time'
          ? `<div class="field"><label>Zeit (Sek.)</label><input type="number" min="0" data-log-time value="${ex.targetTime ?? ''}" /></div>`
          : `<div class="field"><label>Wiederholungen</label><input type="number" min="0" data-log-reps value="${ex.targetReps ?? ''}" /></div>`}
        ${ex.resistanceType === 'bodyweight' ? '' : `<div class="field"><label>${ex.unit}</label><input type="number" step="0.5" min="0" data-log-weight value="${ex.targetWeight ?? ''}" /></div>`}
      </div>
      <label class="checkbox-row"><input type="checkbox" data-log-skip /> Übersprungen</label>
    </div>`;
}

function readExerciseLogCard(host, ex, i) {
  const card = host.querySelector(`[data-log-card="${i}"]`);
  const skipped = card.querySelector('[data-log-skip]')?.checked || false;
  return {
    exerciseId: ex.exerciseId || null,
    name: ex.name,
    resistanceType: ex.resistanceType,
    measureType: ex.measureType,
    unit: ex.unit,
    targetReps: ex.targetReps ?? null,
    targetTime: ex.targetTime ?? null,
    targetWeight: ex.targetWeight ?? null,
    actualReps: numOrNull(card.querySelector('[data-log-reps]')?.value),
    actualTime: numOrNull(card.querySelector('[data-log-time]')?.value),
    actualWeight: numOrNull(card.querySelector('[data-log-weight]')?.value),
    skipped,
  };
}

/* ---- Pausenphase (Timer + optionales Quiz) ---- */

function renderPausePhase(root, w) {
  clearInterval(timerHandle);
  root.innerHTML = `
    <div class="card" style="text-align:center;margin-bottom:var(--sp-4)">
      <div class="field-hint" style="margin-bottom:var(--sp-2)">Pause</div>
      <div id="pause-clock" style="font-family:var(--font-mono);font-size:var(--fs-xxl);font-weight:700">${formatClock(w.pause.secondsLeft)}</div>
      <div style="display:flex;gap:var(--sp-2);justify-content:center;margin-top:var(--sp-3)">
        <button class="btn-icon" id="pause-minus">-15s</button>
        <button class="btn btn-primary" id="pause-toggle">${icon(w.pause.running ? 'pause' : 'play')} ${w.pause.running ? 'Pause halten' : 'Timer starten'}</button>
        <button class="btn-icon" id="pause-plus">+15s</button>
      </div>
      ${!w.pause.showQuiz ? `<button class="btn btn-secondary btn-block" id="start-quiz-btn" style="margin-top:var(--sp-3)">${icon('brain')} Quizfrage während der Pause</button>` : ''}
      <button class="btn btn-ghost btn-block" id="skip-pause-btn" style="margin-top:var(--sp-3)">Pause überspringen → weiter</button>
    </div>
    <div id="pause-quiz-host"></div>
  `;
  if (w.pause.showQuiz) renderPauseQuiz(root.querySelector('#pause-quiz-host'), w);

  root.querySelector('#pause-toggle').addEventListener('click', async () => {
    w.pause.running = !w.pause.running;
    await saveActiveWorkout(w);
    renderPausePhase(root, w);
  });
  root.querySelector('#pause-minus').addEventListener('click', async () => { w.pause.secondsLeft = Math.max(0, w.pause.secondsLeft - 15); await saveActiveWorkout(w); renderPausePhase(root, w); });
  root.querySelector('#pause-plus').addEventListener('click', async () => { w.pause.secondsLeft += 15; await saveActiveWorkout(w); renderPausePhase(root, w); });
  const quizBtn = root.querySelector('#start-quiz-btn');
  if (quizBtn) quizBtn.addEventListener('click', async () => { w.pause.showQuiz = true; w.pause.running = true; await saveActiveWorkout(w); renderPausePhase(root, w); });
  root.querySelector('#skip-pause-btn').addEventListener('click', async () => {
    w.phase = 'active'; w.pause = null;
    await saveActiveWorkout(w);
    renderActiveWorkout(root, w);
  });

  if (w.pause.running && w.pause.secondsLeft > 0) {
    timerHandle = setInterval(async () => {
      w.pause.secondsLeft -= 1;
      const clockEl = document.getElementById('pause-clock');
      if (clockEl) clockEl.textContent = formatClock(Math.max(0, w.pause.secondsLeft));
      if (w.pause.secondsLeft <= 0) {
        clearInterval(timerHandle);
        w.pause.running = false;
        await saveActiveWorkout(w);
        toast('Pause vorbei');
      }
    }, 1000);
  }
}

function renderPauseQuiz(host, w) {
  getActiveQuestions().then((questions) => {
    if (!questions.length) { host.innerHTML = '<p class="field-hint">Noch keine Quizfragen vorhanden.</p>'; return; }
    const q = questions[Math.floor(Math.random() * questions.length)];
    host.innerHTML = `
      <div class="card">
        <p style="margin-bottom:var(--sp-3)">${escapeHtml(q.text)}</p>
        ${q.options.map((opt, i) => `<button class="answer-option" data-opt="${i}"><span class="answer-option__letter">${String.fromCharCode(65 + i)}</span>${escapeHtml(opt)}</button>`).join('')}
      </div>
    `;
    host.querySelectorAll('[data-opt]').forEach((btn) => btn.addEventListener('click', async () => {
      const chosen = +btn.dataset.opt;
      const correct = chosen === q.correctIndex;
      host.querySelectorAll('[data-opt]').forEach((b, i) => {
        b.setAttribute('disabled', 'true');
        if (i === q.correctIndex) b.classList.add('is-correct');
        else if (i === chosen) b.classList.add('is-wrong');
      });
      await logAnswer(q, correct, 'quiz');
      w.quizAnswered = (w.quizAnswered || 0) + 1;
      await saveActiveWorkout(w);
      setTimeout(() => renderPauseQuiz(host, w), 900);
    }));
  });
}

/* ---- Abschluss / Abbruch ---- */

async function finishWorkout(root, w) {
  if (!w.rounds.length) { if (!confirm('Noch keine Sätze protokolliert. Trotzdem abschließen?')) return; }
  const newPRs = await detectNewPRs(w.rounds);
  const endTime = Date.now();
  const durationSeconds = Math.round((endTime - w.startTime) / 1000);
  const session = {
    planId: w.planId, planName: w.planName, dayId: w.dayId || null, dayTitle: w.dayTitle,
    date: w.date, startTime: w.startTime, endTime, durationSeconds,
    rounds: w.rounds, quizAnswered: w.quizAnswered || 0, aborted: false,
  };
  await saveCompletedSession(session);
  await clearActiveWorkout();
  clearInterval(timerHandle);

  const totalExercises = new Set(w.rounds.flatMap((r) => r.entries.map((e) => e.name))).size;
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Training abgeschlossen 🎉</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <div class="progress-row"><div class="progress-row__label"><span>Dauer</span><span>${formatDuration(durationSeconds)}</span></div></div>
    <div class="progress-row"><div class="progress-row__label"><span>Sätze absolviert</span><span>${w.rounds.length}</span></div></div>
    <div class="progress-row"><div class="progress-row__label"><span>Übungen</span><span>${totalExercises}</span></div></div>
    <div class="progress-row"><div class="progress-row__label"><span>Quizfragen</span><span>${w.quizAnswered || 0}</span></div></div>
    ${newPRs.length ? `<div class="section-title"><h2>Neue Bestleistungen</h2></div>${newPRs.map((pr) => `<div class="item-row" style="margin-bottom:6px"><div class="item-row__main"><div class="item-row__title">${escapeHtml(pr.name)}</div><div class="item-row__meta">${escapeHtml(pr.text)}</div></div></div>`).join('')}` : ''}
    <button class="btn btn-primary btn-block" id="close-summary-btn" style="margin-top:var(--sp-4)">Fertig</button>
  `);
  dlg.querySelector('#close-summary-btn').addEventListener('click', () => dlg.close());
  dlg.addEventListener('close', () => renderTrainingTab(document.getElementById('sport-tab-content')));
}

async function abortWorkout(root, w) {
  if (!confirm('Training wirklich abbrechen? Bereits protokollierte Sätze werden als unvollständiges Training gespeichert, der Rest verworfen.')) return;
  clearInterval(timerHandle);
  if (w.rounds.length) {
    await saveCompletedSession({
      planId: w.planId, planName: w.planName, dayId: w.dayId || null, dayTitle: w.dayTitle,
      date: w.date, startTime: w.startTime, endTime: Date.now(),
      durationSeconds: Math.round((Date.now() - w.startTime) / 1000),
      rounds: w.rounds, quizAnswered: w.quizAnswered || 0, aborted: true,
    });
  }
  await clearActiveWorkout();
  renderTrainingTab(document.getElementById('sport-tab-content'));
}

function startElapsedTicker(startTime) {
  const update = () => {
    const el = document.getElementById('elapsed-time');
    if (el) el.textContent = `Dauer: ${formatClock(Math.floor((Date.now() - startTime) / 1000))}`;
  };
  update();
  timerHandle = setInterval(update, 1000);
}

/* ---- Intervalltimer (unabhängig vom Trainingsflow) ---- */

function openIntervalTimerSheet() {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Intervalltimer</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <div class="field-row">
      <div class="field"><label>Belastung (Sek.)</label><input type="number" id="iv-work" min="1" value="30" /></div>
      <div class="field"><label>Pause (Sek.)</label><input type="number" id="iv-rest" min="0" value="15" /></div>
      <div class="field"><label>Intervalle</label><input type="number" id="iv-count" min="1" value="6" /></div>
    </div>
    <button class="btn btn-primary btn-block" id="iv-start">${icon('play')} Starten</button>
    <div id="iv-host" style="margin-top:var(--sp-4)"></div>
  `);
  dlg.querySelector('#iv-start').addEventListener('click', () => {
    const work = Number(dlg.querySelector('#iv-work').value) || 30;
    const rest = Number(dlg.querySelector('#iv-rest').value) || 0;
    const count = Number(dlg.querySelector('#iv-count').value) || 1;
    runIntervalTimer(dlg.querySelector('#iv-host'), work, rest, count);
  });
}

function runIntervalTimer(host, work, rest, count) {
  let interval = 1, phase = 'work', secondsLeft = work;
  let handle;
  function tick() {
    host.innerHTML = `
      <div style="text-align:center">
        <div class="field-hint">Intervall ${interval} / ${count} · ${phase === 'work' ? 'Belastung' : 'Pause'}</div>
        <div style="font-family:var(--font-mono);font-size:var(--fs-xxl);font-weight:700">${formatClock(secondsLeft)}</div>
        <button class="btn btn-ghost" id="iv-stop" style="margin-top:var(--sp-3)">Stoppen</button>
      </div>`;
    host.querySelector('#iv-stop').addEventListener('click', () => { clearInterval(handle); host.innerHTML = '<p class="field-hint">Intervalltimer gestoppt.</p>'; });
  }
  tick();
  handle = setInterval(() => {
    secondsLeft -= 1;
    if (secondsLeft < 0) {
      if (phase === 'work' && rest > 0) { phase = 'rest'; secondsLeft = rest; }
      else if (interval < count) { interval += 1; phase = 'work'; secondsLeft = work; }
      else { clearInterval(handle); host.innerHTML = '<p class="field-hint">Intervalltimer fertig 🎉</p>'; toast('Intervalltimer fertig'); return; }
      toast(phase === 'work' ? 'Belastung!' : 'Pause!');
    }
    tick();
  }, 1000);
}

/* ---------------- Tab: Historie ---------------- */

async function renderHistoryTab(root) {
  const sessions = await getSessions();
  root.innerHTML = `
    <button class="btn btn-secondary btn-block" id="export-btn" style="margin-bottom:var(--sp-4)">${icon('download')} Trainingsdaten exportieren</button>
    ${sessions.length ? sessions.map(sessionRow).join('') : emptyState('Noch kein Training absolviert.')}
  `;
  root.querySelector('#export-btn').addEventListener('click', async () => { await exportSportData(); toast('Export gestartet'); });
  root.querySelectorAll('[data-toggle-session]').forEach((b) => b.addEventListener('click', () => {
    const detail = root.querySelector(`[data-session-detail="${b.dataset.toggleSession}"]`);
    detail.hidden = !detail.hidden;
  }));
  root.querySelectorAll('[data-del-session]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('Trainingseintrag löschen?')) return;
    await deleteSession(b.dataset.delSession);
    renderHistoryTab(root);
  }));
}

function sessionRow(s) {
  if (isLegacySession(s)) {
    const totalSets = s.entries.reduce((sum, e) => sum + (Number(e.sets) || 0), 0);
    return `
      <div class="item-row" style="margin-bottom:var(--sp-3)">
        <div class="item-row__main">
          <div class="item-row__title">${escapeHtml(s.title || 'Training')}</div>
          <div class="item-row__meta">${s.date} · ${s.entries.length} Übungen · ${totalSets} Sätze (altes Format)</div>
        </div>
        <div class="item-row__actions"><button class="btn-icon" data-del-session="${s.id}" aria-label="Löschen">${icon('trash')}</button></div>
      </div>`;
  }
  const exerciseCount = new Set(s.rounds.flatMap((r) => r.entries.map((e) => e.name))).size;
  return `
    <div class="item-row" style="margin-bottom:var(--sp-3);flex-direction:column;align-items:stretch">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;width:100%">
        <div class="item-row__main" data-toggle-session="${s.id}" style="cursor:pointer">
          <div class="item-row__title">${escapeHtml(s.dayTitle || s.planName || 'Training')}${s.aborted ? ' <span class="field-hint">(abgebrochen)</span>' : ''}</div>
          <div class="item-row__meta">${s.date} · ${formatDuration(s.durationSeconds || 0)} · ${s.rounds.length} Sätze · ${exerciseCount} Übungen</div>
        </div>
        <div class="item-row__actions"><button class="btn-icon" data-del-session="${s.id}" aria-label="Löschen">${icon('trash')}</button></div>
      </div>
      <div data-session-detail="${s.id}" hidden style="margin-top:var(--sp-2)">
        ${s.rounds.map((r) => `
          <div class="plan-exercise-line" style="flex-direction:column;align-items:flex-start;padding:var(--sp-2) 0;border-top:1px dashed var(--color-border)">
            ${r.entries.map((e) => `<div style="display:flex;justify-content:space-between;width:100%"><span>${escapeHtml(e.name)}${e.skipped ? ' (übersprungen)' : ''}</span><span style="font-family:var(--font-mono)">${e.skipped ? '–' : actualLabel(e)}</span></div>`).join('')}
          </div>`).join('')}
      </div>
    </div>`;
}

function actualLabel(e) {
  if (e.measureType === 'time') return `${e.actualTime ?? '–'}s`;
  const w = e.resistanceType === 'bodyweight' ? '' : ` · ${e.actualWeight ?? '–'}${e.unit}`;
  return `${e.actualReps ?? '–'}${w}`;
}

/* ---------------- Tab: Fortschritt ---------------- */

async function renderProgressTab(root) {
  const stats = await getOverallSportStats();
  root.innerHTML = `
    <div class="section-title"><h2>Übersicht</h2></div>
    <div class="progress-row"><div class="progress-row__label"><span>Trainings gesamt</span><span>${stats.totalSessions}</span></div></div>
    <div class="progress-row"><div class="progress-row__label"><span>Diese Woche</span><span>${stats.sessionsThisWeek}</span></div></div>
    <div class="progress-row"><div class="progress-row__label"><span>Diesen Monat</span><span>${stats.sessionsThisMonth}</span></div></div>
    <div class="progress-row"><div class="progress-row__label"><span>Gesamtdauer</span><span>${formatDuration(stats.totalDurationSeconds)}</span></div></div>
    <div class="progress-row"><div class="progress-row__label"><span>Gesamtvolumen (Gewicht × Wdh.)</span><span>${Math.round(stats.totalVolume)}</span></div></div>
    <div class="section-title"><h2>Persönliche Bestleistungen &amp; Verlauf</h2></div>
    ${stats.exerciseProgress.length ? stats.exerciseProgress.map(exerciseProgressCard).join('') : emptyState('Noch keine Trainingsdaten für eine Fortschrittsanalyse vorhanden.')}
  `;
}

function exerciseProgressCard(g) {
  const prLabel = g.pr ? (g.pr.type === 'time' ? `${g.pr.value}s Bestzeit` : g.pr.type === 'reps' ? `${g.pr.value} Wdh. Bestleistung` : `${g.pr.value}${g.pr.unit} Bestgewicht`) : '–';
  const values = g.history.map((h) => h.value).filter((v) => v != null);
  return `
    <div class="card" style="margin-bottom:var(--sp-3)">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <strong>${escapeHtml(g.name)}</strong>
        <span style="font-family:var(--font-mono)">${prLabel}</span>
      </div>
      ${sparklineSvg(values)}
    </div>`;
}

/* ---------------- Tab: Körperdaten (unverändert ggü. v1.0) ---------------- */

async function renderBodyTab(root) {
  const metrics = await getBodyMetrics();
  const customKeys = [...new Set(metrics.map((m) => m.type))].filter((k) => !BUILTIN_METRIC_TYPES.some((b) => b.key === k));
  const allTypes = [...BUILTIN_METRIC_TYPES, ...customKeys.map((k) => ({ key: k, label: k, unit: '' }))];
  const grouped = groupBy(metrics, 'date');
  const dates = Object.keys(grouped).sort((a, b) => b.localeCompare(a));

  root.innerHTML = `
    ${allTypes.filter((t) => metrics.some((m) => m.type === t.key)).map((t) => metricSparklineCard(t, metrics.filter((m) => m.type === t.key))).join('')}
    <div class="section-title"><h2>Verlauf</h2></div>
    ${dates.length ? dates.map((d) => `
      <div class="card" style="margin-bottom:var(--sp-2)">
        <div class="metric-history-row__date" style="margin-bottom:6px">${d}</div>
        ${grouped[d].map((m) => `
          <div class="metric-history-row">
            <span>${labelForType(allTypes, m.type)}</span>
            <span>${m.value} ${unitForType(allTypes, m.type)} <button class="btn-icon" style="width:28px;height:28px;margin-left:6px" data-del-metric="${m.id}">${icon('trash')}</button></span>
          </div>`).join('')}
      </div>`).join('') : emptyState('Noch keine Körpermessungen erfasst.')}
  `;
  root.querySelectorAll('[data-del-metric]').forEach((b) => b.addEventListener('click', async () => {
    await deleteBodyMetric(b.dataset.delMetric);
    renderBodyTab(root);
  }));
}

function metricSparklineCard(type, points) {
  const sorted = [...points].sort((a, b) => a.date.localeCompare(b.date));
  const values = sorted.map((p) => p.value);
  const latest = values[values.length - 1];
  const first = values[0];
  const delta = (latest - first);
  return `
    <div class="card" style="margin-bottom:var(--sp-3)">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <strong>${type.label}</strong>
        <span style="font-family:var(--font-mono)">${latest} ${type.unit} <span style="color:${delta <= 0 ? 'var(--color-success)' : 'var(--color-accent)'}">(${delta > 0 ? '+' : ''}${delta.toFixed(1)})</span></span>
      </div>
      ${sparklineSvg(values)}
    </div>`;
}

function sparklineSvg(values) {
  if (values.length < 2) return '<p class="field-hint">Noch nicht genug Daten für einen Verlauf.</p>';
  const w = 300, h = 56, pad = 4;
  const min = Math.min(...values), max = Math.max(...values);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = pad + (i / (values.length - 1)) * (w - pad * 2);
    const y = h - pad - ((v - min) / range) * (h - pad * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  return `<svg class="sparkline" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><polyline points="${pts}" fill="none" stroke="var(--color-teal)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}

function labelForType(types, key) { return types.find((t) => t.key === key)?.label || key; }
function unitForType(types, key) { return types.find((t) => t.key === key)?.unit || ''; }

function openBodyMetricSheet(root) {
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Körpermessung erfassen</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <form id="metric-form">
      <div class="field"><label for="m-date">Datum</label><input id="m-date" type="date" value="${todayIso()}" required /></div>
      <div id="metric-rows">${BUILTIN_METRIC_TYPES.map((t) => `
        <div class="field-row" style="align-items:flex-end">
          <div class="field" style="flex:2"><label>${t.label}</label><input type="number" step="0.1" data-metric="${t.key}" placeholder="${t.unit}" /></div>
        </div>`).join('')}
      </div>
      <div class="field"><label for="m-custom-name">Eigene Messart (optional)</label><input id="m-custom-name" placeholder="z.B. Oberschenkel" /></div>
      <div class="field"><label for="m-custom-value">Wert</label><input id="m-custom-value" type="number" step="0.1" /></div>
      <button class="btn btn-primary btn-block" type="submit">${icon('check')} Speichern</button>
    </form>
  `);
  dlg.querySelector('#metric-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const date = dlg.querySelector('#m-date').value;
    let count = 0;
    for (const t of BUILTIN_METRIC_TYPES) {
      const val = dlg.querySelector(`[data-metric="${t.key}"]`).value;
      if (val !== '') { await saveBodyMetric({ date, type: t.key, value: Number(val) }); count += 1; }
    }
    const customName = dlg.querySelector('#m-custom-name').value.trim();
    const customValue = dlg.querySelector('#m-custom-value').value;
    if (customName && customValue !== '') {
      await saveBodyMetric({ date, type: customName, value: Number(customValue) });
      count += 1;
    }
    if (!count) { toast('Bitte mindestens einen Wert eingeben', 'danger'); return; }
    toast('Messung gespeichert');
    dlg.close();
    renderBodyTab(document.getElementById('sport-tab-content'));
  });
}

/* ---------------- Helpers ---------------- */

function groupBy(arr, key) {
  return arr.reduce((acc, item) => { (acc[item[key]] ??= []).push(item); return acc; }, {});
}
function numOrNull(v) { return v === '' || v == null ? null : Number(v); }
function emptyState(text) { return `<div class="empty-state">${icon('dumbbell')}<p>${escapeHtml(text)}</p></div>`; }
function formatClock(totalSeconds) {
  const s = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}
function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${m}min`;
  return `${m} min`;
}

function createSheet(innerHtml) {
  const dlg = document.createElement('dialog');
  dlg.className = 'sheet';
  dlg.innerHTML = `<div class="sheet__handle"></div><div class="sheet__body">${innerHtml}</div>`;
  document.body.appendChild(dlg);
  dlg.addEventListener('close', () => dlg.remove());
  dlg.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => dlg.close()));
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  dlg.showModal();
  return dlg;
}
