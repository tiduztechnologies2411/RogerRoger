/**
 * sportPrompt.js – Master-Prompt zur externen Erzeugung von Trainingsplänen
 * und Beschreibung des Trainingsdaten-Exportformats.
 *
 * WICHTIG: TRAINING_PROMPT muss exakt zum Importschema passen, das in sport.js
 * (validateImportPlan / PLAN_SCHEMA_VERSION) implementiert ist. Bei Schema-Änderungen
 * MUSS TRAINING_PROMPT_VERSION erhöht und der Text hier aktualisiert werden
 * (siehe CLAUDE.md, Regel 6/9).
 */

export const TRAINING_PROMPT_VERSION = 'v1.1';
export const PLAN_SCHEMA_VERSION = 'roger-roger-trainingsplan-v3';
export const EXPORT_SCHEMA_VERSION = '1.0';

export const TRAINING_PROMPT = `Du erstellst einen Trainingsplan für die App "Roger Roger" im folgenden
exakten JSON-Format. Gib AUSSCHLIESSLICH valides JSON zurück – keinen einleitenden
Text, keine Erklärungen, keine Markdown-Codeblock-Markierungen.

FORMAT:
{
  "schemaVersion": "${PLAN_SCHEMA_VERSION}",
  "name": "Name des Plans",
  "description": "Optionale Kurzbeschreibung",
  "startDate": "2026-08-24",
  "days": [
    {
      "title": "z.B. Tag 1 – Oberkörper",
      "weekdays": [1, 5],
      "blocks": [
        {
          "targetSets": 3,
          "restSeconds": 90,
          "exercises": [
            {
              "name": "Übungsname",
              "resistanceType": "weight",
              "measureType": "reps",
              "targetReps": 8,
              "targetWeight": 12,
              "unit": "kg",
              "note": "Optionaler Hinweis"
            }
          ]
        }
      ]
    }
  ]
}

REGELN:
- "schemaVersion" ist immer der String "${PLAN_SCHEMA_VERSION}".
- "name" ist Pflicht. "description" ist optional.
- "startDate" ist optional (Format JJJJ-MM-TT). Fehlt es, wird beim Import automatisch
  das heutige Datum verwendet. Ab diesem Datum werden die unten zugewiesenen Wochentage
  im Kalender berücksichtigt – kein Trainingstermin vor diesem Datum.
- "days" ist ein Array mit mindestens einem Trainingstag, jeder Tag hat "title" und
  mindestens einen Block in "blocks". "weekdays" ist optional: ein Array von ISO-Wochentagen
  (1 = Montag … 7 = Sonntag), an denen dieser Tag automatisch im Kalender erscheinen soll
  (z.B. [1, 5] für Montag und Freitag). Ohne "weekdays" erscheint der Tag nicht automatisch
  im Kalender und wird beim Training-Start weiterhin manuell ausgewählt.
- Ein "block" entspricht einem "Satz" im Sinne der App: eine oder mehrere Übungen,
  die zusammen ausgeführt werden (bei nur einer Übung ein normaler Satz, bei mehreren
  ein Supersatz), gefolgt von einer gemeinsamen Pause. "targetSets" (Zahl ≥ 1) gibt an,
  wie oft dieser Block wiederholt wird. "restSeconds" (Zahl ≥ 0) ist die Pause danach.
- "exercises" innerhalb eines Blocks ist ein Array mit mindestens einer Übung.
- "resistanceType" ist genau eines von: "weight" (Kurzhanteln, Einheit kg),
  "band" (Widerstandsband, Einheit lbs), "bodyweight" (Körpergewicht, keine Einheit).
- "measureType" ist genau eines von: "reps" (Wiederholungen) oder "time" (Zeit in Sekunden).
- Bei "measureType": "reps" ist "targetReps" (Zahl > 0) Pflicht. Bei "measureType": "time"
  ist "targetTime" (Zahl > 0, Sekunden) Pflicht statt "targetReps".
- "targetWeight" ist Pflicht bei "resistanceType": "weight" oder "band" (Zahl > 0), bei
  "bodyweight" wird "targetWeight" weggelassen (NICHT 0 setzen).
- "unit" muss zum "resistanceType" passen ("kg" bei weight, "lbs" bei band, leer/weggelassen
  bei bodyweight).
- "note" ist optional.
- Nutze ausschließlich die tatsächlich vorhandene Ausrüstung des Nutzers: Kurzhanteln (kg),
  ein Widerstandsband zum Einhaken in den Türrahmen (lbs), Körpergewicht.
- Keine widersprüchlichen Angaben, keine zusätzlichen Felder außerhalb des Schemas.
- Gib NUR das JSON-Objekt zurück, keinen Text davor oder danach.

Erstelle jetzt einen Trainingsplan nach diesem Schema für folgende Vorgaben
(vom Nutzer zu ergänzen):

Ziel/Fokus: [z.B. "3-Tage-Ganzkörper-Plan für zuhause"]
Verfügbare Ausrüstung: Kurzhanteln, Widerstandsband (Türrahmen), Körpergewicht
Erfahrungslevel: [z.B. "Anfänger", "Fortgeschritten"]
Optional – bisherige Trainingsdaten (aus "Trainingsdaten exportieren"): [hier einfügen, falls vorhanden]`;
