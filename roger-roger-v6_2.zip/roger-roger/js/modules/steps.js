/**
 * steps.js – manueller Tages-Schrittestand auf dem Dashboard (V1.5).
 *
 * Bewusst nur manuelle Eingabe: keine Sensor-/Health-Integration, keine
 * Berechtigungsdialoge (siehe Auftrag). Ein Wert pro Kalendertag – die `id`
 * im `steps`-Store ist direkt das ISO-Datum (`todayIso()`), dadurch ist
 * "genau ein Wert pro Tag" strukturell erzwungen (jedes `put` überschreibt
 * nur den Eintrag desselben Tages), ohne dass eine zusätzliche Abfrage nötig
 * wäre. Frühere Tageswerte bleiben als eigene Zeilen im selben Store erhalten.
 * Dieses Modul stellt bewusst kein eigenes `render(container)` für eine
 * Vollseite bereit, da Schritte laut Auftrag nur auf dem Dashboard erscheinen sollen.
 */
import { db } from '../core/db.js';
import { icon } from '../core/icons.js';
import { todayIso, toast } from '../core/utils.js';

const S = db.STORES;

/* ---------------- Datenzugriff ---------------- */

export async function getStepsForDate(date = todayIso()) {
  const row = await db.get(S.steps, date);
  return row?.value ?? null;
}

export async function setStepsForDate(value, date = todayIso()) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n) || n < 0) throw new Error('Ungültige Schrittzahl');
  await db.put(S.steps, { id: date, value: n, updatedAt: Date.now() });
  return n;
}

/* ---------------- Dashboard-Integration ---------------- */

export function renderSection(value) {
  return `
    <div class="steps-card" id="steps-card">
      <span class="steps-card__icon">${icon('footprints')}</span>
      <div class="steps-card__main">
        <div class="steps-card__label">Schritte heute</div>
        <div class="steps-card__value">${value != null ? value.toLocaleString('de-DE') : '–'}</div>
      </div>
      <button class="btn-icon" id="edit-steps-btn" aria-label="Schritte bearbeiten">${icon('edit')}</button>
    </div>
  `;
}

/** Bindet die Events für einen bereits ins DOM eingefügten Steps-Bereich. `onChange` wird nach dem Speichern aufgerufen. */
export function attachHandlers(container, onChange) {
  const btn = container.querySelector('#edit-steps-btn');
  if (btn) btn.addEventListener('click', () => openEditSheet(onChange));
}

async function openEditSheet(onChange) {
  const current = await getStepsForDate();
  const dlg = createSheet(`
    <div class="sheet__header"><h2>Schritte heute</h2><button class="btn-icon" data-close>${icon('x')}</button></div>
    <form id="steps-form">
      <div class="field">
        <label for="steps-input">Schrittzahl</label>
        <input id="steps-input" type="number" inputmode="numeric" min="0" step="1" value="${current ?? ''}" placeholder="z.B. 6420" required autofocus />
      </div>
      <div id="steps-error" class="field-error" hidden></div>
      <button class="btn btn-primary btn-block" type="submit">${icon('check')} Speichern</button>
    </form>
  `);
  dlg.querySelector('#steps-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const raw = dlg.querySelector('#steps-input').value;
    const n = Number(raw);
    const errEl = dlg.querySelector('#steps-error');
    if (raw === '' || !Number.isInteger(n) || n < 0) {
      errEl.textContent = 'Bitte eine gültige, nicht-negative ganze Zahl eingeben.';
      errEl.hidden = false;
      return;
    }
    await setStepsForDate(n);
    toast('Schritte gespeichert');
    dlg.close();
    onChange();
  });
}

function createSheet(innerHtml) {
  const dlg = document.createElement('dialog');
  dlg.className = 'sheet';
  dlg.innerHTML = `<div class="sheet__handle"></div><div class="sheet__body">${innerHtml}</div>`;
  document.body.appendChild(dlg);
  dlg.addEventListener('close', () => dlg.remove());
  dlg.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => dlg.close()));
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  dlg.showModal();
  return dlg;
}
