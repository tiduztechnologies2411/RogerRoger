// Prüft, dass jede in sw.js (SHELL_FILES) gelistete Datei existiert und alle Icons im Manifest vorhanden sind.
// Aufruf: node scripts/check-shell.mjs   (läuft auch im GitHub-Actions-Workflow vor dem Deploy)
import { readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const sw = readFileSync(join(root, 'sw.js'), 'utf8');
const list = sw.match(/const SHELL_FILES = \[([\s\S]*?)\];/);
if (!list) { console.error('SHELL_FILES nicht gefunden'); process.exit(1); }
const files = [...list[1].matchAll(/'(\.[^']*)'/g)].map((m) => m[1]);
const manifest = JSON.parse(readFileSync(join(root, 'manifest.webmanifest'), 'utf8'));
const missing = [];
for (const f of files) {
  if (f === './') continue;
  if (!existsSync(join(root, f))) missing.push(f);
}
for (const icon of manifest.icons) {
  if (!existsSync(join(root, icon.src))) missing.push(icon.src);
  if (!files.includes(icon.src)) missing.push(`${icon.src} (nicht in SHELL_FILES)`);
}
if (missing.length) { console.error('Fehlt oder nicht gecacht:\n - ' + missing.join('\n - ')); process.exit(1); }
console.log(`OK: ${files.length} Shell-Dateien und ${manifest.icons.length} Manifest-Icons vorhanden.`);
