/**
 * sw.js – Service Worker für RogerRoger (PWA, GitHub Pages tauglich).
 *
 * Strategie (bewusst einfach, kein Build-Schritt):
 *  - Install:   komplette App-Shell (SHELL_FILES) wird in EINEN versionierten Cache geladen,
 *               am HTTP-Cache vorbei (cache: 'reload'), damit nie alte und neue Dateien gemischt werden.
 *               Schlägt eine Datei fehl, schlägt die Installation fehl -> alte Version bleibt aktiv.
 *  - Update:    ein neuer Worker wartet, bis die App ihn per Nachricht freigibt ("Aktualisieren"-Banner
 *               in app.js) oder alle App-Fenster geschlossen wurden. Kein automatisches Neuladen mitten
 *               in der Nutzung.
 *  - Fetch:     nur GET, nur same-origin. Seiten-Navigation und Assets kommen aus dem Cache der
 *               aktiven Version (cache first). Alles Unbekannte geht ans Netz und wird NICHT zusätzlich
 *               gecacht. Offline ohne Treffer -> verständliche Offline-Seite bzw. 503.
 *  - Activate:  löscht nur eigene, veraltete Caches (Präfix CACHE_PREFIX) – wichtig auf
 *               github.io, wo mehrere Projekte denselben Origin teilen.
 *  - Nutzerdaten (IndexedDB, localStorage) werden vom Service Worker nie berührt.
 *
 * Alle Pfade sind relativ zu dieser Datei -> funktioniert unter /<repo>/ genauso wie unter /.
 *
 * VERSIONIERUNG: BUILD_ID wird vom GitHub-Actions-Workflow beim Deploy automatisch ersetzt.
 * Wer OHNE Workflow veröffentlicht (Branch-Deploy), erhöht stattdessen CACHE_VERSION von Hand.
 * Bei neuen/entfernten Dateien immer SHELL_FILES anpassen.
 */
const CACHE_PREFIX = 'roger-roger-shell-';
const CACHE_VERSION = 'v12';
const BUILD_ID = '__BUILD_ID__';
const CACHE_NAME = `${CACHE_PREFIX}${CACHE_VERSION}-${BUILD_ID}`;

const SHELL_FILES = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/tokens.css',
  './css/themes.css',
  './css/base.css',
  './css/components.css',
  './css/calendar.css',
  './css/sport.css',
  './css/quiz.css',
  './css/notes.css',
  './css/settings.css',
  './js/app.js',
  './js/core/db.js',
  './js/core/crypto.js',
  './js/core/theme.js',
  './js/core/utils.js',
  './js/core/router.js',
  './js/core/moduleRegistry.js',
  './js/core/icons.js',
  './js/modules/dashboard.js',
  './js/modules/dailies.js',
  './js/modules/steps.js',
  './js/modules/calendar.js',
  './js/modules/sport.js',
  './js/modules/sportPrompt.js',
  './js/modules/quiz.js',
  './js/modules/quizData.js',
  './js/modules/quizPrompt.js',
  './js/modules/quizFoundation/index.js',
  './js/modules/quizFoundation/helpers.js',
  './js/modules/quizFoundation/geography.js',
  './js/modules/quizFoundation/history.js',
  './js/modules/quizFoundation/naturalScience.js',
  './js/modules/quizFoundation/filmStudies.js',
  './js/modules/quizFoundation/artCulture.js',
  './js/modules/quizFoundation/languageLiterature.js',
  './js/modules/quizFoundation/technology.js',
  './js/modules/quizFoundation/economicsPolitics.js',
  './js/modules/quizFoundation/sports.js',
  './js/modules/quizFoundation/astronomy.js',
  './js/modules/notes.js',
  './js/modules/settings.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png',
];

const INDEX_URL = new URL('./index.html', self.location).href;

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // cache: 'reload' umgeht den HTTP-Cache (GitHub Pages liefert max-age=600) -> garantiert frische Dateien
    await Promise.all(SHELL_FILES.map(async (file) => {
      const response = await fetch(new Request(file, { cache: 'reload' }));
      if (!response.ok) throw new Error(`Precache fehlgeschlagen: ${file} (${response.status})`);
      await cache.put(new Request(file), response);
    }));
    // Kein skipWaiting() hier: die App entscheidet über die Übernahme (siehe Message-Handler).
  })());
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter((k) => k.startsWith(CACHE_PREFIX) && k !== CACHE_NAME)
        .map((k) => caches.delete(k))
    );
    await self.clients.claim();
  })());
});

const OFFLINE_HTML = `<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>RogerRoger – offline</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0A0D12;color:#F3F6FA;font-family:-apple-system,system-ui,sans-serif;text-align:center;padding:24px}</style></head>
<body><div><h1>Du bist offline</h1><p>RogerRoger wurde auf diesem Gerät noch nicht vollständig geladen.<br>Verbinde dich einmal mit dem Internet und öffne die App erneut.</p></div></body></html>`;

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return; // fremde Origins: Browser-Standard

  // Seitenaufruf (auch mit Hash/Query): immer die App-Shell der aktiven Version
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(INDEX_URL);
      if (cached) return cached;
      try { return await fetch(request); }
      catch (e) { return new Response(OFFLINE_HTML, { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } }); }
    })());
    return;
  }

  // Assets: aus dem Cache der aktiven Version; Unbekanntes ans Netz, ohne es zu cachen
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request, { ignoreSearch: true });
    if (cached) return cached;
    try { return await fetch(request); }
    catch (e) { return new Response('Offline', { status: 503, statusText: 'Offline' }); }
  })());
});
